# Block Polygon Count Discrepancy Analysis

## Executive Summary

Analysis of polygon count discrepancies between user manual counts and the DXF Block Extractor algorithm for two blocks in `sample-blocks.dxf`. The discrepancies result from two distinct issues: (1) vertical line gaps that allow paint to flow between visual columns, and (2) HATCH boundary edges not being extracted by the algorithm.

## Table Summary

| Block Name | Excel Count | User Count | Discrepancy Cause |
|------------|------------|------------|-------------------|
| Frysetorg D 1960 L 3750 | 7 | 21 | Vertical lines have gaps - paint flows between columns |
| SPAR Gulv 900x600 H1860 | 5 | 7 | HATCH boundary edges not extracted |

## Relevant Files

- `app/core/geometry.py:375-458` - `_extract_all_edges()` and `_extract_paint_bucket_regions()` - Only extracts LINE and LWPOLYLINE edges, ignores HATCH boundaries
- `app/core/geometry.py:727-873` - `_detect_content_zone()` - Main content zone detection using paint-bucket algorithm
- `ai_docs/logical-rules-for-polygons.md` - Paint-bucket principle documentation
- `app/tests/assets/samples/sample-blocks.dxf` - Source DXF file with the blocks

## Finding #1: Frysetorg D 1960 L 3750 (Excel: 7, User: 21)

### Root Cause: Vertical Line Gaps

The vertical divider lines at X=74, 1250, 2500, and 3676 do **NOT** span the full block height. Each has gaps:

| X Position | Segment 1 | Segment 2 | Gap Range |
|------------|-----------|-----------|-----------|
| X=74 | Y=-1808 to -1155 | Y=-805 to -154 | Y=-1155 to -805 |
| X=1250 | Y=-1808 to -1050 | Y=-909 to -152 | Y=-1050 to -909 |
| X=2500 | Y=-1808 to -1050 | Y=-909 to -152 | Y=-1050 to -909 |
| X=3676 | Y=-1808 to -1155 | Y=-805 to -154 | Y=-1155 to -805 |

### Why This Creates 7 Regions Instead of 21

Per the paint-bucket principle from `ai_docs/logical-rules-for-polygons.md`:

> **Operational Definition**: Imagine using a paint bucket tool—each region is a separate area that would fill independently.

Because vertical lines have gaps, **paint can flow between adjacent columns** through those gaps. The 7 detected polygons are:

1. **Large outer region** (Area: 3,349,218) - X=[0, 3750], Y=[-1808, 0] - encompasses multiple visual columns connected through gaps
2. **Center column lower** (Area: 816,875) - X=[1250, 2500], Y=[-1808, -1154]
3. **Center column upper** (Area: 816,875) - X=[1250, 2500], Y=[-805, -152]
4. **Right column** (Area: 768,516) - X=[2500, 3676], Y=[-1808, -1154]
5. **Left column** (Area: 768,516) - X=[74, 1250], Y=[-1808, -1154]
6. **Small region** (Area: 130,000) - X=[1250, 2500], Y=[-1154, -1050]
7. **Small region** (Area: 130,000) - X=[1250, 2500], Y=[-909, -805]

### User's Count of 21

The user likely counted **visual rectangles** treating vertical lines as if they spanned full height. If the vertical lines were continuous, a grid-based calculation would yield:
- 10 horizontal bands × variable column divisions = ~21 visual cells

**Algorithm is correct** per the paint-bucket rule - regions must be truly CLOSED.

## Finding #2: SPAR Gulv 900x600 H1860 (Excel: 5, User: 7)

### Root Cause: HATCH Boundaries Not Extracted

The `_extract_all_edges()` function in `geometry.py:375-407` only extracts edges from:
- LINE entities
- LWPOLYLINE/POLYLINE entities

**It does NOT extract HATCH boundary edges.**

### Block Structure

The block contains:
- 1 HATCH entity (SOLID pattern, color 1 = red) with boundary rectangle (30, -35) to (900, 35)
- 6 LWPOLYLINE entities
- 2 LINE entities
- 1 MTEXT entity

### HATCH Boundary Edges (Currently Ignored)

```
(30.0, -35.0) -> (900.0, -35.0)
(900.0, -35.0) -> (900.0, 35.0)
(900.0, 35.0) -> (30.0, 35.0)
(30.0, 35.0) -> (30.0, -35.0)
```

### Impact

If HATCH boundaries were included in edge extraction:
- The center area would be divided into:
  - Region inside the red hatch boundary
  - Region outside the red hatch boundary (but inside surrounding polylines)
- This would add 2 more closed regions, matching user's count of 7

## Algorithm Behavior Summary

```
Current _extract_all_edges() behavior:
  ✓ Extracts LINE entities
  ✓ Extracts LWPOLYLINE/POLYLINE entities (including closing edge if closed)
  ✗ Does NOT extract HATCH boundary edges
  ✗ Does NOT extract CIRCLE/ARC edges
```

## Recommendations

### For SPAR Block (HATCH Issue)

1. **Option A**: Modify `_extract_all_edges()` to include HATCH boundary paths
   - HATCH entities have `.paths` property with `.edges` containing LineEdge objects
   - Each LineEdge has `.start` and `.end` coordinates

2. **Option B**: Document that HATCH boundaries are intentionally excluded
   - May be intentional since HATCH often represents fill rather than structural boundaries

### For Frysetorg Block (Gap Issue)

1. **No code change needed** - Algorithm correctly implements paint-bucket rule
2. **User education** - Document that polygon count reflects truly CLOSED regions, not visual rectangles
3. The gaps in vertical lines are CAD design features, not algorithm errors

## Next Steps

1. Clarify with user whether HATCH boundaries should contribute to polygon count
2. If yes, implement HATCH boundary extraction in `_extract_all_edges()`
3. Add test cases for blocks with HATCH boundaries
4. Update documentation to explain the paint-bucket rule and gap behavior
