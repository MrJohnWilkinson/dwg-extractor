# Gap Tolerance Approach Analysis: SPAR Gulv vs Frysetorg

## Executive Summary

The two polygon count issues (SPAR Gulv precision errors and Frysetorg design gaps) require fundamentally different gap tolerances. The optimal solution is a **two-stage snapping approach**: Stage 1 applies coordinate precision normalization (always-on, ~1e-6 tolerance) to fix floating-point artifacts, while Stage 2 provides user-configurable gap bridging (default-off) for intentional design gaps.

## Table Summary

| Criterion | Option 1: Coordinate Snapping | Option 2: Buffer-Based | Option 3: Shapely snap() | **Recommended: Two-Stage** |
|-----------|------------------------------|------------------------|--------------------------|---------------------------|
| Fixes SPAR Gulv (3.7nm gap) | Yes | Yes | Yes | Yes (Stage 1) |
| Fixes Frysetorg (~200 unit gap) | No | Possibly | Yes (with config) | Yes (Stage 2) |
| Risk of geometry distortion | Low | High | Medium | Low |
| Performance impact | Minimal | High | Low-Medium | Low-Medium |
| Configurability | None | Complex | Simple | Simple |
| Implementation complexity | Low (10 lines) | High (30+ lines) | Medium (20 lines) | Medium (30 lines) |
| Preserves paint-bucket semantics | Yes | Partially | Yes (if careful) | Yes |

## Relevant Files

- **app/core/geometry.py:465-513** - `_extract_all_edges()` - Where coordinate snapping would be applied
- **app/core/geometry.py:515-560** - `_extract_paint_bucket_regions()` - Where snap() would be applied post-union
- **app/core/constants.py:152-156** - Arc flattening config - Pattern for adding new tolerance constants
- **ai_output/010-spar-gulv-polygon-count-analysis.md** - SPAR Gulv root cause analysis
- **ai_output/002-polygon-count-solutions-report.md** - Original solution proposals

## Problem Characterization

### SPAR Gulv 900x600 H1860

| Attribute | Value |
|-----------|-------|
| Gap magnitude | ~3.7 nanometers (3.7e-9 units) |
| Cause | Floating-point precision in DXF file |
| User expectation | Lines should touch (they look perfect) |
| Required tolerance | 1e-6 or less |
| Fix frequency | Always apply |

### Frysetorg D 1960 L 3750

| Attribute | Value |
|-----------|-------|
| Gap magnitude | ~140-350 CAD units |
| Cause | Intentional design choice (visible when zoomed) |
| User expectation | Lines should bridge (they look connected at normal zoom) |
| Required tolerance | 150-500 units |
| Fix frequency | User-controlled |

## Option Analysis

### Option 1: Coordinate Snapping

```python
def _snap_coordinate(value: float, precision: int = 6) -> float:
    return round(value, precision)
```

**Pros:**
- Simple implementation
- Zero risk of geometry distortion
- Fixes floating-point precision errors universally
- Minimal performance impact

**Cons:**
- Cannot bridge large gaps (140+ units)
- Fixed precision may not suit all drawing scales

**Verdict:** Solves SPAR Gulv only. Does not address Frysetorg.

### Option 2: Buffer-Based Intersection

```python
buffered = unary_union([edge.buffer(tolerance) for edge in edges])
boundary = buffered.boundary  # Extract boundary lines
```

**Pros:**
- Can theoretically bridge any gap size
- Works with complex geometries

**Cons:**
- High performance cost (creates polygon buffers)
- Risk of geometry artifacts at corners
- Buffer/un-buffer doesn't preserve original topology
- Curved edges from buffering complicate polygonize

**Verdict:** Over-engineered, high risk. Not recommended.

### Option 3: Shapely snap() Function

```python
from shapely.ops import snap
merged = unary_union(edges)
snapped = snap(merged, merged, tolerance)
```

**Pros:**
- Single function call
- Configurable tolerance
- Preserves line topology (just moves vertices)
- Well-tested Shapely functionality

**Cons:**
- Single tolerance value: can't fix 3.7nm AND 200-unit gaps simultaneously
- High tolerance could incorrectly merge separate features

**Verdict:** Good for one problem, not both.

## Recommended Approach: Two-Stage Snapping

The key insight is that SPAR Gulv and Frysetorg represent **two different classes of problems** requiring **two different tolerance levels**:

| Stage | Purpose | Tolerance | Default | Risk |
|-------|---------|-----------|---------|------|
| Stage 1: Precision Normalization | Fix floating-point artifacts | 1e-6 | Always ON | Negligible |
| Stage 2: Gap Bridging | Bridge intentional design gaps | User-defined (0-500+) | OFF (0.0) | User-controlled |

### Implementation Design

```python
# In constants.py
COORDINATE_SNAP_PRECISION: float = 1e-6
"""Always-on tolerance for fixing floating-point precision errors.
Snaps endpoints within 1 micrometer (in CAD units). Safe for all drawings."""

GAP_BRIDGE_TOLERANCE: float = 0.0
"""User-configurable tolerance for bridging intentional design gaps.
Default 0.0 (disabled). Set based on drawing scale when needed."""
```

```python
# In geometry.py _extract_paint_bucket_regions()
def _extract_paint_bucket_regions(
    block_def: BlockLayout,
    abort_event: threading.Event | None = None,
    gap_bridge_tolerance: float = 0.0,
) -> list[Polygon]:
    edges = _extract_all_edges(block_def)
    if not edges:
        return []

    # Stage 1: Always apply precision normalization
    merged = unary_union(edges)
    if not merged.is_empty:
        merged = snap(merged, merged, COORDINATE_SNAP_PRECISION)

    # Stage 2: Apply user gap bridging if enabled
    if gap_bridge_tolerance > 0:
        merged = snap(merged, merged, gap_bridge_tolerance)

    # Continue with polygonize...
```

### Why This Works

| Block | Stage 1 (1e-6) | Stage 2 (User) | Result |
|-------|----------------|----------------|--------|
| SPAR Gulv | Fixes 3.7nm gap | Not needed | 7 polygons |
| Frysetorg (no config) | No effect | Disabled | 7 polygons (current) |
| Frysetorg (gap_bridge=200) | No effect | Bridges gaps | 9+ polygons |

### Edge Cases

| Scenario | Behavior |
|----------|----------|
| User sets gap_bridge=0 | Stage 2 skipped, precision fix only |
| User sets gap_bridge=1000000 | Warning logged if > 10% of block size |
| Drawing in micrometers | Stage 1 still appropriate (1e-6 of micrometer) |
| Multiple snap tolerances needed | Chain additional snap() calls |

## Implementation Comparison

| Approach | Lines of Code | Test Cases Needed | Breaking Change Risk |
|----------|---------------|-------------------|---------------------|
| Option 1 only | 10 | 2 | None |
| Option 3 only | 15 | 3 | Low |
| **Two-Stage (Recommended)** | 30 | 5 | None |

## Recommendations

### Immediate (High Priority)

1. **Implement Stage 1 precision normalization** - Add `COORDINATE_SNAP_PRECISION = 1e-6` and apply to all edge extraction
2. **Test with SPAR Gulv block** - Verify polygon count increases from 5 to 7
3. **No user configuration needed** - This is a bug fix, not a feature

### Future (User-Requested)

1. **Add Stage 2 gap bridging parameter** - `gap_bridge_tolerance` in `_detect_content_zone()`
2. **Expose in GUI settings** - Optional advanced setting for users with intentional gaps
3. **Document behavior clearly** - Explain that large gaps are design choices

## Next Steps

1. Add `COORDINATE_SNAP_PRECISION` constant to `app/core/constants.py`
2. Modify `_extract_paint_bucket_regions()` to apply Stage 1 snapping
3. Create unit test with SPAR Gulv-like precision error
4. Validate polygon count fix
5. (Optional) Add Stage 2 for user-configurable gap bridging

## Conclusion

Neither coordinate snapping alone nor single-tolerance snap() can solve both problems. The two-stage approach provides:

- **Automatic precision fix** for floating-point artifacts (SPAR Gulv)
- **Optional gap bridging** for intentional design gaps (Frysetorg)
- **No risk to existing behavior** with conservative Stage 1 tolerance
- **User control** over aggressive gap bridging behavior
