# Frysetorg Block H2O Area Processing Analysis

## Executive Summary

This report traces step-by-step how the `Frysetorg D 1960 L 3750` block is processed by the DXF Block Extractor, with specific focus on the H2O symbol area containing 23 lines and 1 circle. The H2O area lines form an artistic wave pattern with 36 dead-end points, producing zero closed polygons. The circle is completely ignored by the current algorithm.

## Table Summary

| Processing Step | Input | Output | H2O Area Impact |
|-----------------|-------|--------|-----------------|
| 1. Edge Extraction | 47 entities | 43 edges | 23 edges from H2O lines, circle ignored |
| 2. Unary Union | 43 edges | 83 segments | Lines split at 40 intersections |
| 3. Polygonize | 83 segments | 7 polygons | H2O area produces 0 polygons |
| 4. Net Area Calc | 7 polygons | 7 net areas | No containment relationships |
| 5. Content Zone | 7 candidates | 1 winner | Polygon 2 (area: 3,349,218) |

## Relevant Files

- `app/core/geometry.py:375-411` - `_extract_all_edges()` - Extracts LINE/LWPOLYLINE only, ignores CIRCLE
- `app/core/geometry.py:413-458` - `_extract_paint_bucket_regions()` - Runs polygonize on edges
- `app/core/geometry.py:670-724` - `_calculate_net_areas()` - Calculates net areas for content zone
- `app/core/geometry.py:727-873` - `_detect_content_zone()` - Main orchestration function
- `app/tests/assets/samples/sample-blocks.dxf` - Source DXF containing the Frysetorg block

## Block Entity Composition

| Entity Type | Count | Location | Extracted as Edges? |
|-------------|-------|----------|---------------------|
| LINE | 43 | Full block | Yes (all 43) |
| CIRCLE | 1 | H2O area (1874.5, -1563) r=60 | **No** |
| MTEXT | 2 | "Frysdisk", "L:3750 D:1960" | No (text entity) |
| TEXT | 1 | "H2O" at (1797.5, -1449.6) | No (text entity) |

## Step-by-Step Processing

### Step 1: Edge Extraction (`_extract_all_edges`)

```
Input: 47 entities in block definition
Processing:
  - 43 LINE entities → 43 LineString edges
  - 2 MTEXT entities → Skipped (not geometric)
  - 1 TEXT entity → Skipped (not geometric)
  - 1 CIRCLE entity → SKIPPED (entity type not handled)
Output: 43 edges
```

**Key Finding**: The CIRCLE under H2O is completely ignored. The algorithm only handles:
- LINE → single edge
- LWPOLYLINE/POLYLINE → multiple edges + closing edge if closed

### Step 2: Unary Union (Intersection Splitting)

```
Input: 43 edges
Processing: Shapely unary_union() merges coincident points and splits at intersections
Output: 83 line segments
Splits: 40 new intersection points created
```

The H2O area lines are split at their crossing points, creating additional segments.

### Step 3: Polygonize (Closed Region Detection)

```
Input: 83 line segments
Processing: Shapely polygonize() traces closed loops
Output: 7 closed polygons
```

**H2O Area Result**: Zero polygons from H2O lines because:

| Metric | Value | Meaning |
|--------|-------|---------|
| Lines in H2O area | 23 | All the wave/water pattern lines |
| Dead-end points | 36 | Endpoints with degree 1 (no connection) |
| Pass-through points | 2 | Points where exactly 2 lines meet |
| Junction points | 2 | Points where 3+ lines meet |

Per the paint-bucket rule: "Open paths and dangling edges do not create regions." The 36 dead-end points prevent any closed loops from forming.

### Step 4: Polygon Analysis

All 7 detected polygons are from the main block structure (shelves/compartments), not from the H2O area:

| Polygon | Area (sq units) | Bounds X | Bounds Y | Description |
|---------|-----------------|----------|----------|-------------|
| 1 | 816,875 | [1250, 2500] | [-805, -152] | Upper center section |
| 2 | 3,349,218 | [0, 3750] | [-1808, 0] | **Largest - content zone** |
| 3 | 768,516 | [74, 1250] | [-1808, -1154] | Lower left section |
| 4 | 816,875 | [1250, 2500] | [-1808, -1154] | Lower center section |
| 5 | 768,516 | [2500, 3676] | [-1808, -1154] | Lower right section |
| 6 | 130,000 | [1250, 2500] | [-1154, -1050] | Gap region 1 |
| 7 | 130,000 | [1250, 2500] | [-909, -805] | Gap region 2 |

### Step 5: Content Zone Selection

```
Winner: Polygon 2
Net Area: 3,349,218 sq units
Contains: No other polygons
```

None of the 7 polygons contain each other (they're adjacent or separate), so net area = gross area for all.

## H2O Symbol Structure

The H2O symbol consists of:

```
  Circle (ignored)
      ○
     /|\
    / | \    ← Diagonal lines forming wave pattern
   /  |  \
  ----+----  ← Horizontal stub lines
```

**Lines 10-32** (sorted by X) form two mirrored wave patterns:
- Left wave: X ≈ 1794-1849, 13 line segments
- Right wave: X ≈ 1899-1954, 10 line segments

These are artistic/decorative elements that intentionally don't form closed shapes.

## Algorithm Behavior Summary

```
Current _extract_all_edges() behavior:
  ✓ Extracts LINE entities
  ✓ Extracts LWPOLYLINE/POLYLINE entities
  ✗ Does NOT extract CIRCLE entities
  ✗ Does NOT extract ARC entities
  ✗ Does NOT extract HATCH boundary edges
```

The H2O area is **correctly processed** - the algorithm finds no closed regions because there are none. The visual appearance of a "water symbol" is achieved through open paths, not closed polygons.

## Recommendations

### For Circle Extraction (Optional Enhancement)

If circles should contribute to polygon detection:

```python
elif entity.dxftype() == "CIRCLE":
    center = entity.dxf.center
    radius = entity.dxf.radius
    # Discretize circle into line segments
    n_segments = 32  # Configurable precision
    points = []
    for i in range(n_segments):
        angle = 2 * math.pi * i / n_segments
        x = center.x + radius * math.cos(angle)
        y = center.y + radius * math.sin(angle)
        points.append((x, y))
    # Create edges from consecutive points
    for i in range(len(points)):
        edges.append(LineString([points[i], points[(i + 1) % n_segments]]))
```

### For H2O Area Lines

No code change recommended. The current behavior is correct:
- Open artistic lines should not create regions
- The paint-bucket rule correctly excludes them
- User count of 21 likely includes visual "cells" that aren't actually closed

## Next Steps

1. Decide if CIRCLE entities should be extracted (creates 1 additional polygon per circle)
2. If yes, implement circle discretization in `_extract_all_edges()`
3. Add test case for blocks with decorative open line patterns
4. Document that artistic/decorative lines are intentionally excluded from polygon count
