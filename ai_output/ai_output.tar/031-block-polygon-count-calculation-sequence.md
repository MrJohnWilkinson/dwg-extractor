# Block Polygon Count Calculation Sequence Analysis

## Executive Summary

This report provides deep analysis of polygon count discrepancies for two blocks in `sample-blocks.dxf`. The algorithm correctly implements paint-bucket region detection, but two distinct issues cause discrepancies: (1) **floating-point precision gaps** in LINE endpoints (gap of 3.7×10⁻⁹ units) preventing edge-splitting at intersections for SPAR Gulv, and (2) **intentional design gaps** in vertical lines creating dangling edges for Frysetorg.

## Table Summary

| Block Name | Algorithm | User | Gap Type | Technical Detail |
|------------|-----------|------|----------|------------------|
| Frysetorg D 1960 L 3750 | 7 | 21 | Design Gap | 43 dangling endpoints; vertical lines at x=74,1250,2500,3676 have intentional gaps |
| SPAR Gulv 900x600 H1860 | 5 | 7 | Precision Gap | LINE endpoints at x=914.9999999962746 (not 915.0); prevents right edge split |

## Relevant Files

- **app/core/geometry.py:375-410** - `_extract_all_edges()`: Extracts LINE and LWPOLYLINE edges as LineStrings
- **app/core/geometry.py:413-458** - `_extract_paint_bucket_regions()`: Applies unary_union + polygonize for region detection
- **app/core/geometry.py:727-873** - `_detect_content_zone()`: Main entry point that calls paint-bucket algorithm
- **app/core/constants.py:140-150** - Threshold constants (LINE_SEGMENT_THRESHOLD=5000, POLYGON_COUNT_THRESHOLD=500)
- **app/tests/assets/samples/sample-blocks.dxf** - Test file containing analyzed blocks

## Algorithm Flow

```
Block Definition Input
        │
        ▼
┌──────────────────────────────────────┐
│ Step 1: _extract_all_edges()         │
│  - Iterate all entities in block     │
│  - LINE → LineString(start, end)     │
│  - LWPOLYLINE → edge segments        │
│    + closing edge if closed=True     │
└──────────────────────────────────────┘
        │
        ▼
┌──────────────────────────────────────┐
│ Step 2: unary_union(edges)           │
│  - Merge all edges into one geometry │
│  - Split at all intersection points  │
│  - Result: atomic line segments      │
└──────────────────────────────────────┘
        │
        ▼
┌──────────────────────────────────────┐
│ Step 3: polygonize(segments)         │
│  - Find all closed regions           │
│  - Each region = paint-bucket fill   │
│  - Invalid/empty polygons filtered   │
└──────────────────────────────────────┘
        │
        ▼
   polygon_count = len(regions)
```

## Block-by-Block Analysis

### AP #5-4 (Excel: 8, User: 8) - MATCH

**Entity Composition:**
- 1 closed LWPOLYLINE (outer rectangle: 762 x 4876.8)
- 4 LINE segments (1 vertical + 3 horizontal grid)
- 1 TEXT annotation

**Algorithm Trace:**
```
Step 1: _extract_all_edges()
  - LWPOLYLINE → 4 edges (rectangle boundary)
  - LINE entities → 4 edges (internal dividers)
  → Total: 8 edges

Step 2: unary_union()
  - Splits edges at intersections
  - Vertical divider splits into 4 segments
  - Horizontal dividers split into 2 segments each
  → Result: Multiple atomic segments

Step 3: polygonize()
  - Grid of 2 columns x 4 rows
  → Result: 8 closed regions
```

**Why It Works:** The closed LWPOLYLINE provides complete boundary edges. Internal LINEs connect to boundary vertices, creating fully enclosed cells.

---

### Bread gondola (Excel: 13, User: 13) - MATCH

**Entity Composition:**
- 1 closed LWPOLYLINE (outer square: 1219.2 x 1219.2)
- 13 LINE segments (vertical dividers + horizontal bars)

**Algorithm Trace:**
```
Step 1: _extract_all_edges()
  - LWPOLYLINE → 4 edges (boundary)
  - LINE entities → 13 edges
  → Total: 17 edges

Step 2: unary_union()
  - Splits at all intersection points
  → Result: 21 atomic segments

Step 3: polygonize()
  - Complex grid with varying row heights
  → Result: 13 closed regions
```

---

### Bread gondola end (Excel: 4, User: 4) - MATCH

**Entity Composition:**
- 1 closed LWPOLYLINE (outer rectangle)
- 7 LINE segments (T-junction dividers)

**Algorithm Trace:**
```
Step 1: _extract_all_edges()
  - LWPOLYLINE → 4 edges (boundary)
  - LINE entities → 7 edges
  → Total: 11 edges

Step 2: unary_union()
  - T-junctions create segment splits
  → Result: 11 atomic segments

Step 3: polygonize()
  - 4 regions separated by dividers
  → Result: 4 closed regions
```

---

### Frysetorg D 1960 L 3750 (Excel: 7, User: 21) - DISCREPANCY

**Entity Composition:**
- 0 closed LWPOLYLINE (no explicit boundary!)
- 43 LINE segments (grid + diagonals)
- 1 CIRCLE, 3 TEXT/MTEXT

**Algorithm Trace:**
```
Step 1: _extract_all_edges()
  - LINE entities only → 43 edges
  - No LWPOLYLINE boundary
  → Total: 43 edges

Step 2: unary_union()
  - Splits at intersections
  → Result: 83 atomic segments

Step 3: polygonize()
  - Only 7 regions fully closed
  → Result: 7 polygons
```

**Root Cause: Intentional Gaps in Vertical Lines**

The vertical subdivision lines have intentional gaps that prevent horizontal bands from being subdivided:

```
Vertical line at x=74:
  Segment 1: y=-1808 → y=-1154.5
  GAP:       y=-1154.5 → y=-805.5 (349mm missing)
  Segment 2: y=-805.5 → y=-154.0

Vertical line at x=1250:
  Segment 1: y=-1808 → y=-1050.5
  GAP:       y=-1050.5 → y=-909.5 (141mm missing)
  Segment 2: y=-909.5 → y=-152.0

Similar gaps at x=2500 and x=3676
```

**Dangling Endpoint Analysis:**

| Metric | Value |
|--------|-------|
| Total LINE entities | 43 |
| Dangling endpoints (degree=1) | 43 |
| Horizontal lines | 12 (full-width at various Y levels) |
| Vertical lines | 14 (partial-height with gaps) |
| Diagonal lines | 17 (decorative elements) |

**Polygons Actually Found:**
```
1. area=816,875   bounds=(1250,-805.5) to (2500,-152)
2. area=3,349,218 bounds=(0,-1808) to (3750,0) [outer minus inner]
3. area=768,516   bounds=(74,-1808) to (1250,-1154.5)
4. area=816,875   bounds=(1250,-1808) to (2500,-1154.5)
5. area=768,516   bounds=(2500,-1808) to (3676,-1154.5)
6. area=130,000   bounds=(1250,-1154.5) to (2500,-1050.5)
7. area=130,000   bounds=(1250,-909.5) to (2500,-805.5)
```

**Why User Counts 21:** The user may be visually counting expected grid cells or recognizable compartments. However, the vertical line gaps mean these aren't geometrically closed regions per the paint-bucket algorithm.

---

### Gcase(w1800) (Excel: 2, User: 2) - MATCH

**Entity Composition:**
- 1 closed LWPOLYLINE (rectangle: 600 x 1800)
- 1 LINE segment (vertical divider at x=400)

**Algorithm Trace:**
```
Step 1: _extract_all_edges()
  - LWPOLYLINE → 4 edges (boundary)
  - LINE → 1 edge (divider)
  → Total: 5 edges

Step 2: unary_union()
  - Divider splits boundary into segments
  → Result: 6 atomic segments

Step 3: polygonize()
  - Left region + right region
  → Result: 2 closed regions
```

---

### GS900x450HGE_Liquor (Excel: 4, User: 4-5) - MATCH

**Entity Composition:**
- 3 closed LWPOLYLINEs (2 small squares + 1 thin rectangle)
- 4 LINE segments (U-shape top + decorative bottom)

**Algorithm Trace:**
```
Step 1: _extract_all_edges()
  - 3 LWPOLYLINEs → 12 edges (3 rectangles)
  - 4 LINEs → 4 edges
  → Total: 16 edges

Step 2: unary_union()
  - U-shape lines connect to polyline boundaries
  → Result: Multiple segments

Step 3: polygonize()
  - 3 closed LWPOLYs + 1 U-shape interior
  → Result: 4 closed regions
```

**User Note on 5th Polygon:** User mentions decorative line at bottom. This LINE is disconnected and doesn't close with other geometry. If it were connected, 5 polygons would result.

---

### SPAR Gulv 900x600 H1860 (Excel: 5, User: 7) - DISCREPANCY

**Entity Composition:**
- 4 closed LWPOLYLINEs (corner brackets: 30×70 each)
- 2 open LWPOLYLINEs (main frame rectangles: 900×600)
- 2 LINE segments (horizontal dividers at y=±535)
- 1 HATCH (red solid fill with EdgePath boundary)

**Algorithm Trace:**
```
Step 1: _extract_all_edges()
  - 6 LWPOLYLINEs → 24 edges
  - 2 LINEs → 2 edges
  → Total: 26 edges

Step 2: unary_union()
  - LEFT edge correctly split at y=±535
  - RIGHT edge NOT split (LINE doesn't reach!)
  → Result: 24 segments

Step 3: polygonize()
  → Result: 5 closed regions (not 7)
```

**Root Cause: Floating-Point Precision Gap**

The LINE entities have imprecise endpoint coordinates in the DXF source:

```
LINE raw coordinates:
  start = (15.0, -535.0)              ← Exact
  end   = (914.9999999962746, -535.0) ← NOT 915.0!

LWPOLYLINE vertex at right edge:
  (915.0, -35.0)                      ← Exact
```

| Measurement | Value |
|-------------|-------|
| Expected X | 915.0 |
| Actual X | 914.9999999962746 |
| Gap | 3.7254 × 10⁻⁹ units |

**Impact on Edge Splitting:**

```
After unary_union():

Left edge (correctly split):
  Segment 1: (15,-35) → (15,-535)
  Segment 2: (15,-535) → (15,-635)

Right edge (NOT split - single segment):
  Segment 4: (915,-635) → (915,-35)  ← Should be 2 segments!

Horizontal LINE (doesn't quite reach):
  Segment 18: (15,-535) → (914.999999..., -535)
```

**Why 5 Instead of 7:**

The bottom rectangle (y=-35 to y=-635) should be subdivided by the LINE at y=-535 into two regions. Similarly for the top rectangle. But because the LINE endpoints don't exactly touch the right edge (x=915), `unary_union()` doesn't split the right edge at the intersection point. This prevents `polygonize()` from finding the two inner subdivisions.

| With Precision Issue | Without Issue |
|---------------------|---------------|
| Bottom rect: 1 polygon | Bottom rect: 2 polygons |
| Top rect: 1 polygon | Top rect: 2 polygons |
| Center + corners: 3 | Center + corners: 3 |
| **Total: 5** | **Total: 7** |

**HATCH Boundary Note:**

The HATCH has EdgePath boundaries from (30,-35) to (900,35), but adding these edges does NOT change the count because the HATCH boundary coincides with existing LWPOLYLINE edges after unary_union merging.

**Potential Fix - Coordinate Snapping:**
```python
SNAP_TOLERANCE = 0.001  # 1μm tolerance

def snap_to_grid(coord, tolerance):
    rounded = round(coord / tolerance) * tolerance
    if abs(coord - rounded) < tolerance:
        return rounded
    return coord
```

## Entity Types in Edge Extraction

| Entity Type | Currently Extracted | Notes |
|-------------|---------------------|-------|
| LINE | Yes | Direct edge |
| LWPOLYLINE | Yes | Each vertex pair + closing edge if closed |
| POLYLINE | Yes | Same as LWPOLYLINE |
| HATCH | No | Boundary edges could be extracted |
| CIRCLE | No | Could be approximated as polygon |
| ARC | No | Could be approximated as line segments |

## Recommendations

### Option 1: Coordinate Snapping (Recommended for SPAR Gulv issue)
Add tolerance-based snapping before unary_union to close tiny gaps:
```python
SNAP_TOLERANCE = 0.001  # 1μm tolerance

def _extract_all_edges(block_def, snap_tolerance=0.001):
    edges = []
    for entity in block_def:
        if entity.dxftype() == 'LINE':
            start = entity.dxf.start
            end = entity.dxf.end
            # Snap coordinates to close tiny gaps
            sx = round(start.x / snap_tolerance) * snap_tolerance
            sy = round(start.y / snap_tolerance) * snap_tolerance
            ex = round(end.x / snap_tolerance) * snap_tolerance
            ey = round(end.y / snap_tolerance) * snap_tolerance
            edges.append(LineString([(sx, sy), (ex, ey)]))
```

### Option 2: Document Expected Behavior
For Frysetorg-type blocks with intentional design gaps:
- The algorithm correctly implements paint-bucket semantics
- Only truly closed regions count as polygons
- Design gaps in CAD are respected (not auto-closed)

### Option 3: Add HATCH Boundary Extraction
For comprehensive region detection:
```python
elif entity.dxftype() == 'HATCH':
    for path in entity.paths:
        if hasattr(path, 'edges'):
            for edge in path.edges:
                if hasattr(edge, 'start') and hasattr(edge, 'end'):
                    edges.append(LineString([
                        edge.start[:2], edge.end[:2]
                    ]))
```

## Next Steps

1. **Decide on snap tolerance**: 0.001 units (1μm) would fix SPAR Gulv without affecting valid geometry
2. **Test snap tolerance on other blocks**: Ensure snapping doesn't incorrectly merge near-but-distinct geometry
3. **Add diagnostic output**: Include "dangling endpoint count" and "gap analysis" for debugging
4. **Document paint-bucket semantics**: Clarify that visual regions ≠ geometric regions
