# Alternative Approach vs Primary Fix: Gap Bridge Analysis

## Executive Summary

The Alternative Approach (pre-union snapping) is the **cleaner solution** for fixing the Gap Bridge issue. While both approaches require two `unary_union()` calls when gap bridging is enabled, the Alternative Approach maintains consistency with the existing precision fix pattern, provides cleaner separation of concerns, and keeps the final union as the single authoritative source for intersection computation.

## Table Summary

| Aspect | Primary Fix | Alternative Approach | Winner |
|--------|-------------|---------------------|--------|
| **Code Change** | +1 line | +3 lines | Primary |
| **Pattern Consistency** | Different from precision fix | Same as precision fix | Alternative |
| **Union Operations** | 2 (when gap_bridge > 0) | 2 (when gap_bridge > 0) | Tie |
| **Snap Target** | Post-union merged geometry | Pre-union individual edges | Alternative |
| **Separation of Concerns** | Mixed (snap after union) | Clean (all snapping before union) | Alternative |
| **Code Flow Clarity** | union → snap → union | snap → snap → union | Alternative |
| **Final Union Purpose** | Re-compute intersections | Single authoritative computation | Alternative |
| **Maintainability** | Two different snapping patterns | Unified snapping pattern | Alternative |

## Relevant Files

- `app/core/geometry.py:645-715` - `_extract_paint_bucket_regions()` - Function requiring the fix
- `app/core/geometry.py:541-560` - `_snap_linestring_coords()` - Existing precision fix pattern to follow
- `app/core/geometry.py:687-702` - Current two-stage snapping implementation

## Detailed Analysis

### Primary Fix Implementation

```python
# After existing code at line 701
if gap_bridge_tolerance > 0:
    merged = snap(merged, merged, gap_bridge_tolerance)
    merged = unary_union(merged)  # <-- One line addition
```

**Code Flow:**
1. Individual edges → precision grid snap
2. `unary_union()` → compute intersections, split edges
3. `snap()` → move vertices in merged geometry
4. `unary_union()` → re-compute intersections after snap
5. `polygonize()` → find closed regions

### Alternative Approach Implementation

```python
# Replace lines 699-702 with:
if gap_bridge_tolerance > 0:
    all_edges_geom = unary_union(edges)
    edges = [snap(e, all_edges_geom, gap_bridge_tolerance) for e in edges]
    logger.debug(f"Applied Stage 2 gap bridge: tolerance={gap_bridge_tolerance}")

merged = unary_union(edges)
```

**Code Flow:**
1. Individual edges → precision grid snap
2. (if gap_bridge) `unary_union()` → create reference geometry
3. (if gap_bridge) Individual edges → snap to reference
4. `unary_union()` → single authoritative intersection computation
5. `polygonize()` → find closed regions

## Why Alternative Approach is Cleaner

### 1. Pattern Consistency

The existing precision fix follows a clear pattern:
```python
# Stage 1: Process individual edges BEFORE union
edges = [_snap_linestring_coords(e, precision_tolerance) for e in edges]
merged = unary_union(edges)
```

Alternative Approach maintains this pattern:
```python
# Stage 1: Precision snap (individual edges)
edges = [_snap_linestring_coords(e, precision_tolerance) for e in edges]
# Stage 2: Gap bridge snap (individual edges)
edges = [snap(e, all_edges_geom, gap_bridge_tolerance) for e in edges]
# Final union (single source of truth)
merged = unary_union(edges)
```

Primary Fix breaks this pattern:
```python
edges = [_snap_linestring_coords(e, precision_tolerance) for e in edges]
merged = unary_union(edges)  # First union
merged = snap(merged, merged, gap_bridge_tolerance)  # Snap AFTER union
merged = unary_union(merged)  # Second union to fix snap
```

### 2. Separation of Concerns

| Stage | Alternative Approach | Primary Fix |
|-------|---------------------|-------------|
| Pre-processing | All snapping happens here | Only precision snap |
| Union | Single authoritative pass | Two passes with different purposes |
| Post-processing | None | Snap + re-union |

### 3. Semantic Clarity

**Alternative Approach reads as:**
> "Prepare all edges (fix precision, bridge gaps), then compute intersections once"

**Primary Fix reads as:**
> "Fix precision, compute intersections, then move vertices, then re-compute intersections"

### 4. Maintainability

Future developers will find two snapping operations in the same code location with the same pattern easier to understand and modify than two different patterns in different locations.

## Correctness Verification

Both approaches produce equivalent results for gap bridging:

**Scenario:** Edge A (0,0)→(100,0), Edge B (103,0)→(200,0), gap=3mm

| Step | Alternative | Primary Fix |
|------|-------------|-------------|
| After precision snap | A, B unchanged | A, B unchanged |
| After gap snap | B becomes (100,0)→(200,0) | B becomes (100,0)→(200,0) |
| After union | A, B share (100,0) | A, B share (100,0) |
| Polygonize | Can traverse A→B | Can traverse A→B |

## Performance Consideration

Both approaches perform two `unary_union()` calls when gap bridging is enabled:

- **Alternative:** union(edges) for reference + union(edges) final
- **Primary:** union(edges) + union(merged)

The Alternative Approach may be slightly faster because:
- First union operates on original edges (not yet split at intersections)
- Snapping operates on individual LineStrings, not a large MultiLineString

However, the performance difference is likely negligible for typical CAD drawings.

## Recommendations

1. **Implement the Alternative Approach** for cleaner, more maintainable code
2. Update the function docstring to document both snapping stages consistently
3. Consider adding a debug log showing how many edges were modified by gap bridging

## Proposed Code Change

```python
def _extract_paint_bucket_regions(
    block_def: BlockLayout,
    abort_event: threading.Event | None = None,
    precision_tolerance: float = 1e-6,
    gap_bridge_tolerance: float = 0.0,
) -> list[Polygon]:
    edges = _extract_all_edges(block_def)

    if not edges:
        return []

    if abort_event and abort_event.is_set():
        raise GeometryAbortedError("Region detection aborted")

    # Stage 1: Precision snapping BEFORE union to fix floating-point artifacts
    if precision_tolerance > 0:
        edges = [_snap_linestring_coords(e, precision_tolerance) for e in edges]
        logger.debug(f"Applied Stage 1 precision snap: tolerance={precision_tolerance}")

    # Stage 2: Gap bridging for intentional design gaps (when enabled)
    # Snap individual edges to reference geometry BEFORE final union
    if gap_bridge_tolerance > 0:
        all_edges_geom = unary_union(edges)
        edges = [snap(e, all_edges_geom, gap_bridge_tolerance) for e in edges]
        logger.debug(f"Applied Stage 2 gap bridge: tolerance={gap_bridge_tolerance}")

    # Merge and split at all intersections (single authoritative union)
    merged = unary_union(edges)
    if merged.is_empty:
        return []

    line_segments = list(merged.geoms) if hasattr(merged, "geoms") else [merged]
    polygons = list(polygonize(line_segments))
    # ... rest of function unchanged
```

## Next Steps

1. Implement the Alternative Approach in `geometry.py`
2. Add unit test for gap bridging with the test file `sample-blocks.dxf`
3. Verify polygon counts match precision fix at equivalent tolerances
4. Run full test suite to ensure no regressions
