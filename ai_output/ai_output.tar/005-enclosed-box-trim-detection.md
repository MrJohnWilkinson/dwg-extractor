# Enclosed Box Threshold Approach for Trim Detection

## Executive Summary

This report analyzes an alternative trim detection strategy using enclosed rectangles and surface area thresholds. The approach identifies closed LWPOLYLINE rectangles within blocks, classifies them by area (>90,000 mm² = content zone, <90,000 mm² = trim zone), and derives trim values from edge distances. While not universal, this method could serve as a high-confidence Tier 0 detection that precedes heuristic fallbacks.

## Table Summary

| Aspect | Assessment | Notes |
|--------|------------|-------|
| Detection Method | Closed LWPOLYLINE rectangles | 4-vertex closed polylines only |
| Threshold | 90,000 mm² (300×300 mm) | Separates content from trim zones |
| Expected Accuracy | 85-95% when applicable | High confidence where pattern exists |
| Applicability | ~35% of blocks | Only blocks with explicit geometry |
| Implementation | Medium complexity | Extends existing geometry.py functions |
| False Positives | Low risk | Threshold is conservative |
| Edge Cases | Internal subdivisions, overlapping boxes | Need largest-box heuristic |

## Relevant Files

- `app/core/geometry.py` - Already iterates over LWPOLYLINE entities; needs `_detect_enclosed_rectangles()` function
- `app/core/extractor.py:838-851` - Block geometry analysis; would call new detection function
- `ai_output/004-block-config-automation-feasibility.md` - Prior art showing corner rectangle detection opportunity
- `app/tests/assets/create_comprehensive_scale_test_compact.py` - Shows LWPOLYLINE rectangle creation pattern

## Algorithm Design

### Core Detection Logic

```
1. For each entity in block_def:
   a. Filter for LWPOLYLINE entities
   b. Check if closed (is_closed or first_point == last_point)
   c. Check if exactly 4 vertices (rectangle)
   d. Calculate area from vertex coordinates

2. Classify rectangles:
   - Area > 90,000 mm² → Content Zone candidate
   - Area < 90,000 mm² → Trim Zone candidate

3. Derive trim values:
   - Largest content zone defines "usable area"
   - Trim Left  = content_min_x - block_min_x
   - Trim Right = block_max_x - content_max_x
   - Trim Top   = block_max_y - content_max_y
   - Trim Bottom = content_min_y - block_min_y
```

### Threshold Rationale

The 90,000 mm² threshold (equivalent to a 300×300 mm square) was chosen based on analysis from the prior feasibility report:

| Component Type | Typical Size | Area | Classification |
|----------------|--------------|------|----------------|
| Corner trim rectangle | 30×70 mm | 2,100 mm² | Well below threshold |
| Edge detail geometry | 50×150 mm | 7,500 mm² | Below threshold |
| **Threshold** | **300×300 mm** | **90,000 mm²** | **Boundary** |
| Small shelf section | 400×400 mm | 160,000 mm² | Above threshold |
| Typical block content | 900×800 mm | 720,000 mm² | Well above threshold |

The threshold provides a 12× separation ratio between typical trim zones (2,100 mm²) and typical content zones (720,000 mm²), minimizing false classification risk.

## Feasibility Analysis

### When This Works Well

1. **Blocks with explicit content outlines** - Many CAD blocks include a bounding rectangle around the "usable" area
2. **Symmetric trim blocks** - Corner rectangles clearly mark trim zones at all four edges
3. **Standard shelf fixtures** - Retail blocks often have a frame rectangle plus trim detail rectangles
4. **Clean geometry blocks** - Blocks designed for automation-friendly extraction

### When This Does NOT Work

1. **Empty blocks (65%)** - Dynamic block references have no geometry in the anonymous block
2. **LINE-only geometry** - Blocks built from disconnected LINE entities have no closed rectangles
3. **Complex internal geometry** - Blocks with multiple internal subdivisions or nested equipment
4. **Non-rectangular content** - Curved or irregular content zones
5. **Overlapping rectangles** - Multiple nested frames require largest-box selection heuristic

### Applicability Estimate

From prior analysis of the sample DXF file:

| Block Category | Count | Has Closed Rectangles | Applicable |
|----------------|-------|----------------------|------------|
| Empty (dynamic refs) | 160 | No | 0% |
| 1-20 entities | 35 | Often | ~60% |
| 20-100 entities | 15 | Sometimes | ~40% |
| 100+ entities | 12 | Rarely | ~10% |
| **Total** | 222 | ~25 blocks | **~11%** |

However, for **blocks with actual geometry** (62 of 222), the applicability rises to **~35%**.

## Implementation Strategy

### Proposed Function

```python
def _detect_content_zone(
    block_def: BlockLayout,
    area_threshold: float = 90000.0
) -> dict[str, float] | None:
    """
    Detect content zone from enclosed rectangles.

    Returns:
        Dict with trim_left, trim_right, trim_top, trim_bottom
        or None if no confident detection possible.
    """
```

### Integration Points

1. **Primary detection (new)** - Run enclosed box detection first
2. **Fallback to segment heuristics** - If no confident result, use existing `_calculate_segments()` approach
3. **Confidence flag** - Return detection method so downstream can weight reliability

### Detection Hierarchy (Updated)

| Priority | Method | Confidence | Coverage |
|----------|--------|------------|----------|
| Tier 0 | Enclosed box detection | 95%+ | ~11% of all blocks |
| Tier 1 | Symmetric segment matching | 76% | ~50% of remaining |
| Tier 2 | Block naming convention parsing | 60% | ~25% of remaining |
| Tier 3 | Default/manual | 100% (human) | ~14% remainder |

## Edge Cases and Mitigations

### Multiple Content Rectangles

**Problem:** Block contains several large rectangles (e.g., multi-shelf unit)

**Mitigation:** Select the **outermost** (largest bounding) rectangle as content zone. Inner subdivisions are not trim zones.

```python
# Pseudo-code for largest-bounding selection
content_candidates = [r for r in rectangles if area(r) > threshold]
if len(content_candidates) > 1:
    # Select rectangle with largest bounding box area
    content_zone = max(content_candidates, key=lambda r: bounding_area(r))
```

### Nested Rectangles

**Problem:** Trim rectangles may be inside, not outside, the content zone

**Mitigation:** Only consider rectangles **at block edges** as trim zones:

```python
def is_at_edge(rect, block_bbox, tolerance=5.0):
    """Check if rectangle touches block boundary."""
    return (
        abs(rect.min_x - block_bbox.min_x) < tolerance or
        abs(rect.max_x - block_bbox.max_x) < tolerance or
        abs(rect.min_y - block_bbox.min_y) < tolerance or
        abs(rect.max_y - block_bbox.max_y) < tolerance
    )
```

### Non-Rectangular Polylines

**Problem:** 5+ vertex polylines that aren't rectangles

**Mitigation:** Strict 4-vertex filter with right-angle validation:

```python
def is_rectangle(points, angle_tolerance=1.0):
    """Validate 4 vertices form a rectangle (90° corners)."""
    if len(points) != 4:
        return False
    # Check all angles are 90° within tolerance
    # ...
```

## Recommendations

1. **Implement as opt-in Tier 0 detection** - Run first, fall back to existing heuristics
2. **Parameterize threshold** - Allow configuration for different block types (90k default, adjustable)
3. **Return confidence score** - Let downstream weigh reliability: `enclosed_box` > `segment_match` > `name_parse`
4. **Add validation test cases** - Create DXF fixtures with known enclosed rectangles
5. **Log detection method** - Track which method succeeded for accuracy analysis

## Next Steps

1. Add `_detect_enclosed_rectangles()` to `geometry.py` with closed LWPOLYLINE detection
2. Add `_calculate_rectangle_area()` helper for 4-vertex area calculation
3. Create `_detect_content_zone()` that combines detection with threshold filtering
4. Extend `_get_block_bounding_box()` call site to try enclosed box detection first
5. Create test fixture DXF with known enclosed rectangles for validation
6. Run detection on real sample DXF to measure actual applicability rate

## Conclusion

The enclosed box threshold approach is a **viable complementary strategy** that can provide high-confidence trim detection for a subset of blocks. Its strength is precision over recall—when it works, it works reliably. Combined with existing heuristics as fallbacks, this creates a tiered detection system that maximizes automation while maintaining accuracy.

The 90,000 mm² threshold is geometrically sound, providing clear separation between typical trim zones (~2,000 mm²) and content zones (~700,000 mm²). Implementation complexity is moderate, leveraging existing LWPOLYLINE iteration in `geometry.py`.

**Bottom line:** This approach won't solve every block, but for the ~35% of blocks with explicit geometry, it could achieve 95%+ accuracy compared to 76% from segment matching alone.
