# Precision Fix vs Gap Bridge: Purpose and Mechanism Comparison

## Executive Summary

**Yes, Gap Bridge achieves a different purpose than Precision Fix.** Both are coordinate snapping mechanisms applied during polygon detection, but they target different problems: Precision Fix (Stage 1) corrects microscopic floating-point artifacts inherent in CAD file storage, while Gap Bridge (Stage 2) closes intentional design gaps that may exist in the drawing. They use different algorithms, operate at different tolerance scales, and are applied at different points in the geometry pipeline.

## Table Summary

| Aspect | Precision Fix (Stage 1) | Gap Bridge (Stage 2) |
|--------|------------------------|---------------------|
| **Purpose** | Fix floating-point storage artifacts | Bridge intentional design gaps |
| **Problem Solved** | Coordinates like `4876.80000000028` instead of `4876.8` | Small gaps between lines left by designer |
| **Tolerance Scale** | Nanometer-scale (0.01mm default) | CAD-scale (0.5mm default for MM) |
| **Algorithm** | Custom grid rounding via `_snap_linestring_coords()` | Shapely's `snap()` function |
| **Applied To** | Individual LineStrings (edges) | Merged geometry (after `unary_union`) |
| **Timing** | BEFORE intersection detection | AFTER intersection detection |
| **Default State** | Enabled by default | Disabled by default |
| **Coordinate Shift** | None (tiny tolerance matches precision) | Potentially significant (can expand bounds) |

## Relevant Files

- `app/core/geometry.py:541-560` - `_snap_linestring_coords()` - Custom snapping algorithm for Precision Fix
- `app/core/geometry.py:687-702` - Two-stage snapping application in `_extract_paint_bucket_regions()`
- `app/core/constants.py:198-215` - Stage 1 precision tolerances (PRECISION_SNAP_TOLERANCE)
- `app/core/constants.py:217-229` - Stage 2 gap bridge tolerances (DEFAULT_GAP_BRIDGE_TOLERANCE)
- `app/core/constants.py:239-260` - User-configurable precision fix tolerances (DEFAULT_PRECISION_FIX_TOLERANCE)
- `app/core/extractor.py:128-223` - `get_snap_tolerances()` calculates both values

## Algorithm Differences

### Precision Fix: Custom Grid Snapping

```python
# geometry.py:556-558
coords = [
    (round(x / tolerance) * tolerance, round(y / tolerance) * tolerance)
    for x, y in line.coords
]
```

This applies **deterministic grid rounding** to each coordinate independently. Every coordinate is snapped to the nearest multiple of the tolerance value.

- **Input**: Individual LineString edges before merging
- **Output**: LineStrings with coordinates aligned to grid
- **Behavior**: Predictable, always rounds to nearest grid point

### Gap Bridge: Shapely snap()

```python
# geometry.py:700-701
merged = snap(merged, merged, gap_bridge_tolerance)
```

Shapely's `snap()` function uses a different approach - it snaps vertices of the first geometry to **vertices and edges** of the second geometry within the tolerance distance.

- **Input**: Merged geometry after `unary_union()` (all intersections computed)
- **Output**: Geometry with nearby endpoints connected
- **Behavior**: Context-aware, snaps to existing geometry features

## Pipeline Order

```
1. Extract edges from DXF entities (LINE, LWPOLYLINE, etc.)
2. [Stage 1 - Precision Fix] Grid-snap each edge's coordinates
3. Merge all edges with unary_union() (splits at intersections)
4. [Stage 2 - Gap Bridge] Snap vertices to nearby geometry
5. Run polygonize() to find closed regions
```

The **order matters**: Precision Fix ensures endpoints align before intersection computation, while Gap Bridge connects components that remain disconnected after the union.

## Tolerance Scale Comparison

| Unit | Precision Fix Default | Gap Bridge Default | Ratio |
|------|----------------------|-------------------|-------|
| MM | 0.01 | 0.5 | 50x |
| IN | 0.0005 | 0.01 | 20x |
| FT | 0.00005 | 0.1 | 2000x |
| M | 0.00001 | 0.001 | 100x |

Gap Bridge tolerances are 20-2000x larger than Precision Fix tolerances, reflecting their different purposes:
- Precision Fix: Sub-mil accuracy for storage artifacts
- Gap Bridge: Visible CAD gaps (e.g., 0.5mm)

## Why Both Can Cause Negative Trim (But Differently)

### Precision Fix with Large Custom Tolerance
As documented in report 036, when a user sets a large precision fix amount (e.g., 3 units), the grid snapping can expand coordinates beyond the block's native bounds because:
```
round(4876.8 / 3) * 3 = 1626 * 3 = 4878.0  (+1.2 expansion)
```

### Gap Bridge
Gap Bridge is less likely to cause this issue because:
1. It snaps to existing geometry, not to an arbitrary grid
2. It only affects vertices within tolerance of other geometry
3. It doesn't systematically shift all coordinates

However, Gap Bridge can still cause minor boundary shifts if dangling edges near the block perimeter get snapped to nearby geometry.

## Recommendations

1. **Use Both Together** - They solve complementary problems:
   - Precision Fix: Always enable (fixes storage artifacts)
   - Gap Bridge: Enable when drawings have intentional gaps that prevent polygon closure

2. **Keep Custom Tolerances Small** - Large custom precision fix values (>1 unit) cause the coordinate domain mismatch described in report 036

3. **Document the Distinction** - Users may not understand why two similar-sounding features exist:
   - Precision Fix = automatic floating-point cleanup
   - Gap Bridge = manual gap closure for specific drawings

## Next Steps

1. Consider renaming in UI for clarity:
   - "Precision Fix" → "Floating-Point Cleanup" or "Coordinate Precision"
   - "Gap Bridge" → "Close Drawing Gaps" or "Bridge Disconnected Lines"

2. The negative trim issue from report 036 affects Precision Fix primarily; Gap Bridge is not the root cause

3. Both features could benefit from a visual indicator showing how many coordinates/gaps were affected
