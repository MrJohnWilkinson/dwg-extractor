# Gap Bridge Function Incorrect Polygon Count Analysis

## Executive Summary

The Gap Bridge function fails to produce correct polygon counts because it applies `snap()` **after** `unary_union()` without re-running the union operation. When `snap()` moves vertices to close gaps, new intersection points are created that were not computed by the original union, preventing `polygonize()` from finding closed regions. Precision Fix works correctly because it applies grid snapping **before** `unary_union()`.

## Table Summary

| Aspect | Precision Fix (Working) | Gap Bridge (Broken) |
|--------|------------------------|---------------------|
| **Snapping Timing** | BEFORE `unary_union()` | AFTER `unary_union()` |
| **Intersection Detection** | Computed with snapped coords | Computed with original coords |
| **Post-Snap Processing** | N/A | Missing `unary_union()` |
| **Polygon Detection** | Works - edges meet exactly | Fails - edges don't share endpoints |
| **Result at 3mm** | Correct polygon count | Incorrect/zero polygon count |

## Relevant Files

- `app/core/geometry.py:645-715` - `_extract_paint_bucket_regions()` - Contains the faulty sequence
- `app/core/geometry.py:541-560` - `_snap_linestring_coords()` - Precision Fix grid snapping
- `app/core/geometry.py:687-702` - Two-stage snapping application showing the sequence issue
- `app/tests/assets/samples/sample-blocks.dxf` - Test file where issue manifests

## Root Cause Analysis

### Current Code Sequence (geometry.py:687-705)

```python
# Stage 1: Precision snapping BEFORE union (WORKS)
if precision_tolerance > 0:
    edges = [_snap_linestring_coords(e, precision_tolerance) for e in edges]

# Merge and split at all intersections
merged = unary_union(edges)  # <-- Intersections computed HERE

# Stage 2: Gap bridging AFTER union (BROKEN)
if gap_bridge_tolerance > 0:
    merged = snap(merged, merged, gap_bridge_tolerance)  # <-- Moves vertices

# Find polygons (FAILS for Gap Bridge)
line_segments = list(merged.geoms) if hasattr(merged, "geoms") else [merged]
polygons = list(polygonize(line_segments))  # <-- Requires exact endpoint sharing
```

### Why Precision Fix Works at 3mm

1. Each edge's coordinates are grid-snapped BEFORE union
2. Grid snapping: `round(x / 3) * 3` aligns coordinates to 3mm grid
3. Edges that were 3mm apart now share exact endpoint coordinates
4. `unary_union()` computes intersections with these aligned coordinates
5. `polygonize()` finds closed regions because edges meet exactly

**Example:**
```
Before snap: Edge A ends at (99.5, 100), Edge B starts at (102.2, 100)
After 3mm grid snap: Both become (99, 100) → edges now meet exactly
Union computes this as a shared point → polygonize() succeeds
```

### Why Gap Bridge Fails at 3mm

1. Edges enter `unary_union()` with original coordinates
2. Union computes intersections based on original (unsnapped) geometry
3. `snap()` then moves vertices to close 3mm gaps
4. **PROBLEM**: New intersection points are NOT computed after snap
5. `polygonize()` fails because edges don't actually share endpoints

**Example:**
```
Original: Edge A (0,0)-(100,0), Edge B (103,0)-(200,0) - 3mm gap
After union: Intersections computed - NO intersection between A and B
After snap(3mm): Edge B moves to (100,0)-(200,0)
BUT: Union was NOT re-run, so (100,0) is NOT a shared node
Result: polygonize() can't find closed regions through this connection
```

### The Missing Step

After `snap()` modifies the geometry, the code proceeds directly to `polygonize()` without re-running `unary_union()`. This is the critical bug:

```python
# Current (BROKEN):
merged = snap(merged, merged, gap_bridge_tolerance)
polygons = list(polygonize(line_segments))

# Should be (FIXED):
merged = snap(merged, merged, gap_bridge_tolerance)
merged = unary_union(merged)  # <-- RE-COMPUTE intersections after snap
line_segments = list(merged.geoms) if hasattr(merged, "geoms") else [merged]
polygons = list(polygonize(line_segments))
```

## Shapely `snap()` vs Grid Snapping Behavior

### Shapely `snap()` Function
- Snaps vertices of geometry A to **vertices and edges** of geometry B within tolerance
- Does NOT create new intersection nodes
- Does NOT split edges at snapped points
- Only moves existing vertices closer together

### Grid Snapping (`_snap_linestring_coords`)
- Rounds every coordinate to nearest grid multiple
- Applied to individual LineStrings before any merging
- Deterministic - same input always produces same output
- Ensures coordinates that should meet will meet exactly

## Recommendations

### Primary Fix
Add `unary_union()` after `snap()` in `_extract_paint_bucket_regions()`:

```python
# Stage 2: Gap bridging for intentional design gaps (when enabled)
if gap_bridge_tolerance > 0:
    merged = snap(merged, merged, gap_bridge_tolerance)
    # RE-RUN union to compute new intersections after snapping
    merged = unary_union(merged)
```

### Alternative Approach
Apply gap bridging to individual edges BEFORE the initial union (similar to precision fix):

```python
if gap_bridge_tolerance > 0:
    # Snap individual edges to each other before union
    all_edges_geom = unary_union(edges)
    edges = [snap(e, all_edges_geom, gap_bridge_tolerance) for e in edges]

merged = unary_union(edges)  # Now union handles snapped edges
```

### Testing Requirements
1. Test with `sample-blocks.dxf` at 3mm gap bridge
2. Verify polygon counts match Precision Fix at same tolerance
3. Ensure backward compatibility with smaller tolerances
4. Performance testing - second `unary_union()` has computational cost

## Next Steps

1. Implement the fix by adding `unary_union()` after `snap()` in geometry.py:700-705
2. Add unit test specifically for Gap Bridge polygon detection
3. Consider adding logging to track gap bridge effectiveness (vertices moved, polygons found)
4. Update report 037 to reflect this finding about Gap Bridge's current broken state

## Technical Reference

### Shapely Documentation
- `unary_union()`: Computes geometric union, splits at intersections, returns unified geometry
- `snap()`: Snaps vertices within tolerance, does NOT compute new intersections
- `polygonize()`: Finds closed polygons from edges that share exact endpoints
