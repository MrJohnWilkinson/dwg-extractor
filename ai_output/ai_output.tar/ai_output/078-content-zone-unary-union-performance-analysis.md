# Content Zone Unary Union Performance Analysis

## Executive Summary

The `unary_union()` operation is the primary bottleneck in content zone detection, consuming 37-58 seconds for blocks with 1,000-3,000 edges. This report investigates STRtree spatial indexing, curved entity filtering, and precision settings to reduce processing time. Key finding: **curved entity filtering** offers the highest immediate impact with minimal code changes.

## Table Summary

| Setting | Current Default | Units | Purpose | Performance Impact |
|---------|----------------|-------|---------|-------------------|
| `arc_flattening_sagitta` | 0.1 | **DXF drawing units** | Max arc-to-chord distance for curve flattening | Lower = more segments, slower |
| `coord_dedup_epsilon` | 0.01 | **DXF drawing units** | Tolerance for coordinate deduplication | Higher = fewer unique coords |
| `rotation_tolerance` | 1.0 | **Degrees** | Tolerance for rotation categorization (0/90/180/270) | N/A (not geometry-related) |

### Log Analysis Summary

| Block Name | Entity Count | Edge Count | Unary Union Time | Total Time |
|------------|-------------|------------|------------------|------------|
| Stockroom_Hook_SafetyVestRail | ~130 entities | 1,154 edges | 37.18s | 38.93s |
| FreshProduce_ScoopWeighPottles_Wood | ~280 entities | 3,098 edges | 58.14s | 63.76s |

### Optimization Impact Estimates

| Strategy | Effort | Est. Time Reduction | Risk |
|----------|--------|---------------------|------|
| Skip Curved Entities | Low | 30-50% | Low - may miss curved boundaries |
| STRtree Spatial Clustering | Medium | 40-80% | Medium - requires algorithm redesign |
| Higher Sagitta Value | Trivial | 10-30% | Low - reduces curve precision |
| Shapely 2.1 `disjoint_subset` | Low | 20-60% | Low - requires Shapely 2.1+ |

## Relevant Files

- **`app/core/geometry.py`**: Contains `_extract_all_edges()`, `_extract_paint_bucket_regions()`, and the `unary_union()` call at line 778
- **`app/core/constants.py`**: Defines `ARC_FLATTENING_SAGITTA`, `DEFAULT_COORD_DEDUP_EPSILON`, `DEFAULT_ROTATION_TOLERANCE` and their validation ranges
- **`app/core/settings.py`**: Settings management including precision section settings

## Units Analysis

### Arc Flattening Sagitta (`arc_flattening_sagitta`)
- **Units**: DXF drawing units (mm, inches, meters, etc. - whatever the drawing uses)
- **Default**: 0.1
- **Range**: 0.01 to 1.0
- **Purpose**: Controls maximum perpendicular distance from arc center to chord when flattening curves
- **Impact**: A 10mm radius circle with sagitta=0.1 produces ~36 segments; with sagitta=1.0, produces ~12 segments

### Coordinate Dedup Epsilon (`coord_dedup_epsilon`)
- **Units**: DXF drawing units
- **Default**: 0.01
- **Range**: 0.001 to 1.0
- **Purpose**: In `_get_intersection_points()`, coordinates within this distance are considered duplicates
- **Impact**: Higher values merge more coordinate points, reducing calculation complexity

### Rotation Tolerance (`rotation_tolerance`)
- **Units**: Degrees
- **Default**: 1.0
- **Range**: 0.1 to 5.0
- **Purpose**: Tolerance for categorizing angles as standard (0/90/180/270) vs "other"
- **Impact**: Not related to content zone performance - only affects rotation classification

## Problem Analysis

### Current Flow
```
_detect_content_zone()
  -> _extract_paint_bucket_regions()
       -> _extract_all_edges()      # Extracts LINE, LWPOLYLINE, CIRCLE, ARC, HATCH
       -> snap edges (optional)      # 1-4s
       -> unary_union(edges)         # 37-58s <-- BOTTLENECK
       -> polygonize(merged)         # <1s
```

### Root Cause
`unary_union()` has O(n log n) to O(n²) complexity depending on geometry overlap. With 3,000+ edges, the algorithm must check intersection relationships between thousands of line segments.

### Log Evidence
From the provided logs:
- ELLIPSE entities generate debug messages but are NOT processed in `_extract_all_edges()` (not in current code)
- Many tiny segments (0.01-0.09 units) from curve flattening create dense intersection grids
- The deduplication shows 482-925 unique x-coords from ellipse approximations

## Optimization Strategies

### 1. Skip Curved Entities for Content Zone (Recommended - High Impact, Low Effort)

**Current State**: `_extract_all_edges()` processes CIRCLE and ARC entities, flattening them to many small segments.

**Proposal**: Add `include_curves` parameter (default `False` for content zone):

```python
def _extract_all_edges(
    block_def: BlockLayout,
    include_curves: bool = True,  # New parameter
) -> list[LineString]:
    # ...
    elif entity_type == "CIRCLE":
        if include_curves:
            edges.extend(_extract_circle_edges(entity))
    elif entity_type == "ARC":
        if include_curves:
            edges.extend(_extract_arc_edges(entity))
```

**Impact**:
- Blocks with 12+ ellipses/circles/arcs could see 400+ fewer edges
- Content zone detection rarely needs curved boundaries (rectangular fixtures)

### 2. STRtree Spatial Clustering (Medium Impact, Medium Effort)

**Concept**: Use Shapely's STRtree to identify spatially clustered edges, then only union edges that actually overlap.

```python
from shapely import STRtree

def _spatial_union(edges: list[LineString]) -> BaseGeometry:
    """Union edges using spatial indexing to reduce intersection checks."""
    if len(edges) < 100:
        return unary_union(edges)

    tree = STRtree(edges)
    # Group edges by spatial overlap using tree.query()
    # Union within groups, then union group results
    clusters = _cluster_overlapping_edges(edges, tree)
    cluster_unions = [unary_union(cluster) for cluster in clusters]
    return unary_union(cluster_unions)
```

**Considerations**:
- STRtree is immutable once created
- Query returns indices, requires mapping back to geometries
- Most effective when geometry is spatially distributed (not all overlapping)

### 3. Higher Arc Flattening Sagitta (Trivial, Low Impact)

**Current**: `ARC_FLATTENING_SAGITTA = 0.1`

**Proposal**: Increase to 0.5 or 1.0 for content zone detection only.

```python
# In geometry.py, for content zone:
CONTENT_ZONE_SAGITTA = 0.5  # Coarser approximation acceptable
```

**Impact**:
- 10mm radius circle: 36 segments -> ~12 segments
- Reduces edge count by ~60% for curved entities
- Acceptable precision loss for bounding-box calculations

### 4. Shapely 2.1+ `disjoint_subset` Method (Low Effort, Requires Version Check)

**Concept**: Use optimized union algorithm for geometries that can be divided into non-intersecting subsets.

```python
from shapely import union_all

def _efficient_union(edges: list[LineString]) -> BaseGeometry:
    # Requires Shapely >= 2.1
    try:
        return union_all(edges, method="disjoint_subset")
    except TypeError:
        # Fallback for older Shapely
        return unary_union(edges)
```

**Impact**: 20-60% faster for spatially distributed geometries.

### 5. Add Curved Entity Filter Setting (GUI Enhancement)

**Proposal**: Add UI toggle "Exclude curves from content zone"

New settings in `constants.py`:
```python
"content_zone_exclude_curves": {
    "min_value": None,
    "max_value": None,
    "default": True,  # Default to excluding curves
    "unit_aware": False,
}
```

Entity types to filter:
- CIRCLE
- ARC
- ELLIPSE (if added in future)
- SPLINE (if added in future)

## Recommendations

### Immediate (No Code Changes)
1. Increase `arc_flattening_sagitta` default from 0.1 to 0.5
2. Document units in GUI tooltips

### Short-term (Simple Code Changes)
1. Add `include_curves=False` parameter to `_extract_all_edges()` for content zone
2. Add GUI toggle "Exclude curves from content zone" (default: enabled)

### Medium-term (Algorithm Improvement)
1. Implement STRtree-based clustering before unary_union
2. Upgrade to Shapely 2.1+ and use `union_all(..., method="disjoint_subset")`

### Performance Thresholds
Consider adding an edge-count-based sagitta adjustment:
```python
if estimated_edge_count > 2000:
    sagitta = max(ARC_FLATTENING_SAGITTA, 0.5)  # Coarser for complex blocks
```

## Next Steps

1. **Prototype curve exclusion**: Add `include_curves` parameter and measure impact on the problematic blocks
2. **Benchmark sagitta values**: Test 0.1, 0.25, 0.5, 1.0 on real-world drawings
3. **Evaluate Shapely version**: Check current Shapely version and test `disjoint_subset` if 2.1+
4. **Create spec**: If results are positive, create implementation spec for GUI toggle

## Sources

- [Shapely STRtree Documentation](https://shapely.readthedocs.io/en/stable/strtree.html)
- [Shapely unary_union Reference](https://shapely.readthedocs.io/en/stable/reference/shapely.unary_union.html)
- [GeoPandas union_all Methods](https://geopandas.org/en/latest/docs/reference/api/geopandas.GeoSeries.union_all.html)
- [GEOS Performance Improvements](https://www.crunchydata.com/blog/performance-improvements-in-geos)
