# Curved Lines Filter Implementation Plan

## Executive Summary
This report provides a detailed implementation plan for adding a "Curved Lines Filter" to the DXF Block Extractor GUI, positioned below the existing Min Area and Min Side filters. The filter will exclude polygons containing curved segments (arcs/circles) from content zone detection, helping users focus on rectangular/rectilinear shapes.

## Table Summary

| Step | Component | File | Description |
|------|-----------|------|-------------|
| 1 | Constants | `app/core/constants.py` | Add default values and validation registry |
| 2 | Types | `app/core/types.py` | Add settings to AppSettings TypedDict |
| 3 | Settings Section | `app/core/settings.py` | Add to SETTINGS_SECTIONS "filters" list |
| 4 | Geometry Logic | `app/core/geometry.py` | Add `_contains_curved_segments()` function |
| 5 | Extractor Params | `app/core/extractor.py` | Add filter params to `extract_blocks()` |
| 6 | Main GUI | `app/main.py` | Add checkbox + amount entry below Min Side |
| 7 | Settings Window | `app/core/settings_window.py` | Add read-only display in Filters tab |
| 8 | Tests | `app/tests/` | Add unit tests for new filter logic |

## Relevant Files

- **`app/core/constants.py`** - Contains all filter constants (defaults, min/max values, validation registry). Lines 273-422 define existing filter constants pattern.
- **`app/core/types.py`** - Contains `AppSettings` TypedDict (lines 274-322) where new filter settings must be added.
- **`app/core/settings.py`** - Contains `SETTINGS_SECTIONS` (lines 52-88) mapping filters to their settings keys.
- **`app/core/geometry.py`** - Contains `_detect_content_zone()` (lines 1069-1316) where filter logic is applied, and `_extract_paint_bucket_regions()` (lines 708-800) which extracts edges.
- **`app/core/extractor.py`** - Contains `extract_blocks()` (lines 975-1706) which passes filter params to geometry functions.
- **`app/main.py`** - Contains GUI filter controls (lines 320-382 for Min Area/Min Side pattern) and extraction worker (lines 565-720).
- **`app/core/settings_window.py`** - Contains Filters tab (lines 539-664) with read-only filter display.
- **`app_docs/005-field-naming-convention.md`** - Naming convention guide for new settings.

## In-Scope

1. Add "Curved Lines Filter" checkbox and amount entry to main window GUI
2. Add curved segment detection logic to geometry module
3. Add filter parameters through extractor to geometry functions
4. Add constants (defaults, validation ranges) following existing patterns
5. Add settings persistence via SettingsManager
6. Add read-only display in Advanced Settings Filters tab
7. Unit tests for curved segment detection

## Out-of-Scope

1. Arc/circle tolerance settings (use a simple boolean "has any curved segment")
2. Partial curve filtering (filter only certain arc angles)
3. Modifications to Excel output format
4. Changes to existing filter behavior
5. GUI redesign or reflow

## Filter Sequencing Analysis

### Current Filter Execution Order (geometry.py `_detect_content_zone()`)

```
1. Entity count threshold check (line 1145) → Early exit if > threshold
2. Edge count estimation (line 1154) → Early exit if > threshold
3. Extract paint-bucket regions (line 1174) → O(n) edges + O(n log n) union
4. Side filter (line 1189) → O(n) - uses GROSS geometry
5. Polygon count threshold check (line 1219) → Early exit
6. Net area calculation (line 1238) → O(n²) - expensive
7. Area filter (line 1249) → O(n) - uses NET area
```

### Optimal Position for Curved Lines Filter

The curved lines filter should be placed **AFTER paint-bucket extraction but BEFORE side filter**:

**Rationale:**
1. Cannot filter before extraction - need polygons to analyze
2. Should filter BEFORE net area calculation (O(n²)) to reduce polygon count
3. Curved detection is O(n) per polygon (iterate edges) - cheap
4. Filtering early reduces work in subsequent expensive operations

### Recommended New Sequence

```
1. Entity count threshold check → Early exit
2. Edge count estimation → Early exit
3. Extract paint-bucket regions
4. **CURVED LINES FILTER** ← NEW (O(n) - filter polygons with curved edges)
5. Side filter (gross geometry)
6. Polygon count threshold check → Early exit
7. Net area calculation (O(n²))
8. Area filter (net geometry)
```

## Implementation Steps

### Step 1: Add Constants (`app/core/constants.py`)

Add after line 311 (after `MIN_SIDE_FILTER_MAX`):

```python
# Curved Lines Filter constants
DEFAULT_CURVED_FILTER_ENABLED: bool = False
"""Default state for curved lines filter (disabled by default)."""

CURVED_FILTER_TOLERANCE: float = 0.01
"""Tolerance for detecting curved segments. Edges with any arc/circle
component within this tolerance are considered curved."""
```

Add to `SETTINGS_VALIDATION_REGISTRY` (after `min_side_filter_amount` entry ~line 422):

```python
    "curved_filter_enabled": {
        "min_value": None,
        "max_value": None,
        "default": False,
        "unit_aware": False,
    },
```

### Step 2: Add Types (`app/core/types.py`)

Add to `AppSettings` TypedDict (after `min_side_filter_amount`, ~line 298):

```python
    curved_filter_enabled: bool
```

### Step 3: Add to Settings Section (`app/core/settings.py`)

Add to `SETTINGS_SECTIONS["filters"]` list (after `min_side_filter_amount`, ~line 63):

```python
        "curved_filter_enabled",
```

### Step 4: Add Geometry Logic (`app/core/geometry.py`)

Add new function after `_extract_paint_bucket_regions()` (~line 801):

```python
def _polygon_has_curved_edges(polygon: Polygon, tolerance: float = 0.01) -> bool:
    """
    Detect if a polygon contains curved (non-straight) edges.

    A polygon is considered to have curved edges if any edge has
    intermediate points that deviate from a straight line by more
    than the tolerance. This detects arcs/circles that were flattened
    during edge extraction.

    Args:
        polygon: List of (x, y) vertices
        tolerance: Maximum deviation from straight line to consider
                   an edge as straight. Default 0.01 drawing units.

    Returns:
        True if polygon contains curved edges, False if all edges
        are straight (within tolerance).
    """
    if len(polygon) < 3:
        return False

    # For each triplet of consecutive vertices, check if middle point
    # deviates from the line connecting first and third points
    vertices = polygon + [polygon[0], polygon[1]]  # Close polygon + one more

    for i in range(len(polygon)):
        p1 = vertices[i]
        p2 = vertices[i + 1]  # Middle point
        p3 = vertices[i + 2]

        # Calculate perpendicular distance from p2 to line p1-p3
        # Using cross product formula: |AB × AC| / |AB|
        ax, ay = p3[0] - p1[0], p3[1] - p1[1]
        bx, by = p2[0] - p1[0], p2[1] - p1[1]

        cross = abs(ax * by - ay * bx)
        line_length = math.sqrt(ax * ax + ay * ay)

        if line_length > 1e-9:
            distance = cross / line_length
            if distance > tolerance:
                return True

    return False
```

Modify `_detect_content_zone()` signature (~line 1069) to add parameter:

```python
def _detect_content_zone(
    block_def: BlockLayout,
    block_bbox: tuple[float, float, float, float],
    abort_event: threading.Event | None = None,
    precision_tolerance: float = 1e-6,
    gap_bridge_tolerance: float = 0.0,
    min_area_filter: float = 0.0,
    min_side_filter: float = 0.0,
    curved_filter_enabled: bool = False,  # NEW
    *,
    polygon_count_threshold: int = POLYGON_COUNT_THRESHOLD,
    line_segment_threshold: int = LINE_SEGMENT_THRESHOLD,
    entity_count_threshold: int = ENTITY_COUNT_THRESHOLD,
) -> ContentZoneData:
```

Add curved filter logic AFTER paint-bucket extraction, BEFORE side filter (~line 1184):

```python
    # Step 0.5: Curved lines filter (uses edge geometry)
    # Applied BEFORE side filter for efficiency
    if curved_filter_enabled:
        pre_curved_count = len(all_shapes)
        all_shapes = [
            s for s in all_shapes
            if not _polygon_has_curved_edges(s)
        ]
        logger.debug(
            f"[{block_name}] Curved filter: {pre_curved_count} -> {len(all_shapes)} polygons"
        )
```

### Step 5: Add Extractor Parameters (`app/core/extractor.py`)

Modify `extract_blocks()` signature (~line 975) to add parameter:

```python
def extract_blocks(
    file_path: str,
    abort_event: threading.Event | None = None,
    *,
    unit_override: int | None = None,
    gap_bridge_enabled: bool = False,
    gap_bridge_amount: float | None = None,
    precision_fix_enabled: bool = True,
    precision_fix_amount: float | None = None,
    min_area_filter_enabled: bool = False,
    min_area_filter_amount: float | None = None,
    min_side_filter_enabled: bool = False,
    min_side_filter_amount: float | None = None,
    curved_filter_enabled: bool = False,  # NEW
    # Early-exit threshold parameters
    polygon_count_threshold: int | None = None,
    line_segment_threshold: int | None = None,
    entity_count_threshold: int | None = None,
) -> ExtractionResult:
```

Pass to `_detect_content_zone()` call (~line 1288):

```python
            content_zone = _detect_content_zone(
                block_def,
                bbox,
                abort_event,
                precision_tolerance,
                gap_bridge_tolerance,
                min_area,
                min_side,
                curved_filter_enabled,  # NEW
                polygon_count_threshold=effective_polygon_threshold,
                line_segment_threshold=effective_line_threshold,
                entity_count_threshold=effective_entity_threshold,
            )
```

### Step 6: Add Main GUI Controls (`app/main.py`)

Add instance variable after `min_side_filter_amount_var` (~line 107):

```python
        # Curved Lines Filter settings
        self.curved_filter_var = ctk.BooleanVar(
            value=self.settings.get("curved_filter_enabled")
        )
```

Add GUI row AFTER Min Side Filter section (~line 382), BEFORE progress bar:

```python
        # Fifth separator
        separator5 = ctk.CTkFrame(self.main_frame, height=1, fg_color="gray50")
        separator5.pack(fill="x", pady=5)

        # Curved Lines Filter row frame
        curved_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        curved_frame.pack(pady=(5, 10))

        self.curved_filter_checkbox = ctk.CTkCheckBox(
            curved_frame,
            text="Curved Lines Filter",
            variable=self.curved_filter_var,
            command=self._on_curved_filter_toggle,
            font=ctk.CTkFont(size=12),
        )
        self.curved_filter_checkbox.pack(side="left", padx=(0, 10))

        # Hint label
        curved_hint = ctk.CTkLabel(
            curved_frame,
            text="(excludes polygons with curved edges)",
            font=ctk.CTkFont(size=10),
            text_color="gray",
        )
        curved_hint.pack(side="left")
```

Add toggle handler (~line 967):

```python
    def _on_curved_filter_toggle(self) -> None:
        """Handle curved filter checkbox toggle."""
        enabled = self.curved_filter_var.get()
        self.logger.debug(f"Curved filter toggled: {enabled}")

        # Sync settings to manager and save
        self._sync_settings_to_manager()
```

Modify `_sync_settings_to_manager()` (~line 1175):

```python
        self.settings.set("curved_filter_enabled", self.curved_filter_var.get())
```

Modify `_extraction_worker()` to get and pass the setting (~line 620):

```python
            # Get curved filter setting
            curved_filter_enabled = self.curved_filter_var.get()
```

And pass to `extract_blocks()` call (~line 660):

```python
                curved_filter_enabled=curved_filter_enabled,
```

### Step 7: Add Settings Window Display (`app/core/settings_window.py`)

Add to `_populate_filters_tab()` AFTER min_side_filter_amount (~line 654):

```python
        self._create_setting_row(
            scroll_frame,
            "curved_filter_enabled",
            "Curved Lines Filter",
            "Excludes polygons containing curved edges (arcs, circles). "
            "Useful for focusing on rectangular shapes only.",
            readonly=True,
        )
```

### Step 8: Add Tests

Create `app/tests/core/test_curved_filter.py`:

```python
"""Tests for curved lines filter functionality."""

import pytest
from core.geometry import _polygon_has_curved_edges


class TestPolygonHasCurvedEdges:
    """Tests for _polygon_has_curved_edges function."""

    def test_rectangle_no_curves(self):
        """Rectangle should not be detected as curved."""
        rect = [(0, 0), (100, 0), (100, 50), (0, 50)]
        assert _polygon_has_curved_edges(rect) is False

    def test_triangle_no_curves(self):
        """Triangle should not be detected as curved."""
        tri = [(0, 0), (50, 100), (100, 0)]
        assert _polygon_has_curved_edges(tri) is False

    def test_arc_approximation_detected(self):
        """Flattened arc should be detected as curved."""
        # Quarter circle approximation with intermediate points
        arc = [
            (0, 0), (10, 0),  # Straight segment
            (20, 2), (28, 6), (34, 12), (38, 20), (40, 30),  # Arc
            (40, 50), (0, 50)  # Straight back
        ]
        assert _polygon_has_curved_edges(arc) is True

    def test_degenerate_polygon(self):
        """Degenerate polygon (< 3 vertices) returns False."""
        assert _polygon_has_curved_edges([]) is False
        assert _polygon_has_curved_edges([(0, 0)]) is False
        assert _polygon_has_curved_edges([(0, 0), (1, 1)]) is False
```

## Recommendations

1. **Default Disabled**: Keep curved filter disabled by default - it's a specialized filter that most users won't need.

2. **No Amount Field**: Unlike area/side filters, the curved filter is boolean (has curves or doesn't). The tolerance is a technical constant, not a user-facing setting.

3. **Tooltip**: Add a clear tooltip explaining that this filter excludes any polygon containing arc or circle segments.

4. **Performance**: The curved detection is O(n) per polygon where n is vertex count - very cheap compared to net area calculation.

## Next Steps

1. Implement Step 1 (constants.py) - Add defaults and validation
2. Implement Step 2 (types.py) - Add to AppSettings
3. Implement Step 3 (settings.py) - Add to sections
4. Implement Step 4 (geometry.py) - Add detection function and filter call
5. Implement Step 5 (extractor.py) - Thread parameter through
6. Implement Step 6 (main.py) - Add GUI controls
7. Implement Step 7 (settings_window.py) - Add read-only display
8. Implement Step 8 - Write unit tests
9. Run `uv run pytest app/tests/` to verify
10. Run `uv run mypy app/` for type checking

## References

- Existing filter patterns: `app/core/constants.py:273-311`
- Settings validation: `app/core/constants.py:367-522`
- GUI filter controls: `app/main.py:320-382`
- Filter execution: `app/core/geometry.py:1069-1316`
- Naming convention: `app_docs/005-field-naming-convention.md`
