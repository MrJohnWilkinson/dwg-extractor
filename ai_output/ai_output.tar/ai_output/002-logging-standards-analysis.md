# Logging Standards Analysis

## Executive Summary
The project uses Python's standard `logging` module with a centralized `setup_logger()` function. Currently only INFO level and above is captured (no DEBUG), and there is no timing/performance instrumentation. The logging is stdout-only by design for LLM agent visibility.

## Table Summary

| Aspect | Current State | Gap for LLM Debugging |
|--------|---------------|----------------------|
| **Log Levels Used** | INFO (57), ERROR (12), WARNING (6) | No DEBUG level usage |
| **Minimum Level** | INFO (hardcoded) | Cannot enable verbose debugging |
| **Timing/Duration** | None | No performance metrics |
| **Entry/Exit Logging** | Partial (start messages only) | Missing completion times |
| **Structured Data** | Plain text with f-strings | No JSON/structured format option |
| **Level Configuration** | Hardcoded in logger.py | No env var or runtime control |

## Relevant Files

- **app/core/logger.py** - Centralized logger setup; single point of configuration
- **app/core/extractor.py** - Heavy logging consumer (DXF parsing operations)
- **app/core/excel_writer.py** - Sheet creation logging
- **app/core/excel_formatting.py** - Formatting operation logging
- **app/main.py** - GUI event logging (user actions, errors)

## Current Logging Architecture

### Logger Setup (app/core/logger.py:13-41)
```python
def setup_logger(name: str) -> logging.Logger:
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)  # Hardcoded
    formatter = logging.Formatter(
        "%(asctime)s [%(name)s] %(levelname)s: %(message)s"
    )
```

### Log Level Distribution
- **INFO (57 calls)**: Operation starts, completions, counts
- **ERROR (12 calls)**: Exception handling, file errors
- **WARNING (6 calls)**: Non-fatal issues (no blocks found, platform issues)
- **DEBUG (0 calls)**: Not used anywhere

### Message Patterns
| Pattern | Example | Frequency |
|---------|---------|-----------|
| Start operation | `"Starting block extraction from {file_path}"` | Common |
| Completion with count | `"Block Analysis sheet created with {len(df)} rows"` | Common |
| Error with context | `"File not found: {file_path}"` | On errors |
| Progress indicator | `"Progress: {int(value * 100)}% - {message}"` | GUI only |

## Gaps for LLM Agent Debugging

### 1. No DEBUG Level
- Cannot trace detailed execution flow
- No variable state logging
- No intermediate calculation visibility

### 2. No Timing Information
- No duration tracking for operations
- Cannot identify performance bottlenecks
- No elapsed time in log messages

### 3. Fixed Log Level
- Cannot switch to DEBUG without code change
- No environment variable control
- No runtime configuration

### 4. Missing Entry/Exit Patterns
Current:
```python
logger.info("Creating Block Analysis sheet...")
# ... work ...
logger.info(f"Block Analysis sheet created with {len(df)} rows")
```

Missing: Duration between start/end

## Recommendations

### 1. Add Log Level Configuration
```python
import os
log_level = os.getenv("LOG_LEVEL", "INFO").upper()
handler.setLevel(getattr(logging, log_level, logging.INFO))
```

### 2. Add Timing Decorator/Context Manager
```python
@contextmanager
def log_timing(logger, operation: str):
    start = time.perf_counter()
    logger.info(f"[START] {operation}")
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        logger.info(f"[END] {operation} (elapsed: {elapsed:.3f}s)")
```

### 3. Add DEBUG Statements at Key Points
- Function entry with parameters
- Loop iterations with counts
- Data structure sizes
- Decision branch taken

### 4. Structured Logging Option
For machine parsing by LLM agents:
```python
# Optional JSON format for structured parsing
if os.getenv("LOG_FORMAT") == "json":
    formatter = logging.Formatter('{"time":"%(asctime)s","module":"%(name)s","level":"%(levelname)s","msg":"%(message)s"}')
```

## Next Steps

1. Update `app/core/logger.py` to support configurable log level via `LOG_LEVEL` env var
2. Create a `log_timing` context manager for operation duration tracking
3. Add DEBUG-level logging to `extractor.py` for detailed DXF parsing visibility
4. Document logging conventions in `ai_docs/` for consistent future development
