# Dual-Stage Filter Architecture Analysis

## Executive Summary

The proposed dual-stage filter architecture separates **entity-level pre-filtering** (before `unary_union`) from **polygon-level post-filtering** (after `polygonize`). This approach can reduce the unary_union bottleneck by 30-70% while maintaining accurate polygon validation. The key insight: pre-filters reduce computational cost, post-filters ensure correctness. Both stages serve distinct purposes and should coexist.

## Table Summary

| Stage | Filter Type | Operates On | When Applied | Purpose | Performance Impact |
|-------|-------------|-------------|--------------|---------|-------------------|
| **PRE** | Curved Entity Filter | CIRCLE, ARC entities | Before edge extraction | Reduce edge count | -30-50% edges |
| **PRE** | Short Line Filter | LINE entities < threshold | Before edge extraction | Remove detail lines | -10-30% edges |
| **POST** | Curved Polygon Filter | Polygon vertices | After polygonize | Validate straight edges | Correctness check |
| **POST** | Side Filter | Polygon perimeter | After polygonize | Validate minimum side | Correctness check |
| **POST** | Area Filter | Polygon net area | After net area calc | Validate minimum area | Correctness check |

### Cost-Benefit Matrix

| Optimization | Implementation Effort | Risk Level | Estimated Speedup |
|--------------|----------------------|------------|-------------------|
| Curved entity pre-filter (CIRCLE/ARC skip) | Low | Low | 30-50% |
| Short line pre-filter (length threshold) | Low | Medium | 10-30% |
| Both pre-filters combined | Low | Medium | 40-70% |
| Higher sagitta for remaining curves | Trivial | Low | Additional 10-20% |

## Relevant Files

- **`app/core/geometry.py:658-706`** - `_extract_all_edges()` - Entity extraction point where pre-filters would be applied
- **`app/core/geometry.py:708-800`** - `_extract_paint_bucket_regions()` - Contains the `unary_union` bottleneck at line 778
- **`app/core/geometry.py:1069-1316`** - `_detect_content_zone()` - Orchestrates the full pipeline, applies post-filters
- **`ai_output/079-curved-lines-filter-implementation-plan.md`** - Existing plan for post-filter curved polygon detection
- **`ai_output/080-filter-sequence-reordering-analysis.md`** - Documents why filters cannot move before union (but pre-filters CAN)

## Conceptual Distinction: Pre-Filter vs Post-Filter

### Pre-Filter (Entity-Level)
```
Input: Raw DXF entities (LINE, CIRCLE, ARC, LWPOLYLINE, HATCH)
Question: "Should I include this entity's edges in the union?"
Decision: Based on ENTITY properties (type, length, etc.)
Effect: Fewer edges → faster unary_union
```

### Post-Filter (Polygon-Level)
```
Input: Polygons from polygonize()
Question: "Is this polygon valid for content zone consideration?"
Decision: Based on POLYGON properties (side lengths, curvature, area)
Effect: Fewer candidates → faster subsequent operations
```

**Critical Insight**: These are fundamentally different operations. Post-filters CANNOT move before union because polygons don't exist yet. But PRE-filters operate on raw entities and CAN be applied before edge extraction.

## Proposed Dual-Stage Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 1: Pre-Filtering (O(n) - cheap, reduces union input)                  │
├─────────────────────────────────────────────────────────────────────────────┤
│ 1. Entity count threshold check → Early exit if > 1000 entities            │
│ 2. Edge count estimation        → Early exit if > 5000 estimated edges     │
│                                                                              │
│ 3. ──NEW── ENTITY PRE-FILTER in _extract_all_edges():                       │
│    ├─ Skip CIRCLE entities (if exclude_curved_entities=True)               │
│    ├─ Skip ARC entities (if exclude_curved_entities=True)                  │
│    └─ Skip LINE entities where length < short_line_threshold               │
└─────────────────────────────────────────────────────────────────────────────┘
                                   ↓
┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 2: Paint Bucket Extraction (EXPENSIVE - now with fewer edges)         │
├─────────────────────────────────────────────────────────────────────────────┤
│ 4. Edge snapping (optional)     → O(n) - precision fix or gap bridge       │
│ 5. unary_union()                → O(n log n) - NOW FASTER due to fewer n   │
│ 6. polygonize()                 → O(n) - creates closed polygons           │
└─────────────────────────────────────────────────────────────────────────────┘
                                   ↓
        ╔═══════════════════════════════════════════════════════════════╗
        ║  POLYGONS NOW EXIST - Post-Filters validate correctness       ║
        ╚═══════════════════════════════════════════════════════════════╝
                                   ↓
┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 3: Post-Filtering (validate polygon properties)                       │
├─────────────────────────────────────────────────────────────────────────────┤
│ 7. ──EXISTING── Curved polygon filter → Polygons with curved edges         │
│ 8. ──EXISTING── Side filter          → Polygons with short sides           │
│ 9. Polygon count threshold check     → Early exit if > 500                 │
│ 10. _calculate_net_areas()           → O(n²) - now with fewer polygons     │
│ 11. ──EXISTING── Area filter         → Polygons below minimum area         │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Best Practice Implementation

### Pre-Filter 1: Curved Entity Exclusion

**Implementation**: Modify `_extract_all_edges()` signature and logic

```python
def _extract_all_edges(
    block_def: BlockLayout,
    exclude_curved_entities: bool = False,  # NEW
) -> list[LineString]:
    edges: list[LineString] = []

    for entity in block_def:
        entity_type = entity.dxftype()

        # PRE-FILTER: Skip curved entity types entirely
        if exclude_curved_entities and entity_type in ("CIRCLE", "ARC"):
            continue  # Don't flatten, don't extract - skip entirely

        if entity_type == "LINE":
            # ... existing LINE extraction
        elif entity_type in ("LWPOLYLINE", "POLYLINE"):
            # ... existing POLYLINE extraction
        elif entity_type == "CIRCLE":
            edges.extend(_extract_circle_edges(entity))
        elif entity_type == "ARC":
            edges.extend(_extract_arc_edges(entity))
        elif entity_type == "HATCH":
            edges.extend(_extract_hatch_boundary_edges(entity))

    return edges
```

**Impact Analysis**:
- A single CIRCLE becomes ~36 LineString edges (at default sagitta=0.1)
- Blocks with 10 circles = 360 fewer edges in unary_union
- Very low risk: if content zone IS circular, user can disable the pre-filter

### Pre-Filter 2: Short Line Exclusion

**Implementation**: Add length-based filtering for LINE entities

```python
def _extract_all_edges(
    block_def: BlockLayout,
    exclude_curved_entities: bool = False,
    short_line_threshold: float = 0.0,  # NEW: 0 = disabled
) -> list[LineString]:
    edges: list[LineString] = []

    for entity in block_def:
        entity_type = entity.dxftype()

        if entity_type == "LINE":
            start = entity.dxf.start
            end = entity.dxf.end

            # PRE-FILTER: Skip short LINE entities
            if short_line_threshold > 0:
                length = math.sqrt(
                    (end.x - start.x)**2 + (end.y - start.y)**2
                )
                if length < short_line_threshold:
                    continue  # Skip this short line

            edges.append(LineString([(start.x, start.y), (end.x, end.y)]))
        # ... rest of extraction
```

**Threshold Determination**:
- Could be absolute (e.g., 1.0 drawing units)
- Could be relative to block bounding box (e.g., 1% of smallest dimension)
- Recommendation: Use absolute threshold with sensible default (e.g., 0.5 units)

**Risk Analysis**:
| Threshold | Risk | Use Case |
|-----------|------|----------|
| 0.0 (disabled) | None | Default - no filtering |
| 0.5 units | Low | Filters very small detail lines |
| 2.0 units | Medium | Aggressive filtering, may lose small features |
| 5.0+ units | High | Only for very large-scale content zones |

### Why Keep Post-Filters Too?

Even with pre-filters, post-filters remain valuable:

1. **Curved Polygon Post-Filter**: Catches curves from LWPOLYLINE bulges and HATCH boundaries (which aren't filtered by CIRCLE/ARC pre-filter)

2. **Side Post-Filter**: Validates the ACTUAL polygon geometry. A polygon might be formed by many LINE entities where the shortest side is still too small.

3. **Defense in Depth**: Pre-filters optimize performance; post-filters ensure correctness.

**Example Scenario**:
```
Block contains:
- 20 CIRCLE entities (decorative)
- 50 short LINE entities (dimension lines)
- 4 LWPOLYLINE entities forming the main rectangle

Pre-filter removes: CIRCLE + short LINE → 70 fewer entities processed
Post-filter validates: The 4 LWPOLYLINE polygons → ensures valid content zone
```

## Semantic Clarity: Filter Naming

To avoid confusion, use distinct names:

| Filter | Stage | Setting Name | GUI Label |
|--------|-------|--------------|-----------|
| Curved Entity Pre-Filter | PRE | `prefilter_exclude_curves` | "Skip Curved Entities" |
| Short Line Pre-Filter | PRE | `prefilter_short_line_threshold` | "Min Line Length" |
| Curved Polygon Post-Filter | POST | `curved_filter_enabled` | "Curved Lines Filter" |
| Side Post-Filter | POST | `min_side_filter_enabled` | "Min Side Filter" |
| Area Post-Filter | POST | `min_area_filter_enabled` | "Min Area Filter" |

## Performance Estimation

Based on log analysis from reports 078/080:

| Block | Original Edges | After Pre-Filters | Estimated Union Time |
|-------|---------------|-------------------|---------------------|
| Stockroom_Hook | 1,154 | ~700 (-40%) | ~15s (was 37s) |
| FreshProduce_Scoop | 3,098 | ~1,500 (-50%) | ~25s (was 58s) |

**Compound Effect**: Fewer edges → faster union → fewer polygons → faster net area calc

## Implementation Recommendations

### Phase 1: Quick Win (Low Effort)
1. Add `exclude_curved_entities` parameter to `_extract_all_edges()`
2. Wire through `_extract_paint_bucket_regions()` and `_detect_content_zone()`
3. Add simple checkbox in Advanced Settings: "Skip Curved Entities for Content Zone"
4. Default: Disabled (preserve existing behavior)

### Phase 2: Enhanced (Medium Effort)
1. Add `short_line_threshold` parameter
2. Add GUI control with reasonable default (0.5 units, disabled)
3. Add tooltip explaining when to use it

### Phase 3: Full Implementation (Complete)
1. Implement curved polygon post-filter (plan 079)
2. Document the dual-stage architecture in user guide
3. Add per-filter timing logs for diagnostics

## Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Content zone IS a circle | User disables "Skip Curved Entities" pre-filter |
| Short lines form critical boundary | User sets threshold to 0 or adjusts value |
| Confusion between pre/post filters | Clear GUI labeling and tooltips |
| Over-filtering produces no polygons | Fallback: retry without pre-filters |

### Fallback Strategy (Advanced)

```python
def _detect_content_zone_with_fallback(..., prefilter_curves=True, prefilter_short=0.5):
    # Try with pre-filters first (fast path)
    result = _detect_content_zone(..., prefilter_curves, prefilter_short)

    if result.status != "found":
        # Retry without pre-filters (slow but thorough)
        logger.info("No content zone found, retrying without pre-filters")
        result = _detect_content_zone(..., prefilter_curves=False, prefilter_short=0.0)

    return result
```

## Next Steps

1. **Implement curved entity pre-filter** - Highest ROI, lowest risk
2. **Benchmark with real files** - Measure actual speedup on problematic blocks
3. **Implement short line pre-filter** - If additional speedup needed
4. **Implement curved polygon post-filter** - Per existing plan 079
5. **Add GUI controls** - Simple Advanced Settings checkboxes
6. **Document dual-stage approach** - User guide explaining when to use each filter

## Conclusion

The dual-stage filter architecture is the **best practice approach** because:

1. **Separation of Concerns**: Pre-filters optimize, post-filters validate
2. **Compositional**: Each filter is independent and stackable
3. **Safe Defaults**: All pre-filters disabled by default
4. **User Control**: Power users can tune for their specific drawings
5. **Measurable**: Clear timing logs show impact of each stage

This is superior to trying to move existing filters earlier (architecturally impossible) or adding complex heuristics to the union algorithm itself.
