# Filter Sequence Reordering Analysis

## Executive Summary

Moving the curved lines filter and side filter BEFORE the `_extract_paint_bucket_regions()` unary union operation is **NOT architecturally possible** without fundamentally changing what these filters do. The filters operate on **polygon properties** (side lengths, edge curvature), but polygons only exist AFTER the expensive unary union + polygonize step. However, alternative optimizations exist that can reduce processing time while maintaining correct semantics.

## Table Summary

| Filter Type | Current Position | Can Move Before Union? | Reason |
|-------------|------------------|------------------------|--------|
| Curved Lines Filter | After paint-bucket | **No** | Needs polygon vertices to detect deviation from straight lines |
| Side Filter | After paint-bucket | **No** | Needs closed polygon perimeter to calculate shortest side |
| Area Filter | After net area calc | **No** | Needs polygon geometry for area calculation |
| Entity Count Threshold | Before paint-bucket | Already there ✓ | Counts entities without geometry |
| Edge Count Estimation | Before paint-bucket | Already there ✓ | Estimates edges without geometry |
| **Entity Type Filter** (NEW) | Before paint-bucket | **Yes** | Can skip CIRCLE/ARC entities at edge extraction |

## Relevant Files

- **`app/core/geometry.py:708-800`** - `_extract_paint_bucket_regions()` - the expensive unary_union operation
- **`app/core/geometry.py:1069-1316`** - `_detect_content_zone()` - orchestrates the detection pipeline
- **`app/core/geometry.py:87-164`** - `calculate_shortest_straight_side()` - side filter logic
- **`ai_output/079-curved-lines-filter-implementation-plan.md`** - Proposed curved filter implementation

## Current Execution Pipeline

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 1: Pre-checks (O(n) - fast)                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│ 1. Entity count threshold check → Early exit if > 1000 entities             │
│ 2. Edge count estimation       → Early exit if > 5000 estimated edges       │
└─────────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 2: Paint Bucket Extraction (EXPENSIVE)                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│ 3. _extract_all_edges()         → O(n) - extracts LINE, POLYLINE, CIRCLE,   │
│                                    ARC, HATCH edges as LineStrings          │
│ 4. Edge snapping (optional)     → O(n) - precision fix or gap bridge        │
│ 5. unary_union()                → O(n log n) to O(n²) - THE BOTTLENECK      │
│ 6. polygonize()                 → O(n) - creates closed polygons            │
└─────────────────────────────────────────────────────────────────────────────┘
                                    ↓
         ╔═══════════════════════════════════════════════════════╗
         ║  POLYGONS NOW EXIST - Filters can operate here        ║
         ╚═══════════════════════════════════════════════════════╝
                                    ↓
┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 3: Post-Polygon Filtering                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│ 7. Side filter                  → O(n) per polygon - filters by shortest    │
│                                    straight side (GROSS geometry)           │
│ 8. Polygon count threshold      → Early exit if > 500 polygons              │
│ 9. _calculate_net_areas()       → O(n²) - calculates net areas              │
│ 10. Area filter                 → O(n) - filters by NET area                │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Why Filters Cannot Move Before Unary Union

### The Fundamental Problem

Filters operate on **polygon properties**:

| Filter | Required Property | How It's Computed |
|--------|-------------------|-------------------|
| Side Filter | Shortest straight side length | Iterate all polygon edges, merge collinear segments, find minimum |
| Curved Filter | Edge deviation from straight line | Compare vertex triplets for perpendicular deviation |
| Area Filter | Polygon net area | Shapely area calculation |

**Polygons are the OUTPUT of the paint-bucket algorithm, not the input.**

### Edge ≠ Polygon Relationship

```
Input Edges:           After unary_union + polygonize:

    ─────────────            ┌────┬────┐
    │         │              │ A  │ B  │
    ─────┼─────              └────┴────┘
    │         │
    ─────────────         Creates 2 polygons from 7 edges
```

- The shared edge between polygons A and B participates in BOTH polygons
- Removing an edge based on one polygon would destroy the other
- No way to know which polygon an edge will form until after polygonize

### Curved Entity ≠ Curved Polygon

A polygon is "curved" if its VERTICES deviate from straight lines. This is different from whether the source ENTITIES were curved:

```
Scenario: Room with curved alcove

    ┌──────────────────┐
    │                  │
    │            ╭─────┘   ← ARC entity creates curved polygon edge
    │            │
    └────────────┘

The ARC is part of the room's boundary.
Excluding ARC entities would break the room polygon.
```

## What CAN Be Optimized

### Option 1: Entity-Type Pre-Filter (NEW capability)

Add a new filter that operates at the ENTITY level (before edge extraction):

```python
# In _extract_all_edges(), skip certain entity types
def _extract_all_edges(block_def, exclude_circles=False, exclude_arcs=False):
    for entity in block_def:
        entity_type = entity.dxftype()

        if entity_type == "CIRCLE" and exclude_circles:
            continue  # Skip circle edge extraction
        if entity_type == "ARC" and exclude_arcs:
            continue  # Skip arc edge extraction

        # ... existing edge extraction
```

**Semantic Difference:**
- "Curved polygon filter" = exclude polygons whose edges deviate from straight lines
- "Curved entity filter" = don't extract edges from CIRCLE/ARC entities at all

| Approach | When Applied | What It Does | Use Case |
|----------|--------------|--------------|----------|
| Entity-Type Filter | Before union | Skips edge extraction for certain entity types | User knows curved entities aren't relevant |
| Curved Polygon Filter | After union | Filters polygons with curved edges | User wants only rectilinear shapes |

### Option 2: Closed LWPOLYLINE Pre-Check

For closed LWPOLYLINE entities, we know the polygon BEFORE the unary union:

```python
# Pre-filter closed polylines by shortest side BEFORE adding their edges
for entity in block_def:
    if entity.dxftype() == "LWPOLYLINE" and entity.closed:
        vertices = [(p[0], p[1]) for p in entity.get_points()]
        if calculate_shortest_straight_side(vertices) < min_side_filter:
            continue  # Don't extract edges from this polyline
```

**Limitation:** Only works for self-contained polylines. Doesn't help with:
- Polygons formed by multiple LINE entities
- Polygons at entity intersections

### Option 3: Spatial Indexing for Unary Union (Advanced)

The unary_union bottleneck could be optimized with spatial indexing:

```python
# Use STRtree for faster intersection detection
from shapely import STRtree

tree = STRtree(edges)
# Process in spatial chunks to reduce worst-case complexity
```

This is a deeper optimization that doesn't change filter sequencing.

## Recommended Filter Sequence

Based on this analysis, the optimal sequence is:

```
1. Entity count threshold check    → O(n), early exit
2. Edge count estimation           → O(n), early exit
3. [NEW] Entity-type pre-filter    → O(n), skip CIRCLE/ARC if enabled
4. Extract paint-bucket regions    → O(n log n) - reduced edge count
5. [NEW] Curved lines filter       → O(n) per polygon, before side filter
6. Side filter                     → O(n) per polygon, uses gross geometry
7. Polygon count threshold check   → Early exit
8. Net area calculation            → O(n²), reduced polygon count
9. Area filter                     → O(n), uses net area
```

The curved lines filter slots in AFTER paint-bucket extraction but BEFORE side filter, as proposed in plan 079. This is optimal because:
- Curved detection is O(n) per polygon (cheap)
- Filtering early reduces work in subsequent operations
- Cannot filter before extraction without changing semantics

## Recommendations

1. **Keep current architecture** - the filter sequence in plan 079 is correct
2. **Consider adding entity-type pre-filter** as a separate setting (not the same as curved polygon filter)
3. **Accept that unary_union is the architectural bottleneck** - it's required for accurate polygon detection
4. **Document the semantic difference** between entity-type filtering and polygon-property filtering

## Next Steps

1. Implement curved lines filter as specified in plan 079 (position 5 in optimized sequence)
2. Optionally add entity-type pre-filter as a separate "Exclude Curved Entities" checkbox
3. Monitor performance with real-world DXF files to identify if further optimization is needed
4. Consider STRtree spatial indexing if unary_union remains a bottleneck after filtering improvements
