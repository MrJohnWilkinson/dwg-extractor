# Content Zone Processing Performance Optimization Report

## Executive Summary
The `unary_union()` operation in Shapely consumes 93-96% of content zone processing time, with complex blocks taking 43-69 seconds for geometry operations that ultimately yield **zero usable results**. The highest-impact optimization is implementing early-exit checks before expensive geometry operations, potentially eliminating all wasted computation for blocks that cannot contain valid content zones.

## Table Summary

| Block Name | Edges | Union Time | Total Time | Result | Wasted? |
|------------|-------|------------|------------|--------|---------|
| Stockroom_Hook_SafetyVestRail | 1,154 | 41.25s (96%) | 43.0s | 0 polygons | Yes |
| FreshProduce_ScoopWeighPottles_Wood | 3,098 | 64.68s (93%) | 69.4s | 0 polygons | Yes |

| Optimization | Impact | Effort | Description |
|-------------|--------|--------|-------------|
| Early Bounding Box Pre-check | Very High | Low | Skip blocks that can't contain valid content zones |
| Reduce Edge Threshold | High | Trivial | Lower LINE_SEGMENT_THRESHOLD from 5000 to ~1500 |
| STRtree Spatial Indexing | High | Medium | Use spatial index to limit intersection computations |
| Skip Curved Entities | Medium | Low | Exclude ELLIPSE/ARC from content zone detection |
| Cascaded Union Batching | Medium | Medium | Process edges in spatial batches |

## Relevant Files

- **`app/core/geometry.py`** - Contains `_extract_paint_bucket_regions()` (lines 708-800) where `unary_union()` bottleneck occurs, and `_detect_content_zone()` (lines 1069-1316) which orchestrates content zone detection
- **`app/core/extractor.py`** - Main extraction logic calling content zone detection per block (lines 1288-1300)
- **`app/core/constants.py`** - Performance threshold constants: `ENTITY_COUNT_THRESHOLD` (1000), `LINE_SEGMENT_THRESHOLD` (5000), `POLYGON_COUNT_THRESHOLD` (500)

## Performance Bottleneck Analysis

### Time Breakdown from Logs

**Block 1: Stockroom_Hook_SafetyVestRail (43.0s total)**
```
Edge extraction:    ~0.02s
Edge snapping:       1.59s (3.7%)
Unary union:        41.25s (95.9%) <-- BOTTLENECK
Polygonize:          0.10s (0.2%)
Side filtering:      0.01s
```

**Block 2: FreshProduce_ScoopWeighPottles_Wood (69.4s total)**
```
Edge extraction:    ~0.08s
Edge snapping:       4.40s (6.3%)
Unary union:        64.68s (93.2%) <-- BOTTLENECK
Polygonize:          0.11s (0.1%)
Side filtering:      0.01s
```

### Why Both Blocks Yield Zero Results

Both blocks spend enormous computation time only to have **all polygons filtered out**:

1. **Block 1**: 135 paint-bucket regions found → 0 after min_side filter (10.0)
2. **Block 2**: 415 regions → 3 after side filter → 0 after min_area filter (100,000)

The blocks contain many small geometric details (ellipses flattened to hundreds of tiny segments) but no rectangular content zones meeting the filter criteria.

### Why unary_union() Is Slow

The `unary_union()` function computes all intersection points between all edges:
- Complexity: O(n² log n) worst case for n segments
- Block with 3,098 edges: ~9.6 million potential intersection checks
- Many tiny segments (0.01-0.08 units) from ellipse flattening increase intersection density

## Recommendations

### 1. Early Bounding Box Pre-check (Highest Impact, Lowest Effort)

**Problem**: Both blocks cannot possibly contain a valid content zone because their geometry is dominated by small decorative elements.

**Solution**: Before extracting edges, check if the block's bounding box dimensions are large enough:

```python
# In _detect_content_zone(), after getting block_bbox:
block_width = block_bbox[2] - block_bbox[0]
block_height = block_bbox[3] - block_bbox[1]

# If block is too small to contain any valid content zone, skip
min_dimension_needed = min_side_filter * 2  # Need at least 2x min_side
if block_width < min_dimension_needed or block_height < min_dimension_needed:
    logger.debug(f"[{block_name}] Skipping: dimensions too small for content zone")
    return _empty_content_zone_data()
```

**Impact**: Would have skipped Block 1 entirely (700x52 units with min_side=10), saving 43s.

### 2. Lower LINE_SEGMENT_THRESHOLD (High Impact, Trivial Effort)

**Current**: `LINE_SEGMENT_THRESHOLD = 5000`

Both problematic blocks pass this threshold:
- Block 1: 1,154 edges (under 5000)
- Block 2: 3,098 edges (under 5000)

**Recommendation**: Lower to 1,500-2,000 to skip complex blocks earlier.

```python
LINE_SEGMENT_THRESHOLD: int = 1500
```

**Trade-off**: May skip some legitimate content zones, but reduces worst-case processing significantly.

### 3. STRtree Spatial Indexing (High Impact, Medium Effort)

**Problem**: `unary_union()` checks all edge pairs for intersections.

**Solution**: Use Shapely's STRtree to spatially cluster edges, then only union edges that actually overlap:

```python
from shapely import STRtree

def _spatial_union(edges: list[LineString]) -> BaseGeometry:
    """Union edges using spatial indexing to reduce intersection checks."""
    if len(edges) < 100:
        return unary_union(edges)

    tree = STRtree(edges)
    # Build spatial clusters and union within clusters
    # Then union cluster results
    ...
```

**Impact**: Could reduce intersection checks by 80-90% for spatially distributed geometry.

### 4. Skip Curved Entities for Content Zone Detection (Medium Impact)

**Problem**: Ellipses/arcs flatten to hundreds of tiny segments that rarely form rectangular boundaries.

**Solution**: Add option to skip ELLIPSE and ARC entities in `_extract_all_edges()`:

```python
elif entity_type == "ELLIPSE":
    if include_curves:  # New parameter, default False for content zone
        edges.extend(_extract_ellipse_edges(entity))
```

**Impact**: Block 2 has 12+ ELLIPSE entities, each producing ~36 segments. Skipping could reduce edges by 400+.

### 5. Cascaded Union Batching (Medium Impact)

**Problem**: Single `unary_union()` call on thousands of edges.

**Solution**: Process in batches using spatial partitioning:

```python
def _batched_union(edges: list[LineString], batch_size: int = 500) -> BaseGeometry:
    """Process edges in spatial batches to reduce memory pressure."""
    if len(edges) <= batch_size:
        return unary_union(edges)

    # Partition edges into spatial buckets
    # Union each bucket
    # Recursively union bucket results
    ...
```

## Additional Observations

### Current Threshold Behavior

| Threshold | Value | Block 1 | Block 2 | Behavior |
|-----------|-------|---------|---------|----------|
| ENTITY_COUNT_THRESHOLD | 1,000 | Pass | Pass | Both blocks have fewer entities |
| LINE_SEGMENT_THRESHOLD | 5,000 | Pass (1,154) | Pass (3,098) | Both under threshold |
| POLYGON_COUNT_THRESHOLD | 500 | Pass (135) | Pass (415) | Both pass net area calc |

All thresholds are passed, leading to full processing with zero useful output.

### Segment Distribution Indicates Complexity

From the logs, segment distributions show many tiny values (0.01-0.08) from curve flattening:
```
Block 1 segments: [87.0, 0.25, 10.75, 0.01, 0.02, 0.02, 0.02, 0.02, 0.03, ...]
Block 2 segments: [0.02, 0.02, 0.02, 0.03, 0.04, 0.04, 0.05, 0.05, 0.06, ...]
```

A heuristic based on segment size variance could identify decorative blocks early.

## Next Steps

1. **Immediate (Low Effort)**
   - Implement bounding box pre-check in `_detect_content_zone()`
   - Lower `LINE_SEGMENT_THRESHOLD` to 1,500

2. **Short-term (Medium Effort)**
   - Add option to skip curved entities in content zone detection
   - Add segment distribution heuristic for early complexity detection

3. **Future Investigation**
   - Benchmark STRtree spatial indexing approach
   - Profile cascaded union batching with real-world data
   - Consider GEOS 3.11+ features (if available) for improved union performance
