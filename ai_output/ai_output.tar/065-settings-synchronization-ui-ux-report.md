# Settings Synchronization UI/UX Analysis Report

## Executive Summary

The DXF Block Extractor has a critical settings synchronization bug where changes made to numeric filter values in the main GUI (e.g., Gap Bridge amount = 4) are not reflected in the Advanced Settings window. The root cause is incomplete bi-directional synchronization between the main GUI's tkinter variables and the centralized `SettingsManager`. The "Settings" button should be renamed "Advanced Settings" to match the window title, and additional UX improvements can enhance the user experience.

## Table Summary

| Issue | Severity | Root Cause | Recommended Fix |
|-------|----------|------------|-----------------|
| Gap Bridge amount not synced | High | `_sync_settings_to_manager()` only syncs booleans, not amounts | Add amount syncing on entry change |
| Other amount fields not synced | High | Same as above | Sync all numeric filter amounts |
| Button naming mismatch | Low | Button text is "Settings", window title is "Advanced Settings" | Rename button to "Advanced Settings" |
| Read-only stale values | Medium | Advanced Settings reads from stale SettingsManager | Sync before opening, or sync on-demand |
| No reverse sync to main GUI | Medium | Closing Advanced Settings doesn't update main GUI | Refresh main GUI after modal closes |

## Relevant Files

- **app/main.py** (lines 86-107, 754-761, 1067-1084) - Main GUI with filter settings and `_sync_settings_to_manager()` function that has incomplete syncing
- **app/core/settings_window.py** (lines 51-984) - Advanced Settings modal window displaying read-only filter values
- **app/core/settings.py** (lines 91-405) - `SettingsManager` class providing centralized settings storage and validation
- **app/core/constants.py** (lines 367-523) - `SETTINGS_VALIDATION_REGISTRY` defining all settings metadata

## Root Cause Analysis

### The Synchronization Bug

The main GUI stores settings in two places:
1. **Tkinter StringVar/BooleanVar** - For immediate UI binding (e.g., `self.gap_bridge_amount_var`)
2. **SettingsManager** - For persistence and sharing with Advanced Settings

**The bug**: `_sync_settings_to_manager()` (main.py:1067-1084) only syncs:
- Boolean filter flags (`precision_fix_enabled`, `gap_bridge_enabled`, etc.)
- Logging settings (`generate_log_file`, `file_log_level`)

**Missing syncs** (never transferred to SettingsManager):
- `precision_fix_amount`
- `gap_bridge_amount`
- `min_area_filter_amount`
- `min_side_filter_amount`
- `unit_override` (unit selection)

When the user sets Gap Bridge to 4 in main GUI, `self.gap_bridge_amount_var` is updated but `SettingsManager` retains the old value. When Advanced Settings opens, it reads the stale value from `SettingsManager.get("gap_bridge_amount")`.

### Gap Bridge: Same or Different Setting?

**They are the SAME setting.** Both the main GUI's Gap Bridge amount field and the Advanced Settings "Filters" tab display `gap_bridge_amount` from the same `SettingsManager`. The Advanced Settings currently shows this as read-only to prevent dual-editing conflicts.

## Best Practice Solutions (2025)

### 1. Single Source of Truth Pattern

Modern desktop UIs (React-style state management, Qt's Model-View, MVVM) use a **single source of truth** for settings:

**Recommended Architecture:**
```
SettingsManager (single source)
     ↓ reads from
Main GUI Variables (bound to widgets)
     ↑ writes to
Entry/Checkbox Changes (on-change callbacks)
```

**Implementation:**
1. Bind tkinter variables to widget changes via `trace_add("write", callback)`
2. On any change, immediately sync to `SettingsManager`
3. When opening Advanced Settings, values are always current
4. After Advanced Settings closes, refresh main GUI from `SettingsManager`

### 2. Modal Window Best Practices

The current implementation uses a **modal dialog** (`grab_set()` + `wait_window()`), which is the correct approach for settings. This prevents:
- Concurrent editing conflicts
- State desynchronization during editing

**Current behavior is correct** - blocking the main window while Advanced Settings is open prevents confusion.

### 3. Instant Sync vs. Apply/Cancel

Two valid approaches exist:

| Approach | Pros | Cons |
|----------|------|------|
| **Instant sync** | Immediate feedback, simpler mental model | No undo, accidental changes persist |
| **Apply/Cancel** | Explicit save, undo capability | Extra clicks, may forget to save |

**Recommendation**: Keep current Apply/Cancel model for Advanced Settings (already implemented), but ensure:
- Main GUI changes sync instantly to SettingsManager
- Advanced Settings reads fresh values on open
- Main GUI refreshes from SettingsManager after modal closes

### 4. Button Naming Consistency

**Best practice**: UI labels should match destination titles exactly.

Current:
- Button: "Settings"
- Window title: "Advanced Settings"

**Fix**: Rename button to "Advanced Settings" (main.py:177)

## Settings Not Being Synced

### From Main GUI to Advanced Settings (broken)

| Setting | Main GUI Variable | Synced? |
|---------|-------------------|---------|
| `precision_fix_enabled` | `self.precision_fix_var` | Yes |
| `precision_fix_amount` | `self.precision_fix_amount_var` | **NO** |
| `gap_bridge_enabled` | `self.gap_bridge_var` | Yes |
| `gap_bridge_amount` | `self.gap_bridge_amount_var` | **NO** |
| `min_area_filter_enabled` | `self.min_area_filter_var` | Yes |
| `min_area_filter_amount` | `self.min_area_filter_amount_var` | **NO** |
| `min_side_filter_enabled` | `self.min_side_filter_var` | Yes |
| `min_side_filter_amount` | `self.min_side_filter_amount_var` | **NO** |
| `unit_override` | `self.unit_selection_var` | **NO** |
| `generate_log_file` | `self.log_file_var` | Yes |
| `file_log_level` | `self.file_log_level_var` | Yes |

### From Advanced Settings to Main GUI (not implemented)

When Advanced Settings closes (after Apply), the main GUI does not refresh its tkinter variables from `SettingsManager`. This means changes made in Advanced Settings tabs (like Output or Logging settings) won't be visible in main GUI until restart.

## Additional UI/UX Improvements

### Low-Complexity Improvements

1. **Real-time validation feedback** - Show red border on invalid entry immediately, not just on focus-out
2. **Tooltip hints** - Add tooltips to main GUI filter controls explaining what they do
3. **Keyboard shortcuts** - Add Ctrl+Shift+S for "Advanced Settings" access
4. **Status bar** - Show current active filters summary at bottom of main window

### Medium-Complexity Improvements

1. **Settings summary** - Add collapsible panel in main GUI showing all active settings
2. **Preset configurations** - Allow saving/loading named settings profiles
3. **Undo/redo** - Track settings changes with undo capability

### Avoid (Unnecessary Complexity)

1. **Live preview** - Showing extraction preview while changing settings adds significant complexity
2. **Cloud sync** - Settings sync across machines is over-engineering for this app
3. **Multiple settings windows** - Keep single modal pattern

## Recommendations

### Immediate Fixes (Bug)

1. **Expand `_sync_settings_to_manager()`** to include all amount fields:
   ```python
   def _sync_settings_to_manager(self) -> None:
       # Boolean flags (existing)
       self.settings.set("precision_fix_enabled", self.precision_fix_var.get())
       # ... other booleans ...

       # ADD: Numeric amounts
       try:
           self.settings.set("precision_fix_amount", float(self.precision_fix_amount_var.get()))
           self.settings.set("gap_bridge_amount", float(self.gap_bridge_amount_var.get()))
           self.settings.set("min_area_filter_amount", float(self.min_area_filter_amount_var.get()))
           self.settings.set("min_side_filter_amount", float(self.min_side_filter_amount_var.get()))
       except ValueError:
           pass  # Skip invalid values
   ```

2. **Call sync before opening Advanced Settings** (main.py:754):
   ```python
   def _open_advanced_settings(self) -> None:
       self._sync_settings_to_manager()  # ADD THIS LINE
       window = AdvancedSettingsWindow(self, self.settings)
       self.wait_window(window)
   ```

3. **Rename button** (main.py:177):
   ```python
   text="Advanced Settings",  # was "Settings"
   ```

### Short-Term Improvements

1. Add variable trace callbacks for instant sync:
   ```python
   self.gap_bridge_amount_var.trace_add("write", lambda *_: self._sync_settings_to_manager())
   ```

2. Refresh main GUI after Advanced Settings closes:
   ```python
   def _open_advanced_settings(self) -> None:
       self._sync_settings_to_manager()
       window = AdvancedSettingsWindow(self, self.settings)
       self.wait_window(window)
       self._refresh_from_settings()  # NEW: Update tkinter vars
   ```

### Architecture Consideration

Consider removing duplicate state storage. Instead of storing values in both tkinter variables AND SettingsManager, use SettingsManager as the single source and bind tkinter variables to it via wrappers. This eliminates sync issues entirely.

## Next Steps

1. Fix the immediate sync bug (add amount fields to `_sync_settings_to_manager()`)
2. Rename "Settings" button to "Advanced Settings"
3. Add sync call before opening Advanced Settings window
4. Add main GUI refresh after Advanced Settings closes
5. (Optional) Implement trace callbacks for instant sync
6. (Optional) Add tooltip hints to main GUI controls
