# Plan Review: Extract CIRCLE, ARC, and HATCH Boundary Edges

## Executive Summary

The plan in `ai_output/004-extract-circle-arc-hatch-edges-plan.md` correctly identifies the need to extend `_extract_all_edges()` but proposes custom implementations where ezdxf provides superior built-in methods. The plan's manual approach to arc discretization and HATCH parsing misses key ezdxf features (`flattening()`, `from_hatch()`) that would produce more accurate results with less code and better maintainability.

## Table Summary

| Plan Element | Proposed Approach | Recommended Approach | Impact |
|--------------|-------------------|---------------------|--------|
| CIRCLE discretization | Custom `_discretize_arc()` with fixed 32 segments | `entity.flattening(sagitta=0.1)` | High - adaptive resolution, mathematically accurate |
| ARC discretization | Custom `_discretize_arc()` with fixed segments | `entity.flattening(sagitta=0.1)` | High - handles all angles correctly |
| ARC_SEGMENT_COUNT | Fixed 32 segments | Sagitta-based (distance) | Medium - large circles get finer detail |
| HATCH PolylinePath | Manual `path.vertices` iteration | `ezdxf.path.from_hatch()` | High - handles bulge values automatically |
| HATCH EdgePath | Manual `edge.type` string checks | `ezdxf.path.from_hatch()` | High - unified API, all edge types |
| Bulge handling | Not addressed | Handled by `from_hatch()` | Critical - curved polyline segments missed |
| Error handling | try/except per entity type | Built-in methods are robust | Low |

## Relevant Files

- **app/core/geometry.py:375-410** - `_extract_all_edges()` function to modify; correctly identified
- **app/core/constants.py** - Plan proposes `ARC_SEGMENT_COUNT` but sagitta constant is better
- **app/tests/assets/circles_arcs_points.dxf** - Existing test fixture; adequate for CIRCLE/ARC testing
- **app/tests/assets/hatch_test.dxf** - Existing test fixture for HATCH entities

## ezdxf Built-in Methods Analysis

### Circle and Arc Flattening

ezdxf provides `flattening(sagitta: float)` on both CIRCLE and ARC entities:

```python
# Returns Iterator[Vec3] in WCS coordinates
for point in entity.flattening(sagitta=0.1):
    # point.x, point.y available
```

**Advantages over plan's fixed segment approach:**
- **Adaptive resolution**: Sagitta (max distance from arc center to chord center) ensures consistent visual quality regardless of arc size
- **Mathematically correct**: Large circles get more segments, small arcs fewer - matches visual fidelity needs
- **WCS coordinates**: No transformation needed, ready for Shapely
- **Closed polygon for CIRCLE**: Start vertex equals end vertex automatically

**Plan's `ARC_SEGMENT_COUNT = 32` issue:**
- A 10-unit radius circle: each segment spans ~1.96 units (likely fine)
- A 1000-unit radius circle: each segment spans ~196 units (too coarse)
- A 1-unit radius circle: each segment spans ~0.2 units (wasteful precision)

### HATCH Boundary Path Extraction

ezdxf provides `ezdxf.path.from_hatch()`:

```python
from ezdxf.path import from_hatch

for path in from_hatch(hatch_entity):
    # path.flattening(distance=0.1) yields vertices
    for vertex in path.flattening(distance=0.1):
        # vertex.x, vertex.y
```

**Critical missing feature in plan - Bulge Values:**

The plan accesses `path.vertices` directly for PolylinePath:
```python
# Plan's approach (incomplete)
for i in range(len(vertices) - 1):
    edges.append(LineString([vertices[i], vertices[i + 1]]))
```

PolylinePath vertices are `(x, y, bulge)` tuples. Bulge values indicate arc segments in the polyline. Non-zero bulge means the segment between two vertices is curved, not straight. The plan ignores this entirely, causing curved boundary segments to be treated as straight lines.

## Shapely Integration Assessment

The plan correctly uses Shapely's `LineString` for edge representation and `polygonize()` for region detection. However:

**Alternative for CIRCLE (not recommended for edges):**
```python
# Creates a polygon approximation of circle
shapely.Point(center).buffer(radius, quad_segs=16)
```
This is less suitable for edge extraction since we need `LineString` edges, not `Polygon` objects, for the `polygonize()` workflow.

**Current approach is correct:** Flattening curves to LineStrings, then using `polygonize()` on the edge set is the right pattern for the paint-bucket algorithm.

## Recommendations

### 1. Replace Custom Arc Discretization with ezdxf Flattening

**Instead of:**
```python
ARC_SEGMENT_COUNT = 32

def _discretize_arc(center, radius, start_angle, end_angle, segment_count):
    # Custom implementation
```

**Use:**
```python
# In constants.py
ARC_FLATTENING_SAGITTA = 0.1  # Max distance from arc to chord center

# In geometry.py
def _extract_circle_edges(entity) -> list[LineString]:
    points = list(entity.flattening(sagitta=ARC_FLATTENING_SAGITTA))
    edges = []
    for i in range(len(points) - 1):
        edges.append(LineString([(points[i].x, points[i].y),
                                  (points[i+1].x, points[i+1].y)]))
    return edges
```

### 2. Use from_hatch() for HATCH Extraction

**Instead of:**
```python
def _extract_hatch_boundary_edges(entity):
    for path in entity.paths:
        if path.type == "PolylinePath":
            # Manual vertex iteration (misses bulge)
        elif path.type == "EdgePath":
            for edge in path.edges:
                if edge.type == "LineEdge":
                    # ...
```

**Use:**
```python
from ezdxf.path import from_hatch

def _extract_hatch_boundary_edges(entity) -> list[LineString]:
    edges = []
    for path in from_hatch(entity):
        points = list(path.flattening(distance=ARC_FLATTENING_SAGITTA))
        for i in range(len(points) - 1):
            edges.append(LineString([(points[i].x, points[i].y),
                                      (points[i+1].x, points[i+1].y)]))
    return edges
```

### 3. Add Sagitta Constant Instead of Segment Count

```python
# constants.py
ARC_FLATTENING_SAGITTA: float = 0.1
"""Maximum distance from arc center to chord center for flattening.
Smaller values = more segments = higher precision. 0.1 is good for
typical CAD drawings with units in mm or inches."""
```

### 4. Consider make_path() for Unified Handling

For future extensibility, `ezdxf.path.make_path()` can convert many entity types:

```python
from ezdxf.path import make_path

supported = ("LINE", "CIRCLE", "ARC", "ELLIPSE", "SPLINE", "LWPOLYLINE")
if entity.dxftype() in supported:
    path = make_path(entity)
    # Use path.flattening() for all types uniformly
```

## Overall Assessment

| Aspect | Rating | Notes |
|--------|--------|-------|
| Problem Identification | Good | Correctly identifies missing entity types |
| Scope Definition | Good | In-scope/out-of-scope well defined |
| Technical Approach | Needs Revision | Custom discretization inferior to built-in methods |
| HATCH Handling | Critical Gap | Bulge values completely missed |
| Test Plan | Adequate | Coverage plan is reasonable |
| Risk Assessment | Understated | Bulge issue is higher risk than indicated |

**Verdict:** The plan requires revision before implementation. Using ezdxf's built-in `flattening()` and `from_hatch()` methods will produce more accurate results with less code and proper handling of edge cases (bulge values, varying arc sizes).

## Next Steps

1. Revise plan to use `entity.flattening(sagitta)` for CIRCLE and ARC
2. Revise HATCH extraction to use `ezdxf.path.from_hatch()`
3. Replace `ARC_SEGMENT_COUNT` with `ARC_FLATTENING_SAGITTA` constant
4. Add test cases for polyline paths with non-zero bulge values
5. Update test fixture generator to include bulged polyline HATCH boundaries

## Sources

- [Arc - ezdxf 1.4.2 documentation](https://ezdxf.readthedocs.io/en/stable/dxfentities/arc.html)
- [Circle - ezdxf 1.4.2 documentation](https://ezdxf.readthedocs.io/en/stable/dxfentities/circle.html)
- [Path - ezdxf 1.4.2 documentation](https://ezdxf.readthedocs.io/en/stable/path.html)
- [Hatch - ezdxf 1.4.3 documentation](https://ezdxf.readthedocs.io/en/stable/dxfentities/hatch.html)
- [Shapely 2.1.2 documentation](https://shapely.readthedocs.io/en/stable/manual.html)
