# Plan: Remove Parallel Processing from Block Analysis

## Executive Summary

This plan removes the `ThreadPoolExecutor`-based parallel block processing from `extract_blocks()` as recommended in `ai_output/062-parallel-processing-performance-analysis.md`. The parallel implementation introduced in `specs/058-unit-3-parallel-block-processing.md` is fundamentally flawed due to Python's GIL preventing true parallelism for the Python-heavy workload. Reverting to sequential processing will improve stability, simplify code, and potentially improve performance by eliminating thread overhead.

## Table Summary

| Step | File | Action | Risk | Dependencies |
|------|------|--------|------|--------------|
| 1 | `app/core/extractor.py` | Remove `concurrent.futures` imports | None | - |
| 2 | `app/core/extractor.py` | Delete `_analyze_single_block()` function (lines 879-982) | Low | Step 1 |
| 3 | `app/core/extractor.py` | Replace Phase 2 parallel block (lines 1299-1354) with sequential loop | Medium | Steps 1-2 |
| 4 | `app/core/types.py` | Remove `BlockAnalysisResult` TypedDict (lines 274-291) | None | Step 3 |
| 5 | `app/tests/core/extractor/test_extractor_parallel.py` | Update tests for sequential behavior | Low | Step 3 |
| 6 | `specs/058-unit-3-parallel-block-processing.md` | Archive to `specs/archive/` | None | Step 5 |
| 7 | All | Run validation suite | None | Steps 1-6 |

## Relevant Files

- **`app/core/extractor.py:16`** - Import statement for `concurrent.futures` to remove
- **`app/core/extractor.py:879-982`** - `_analyze_single_block()` function to delete (104 lines)
- **`app/core/extractor.py:1299-1354`** - Phase 2 parallel processing block to replace (56 lines)
- **`app/core/types.py:274-291`** - `BlockAnalysisResult` TypedDict to remove (18 lines)
- **`app/tests/core/extractor/test_extractor_parallel.py`** - Test file to update (167 lines)
- **`specs/058-unit-3-parallel-block-processing.md`** - Original spec to archive

## In-Scope

1. **Remove `ThreadPoolExecutor` usage** from `extract_blocks()` Phase 2
2. **Delete `_analyze_single_block()` helper function** - inline logic back into main loop
3. **Remove `BlockAnalysisResult` TypedDict** from types.py
4. **Remove `concurrent.futures` imports** from extractor.py
5. **Update parallel processing tests** to verify sequential behavior and result consistency
6. **Archive the original spec** to `specs/archive/058-unit-3-parallel-block-processing.md`
7. **Maintain existing functionality** - all extraction results must remain identical

## Out-of-Scope

1. **Performance optimizations** - Not adding alternative parallelism approaches
2. **ProcessPoolExecutor migration** - Ruled out due to ezdxf pickling issues
3. **Geometry module changes** - `geometry.py` remains unchanged
4. **Early exit thresholds** - Units 1+2 (constants.py thresholds) stay in place
5. **GUI changes** - No UI modifications required
6. **New features** - Pure removal/reversion only

## Implementation Steps

### Step 1: Remove concurrent.futures imports

**File:** `app/core/extractor.py`
**Line:** 16

Remove the import:
```python
# DELETE this line:
from concurrent.futures import ThreadPoolExecutor, as_completed
```

**Validation:** `uv run mypy app/core/extractor.py` - expect errors (expected, imports used)

---

### Step 2: Delete _analyze_single_block() function

**File:** `app/core/extractor.py`
**Lines:** 879-982 (104 lines)

Delete the entire `_analyze_single_block()` function. This function was extracted specifically for parallel processing and will be inlined back into the main extraction loop.

**Validation:** `uv run mypy app/core/extractor.py` - expect errors (function calls remain)

---

### Step 3: Replace Phase 2 with sequential loop

**File:** `app/core/extractor.py`
**Lines:** 1299-1354

Replace the `ThreadPoolExecutor` block with sequential processing:

```python
# PHASE 2: Sequential block geometry analysis
for block_def in doc.blocks:
    block_name = block_def.name

    # Skip modelspace/paperspace blocks
    if block_name in ("*Model_Space", "*Paper_Space") or block_name.startswith(
        "*Paper_Space"
    ):
        continue

    # Handle anonymous blocks starting with *U (dynamic block instances)
    if block_name.startswith("*U"):
        if block_name in anonymous_to_resolved:
            effective_name = anonymous_to_resolved[block_name]
        else:
            continue  # Skip unresolved *U blocks
    elif block_name.startswith("A$C"):
        if block_name in anonymous_to_resolved:
            effective_name = anonymous_to_resolved[block_name]
        else:
            effective_name = block_name
    elif block_name.startswith("*"):
        continue  # Skip other system blocks
    else:
        effective_name = block_name

    # Count entities
    entity_count = sum(1 for _ in block_def)
    block_entities[effective_name] = entity_count

    # Scan for nested INSERTs
    for entity in block_def:
        if entity.dxftype() == "INSERT":
            nested_name = entity.dxf.name
            if nested_name in anonymous_to_resolved:
                nested_name = anonymous_to_resolved[nested_name]
            if nested_name not in nested_block_parents:
                nested_block_parents[nested_name] = set()
            nested_block_parents[nested_name].add(effective_name)

    # Analyze block geometry
    bbox = _get_block_bounding_box(block_def)
    native_width = round(bbox[2] - bbox[0], 2)
    native_height = round(bbox[3] - bbox[1], 2)

    vertical_points, horizontal_points = _get_intersection_points(block_def)
    vertical_segments = _calculate_segments(vertical_points)
    horizontal_segments = _calculate_segments(horizontal_points)

    block_trimming_data[effective_name] = {
        "native_width": native_width,
        "native_height": native_height,
        "vertical_segments": vertical_segments,
        "horizontal_segments": horizontal_segments,
    }

    # Detect content zone
    content_zone = _detect_content_zone(
        block_def,
        bbox,
        abort_event,
        precision_tolerance,
        gap_bridge_tolerance,
        min_area,
        min_side,
    )
    block_content_zone_data[effective_name] = content_zone

logger.info(f"Analyzed {len(block_entities)} block definitions")
logger.info(f"Analyzed geometry for {len(block_trimming_data)} block definitions")
```

**Key changes:**
- Remove `ThreadPoolExecutor` context manager
- Remove `futures` dictionary and `as_completed()` iterator
- Remove exception handling for `future.result()`
- Update logging messages (remove "parallel" and "workers" references)

**Validation:** `uv run mypy app/core/extractor.py` - should pass

---

### Step 4: Remove BlockAnalysisResult TypedDict

**File:** `app/core/types.py`
**Lines:** 274-291

Delete the `BlockAnalysisResult` class:
```python
# DELETE this entire TypedDict:
class BlockAnalysisResult(TypedDict):
    """..."""
    entity_count: int
    trimming_data: BlockTrimmingData
    content_zone_data: ContentZoneData
    nested_inserts: list[str]
```

Also update the import in `app/core/extractor.py` if `BlockAnalysisResult` is imported there.

**Validation:** `uv run mypy app/core/types.py` - should pass

---

### Step 5: Update test file

**File:** `app/tests/core/extractor/test_extractor_parallel.py`

Rename file to `test_extractor_consistency.py` and update tests:

1. **Remove thread-specific tests:**
   - Remove `TestParallelProcessingThreadSafety.test_multiple_concurrent_extractions`
   - Simplify thread safety verification (no longer testing parallel execution)

2. **Keep result consistency tests:**
   - `test_consistent_results` - verify multiple runs produce identical results
   - `test_with_dynamic_blocks` - verify dynamic block resolution
   - `test_with_nested_blocks` - verify nested block tracking
   - `test_abort_event` - verify abort functionality
   - `test_empty_file` - verify edge case handling
   - `test_block_trimming_data` - verify data structure
   - `test_content_zone_data` - verify content zone detection

3. **Update docstrings** to remove parallel processing references

**Validation:** `uv run pytest app/tests/core/extractor/test_extractor_parallel.py -v`

---

### Step 6: Archive original spec

**Action:** Move spec to archive directory

```bash
mkdir -p specs/archive
mv specs/058-unit-3-parallel-block-processing.md specs/archive/
```

---

### Step 7: Run full validation suite

Execute all validation commands:

```bash
uv run mypy app/                                    # Type checking
uv run pytest app/tests/core/extractor/ -v          # Extractor tests
uv run pytest app/tests/ -v                         # Full test suite
uv run ruff check app/                              # Linting
uv run ruff format app/ --check                     # Format verification
```

## Rollback Plan

If issues arise, the changes can be reverted using git:
```bash
git checkout -- app/core/extractor.py app/core/types.py
git checkout -- app/tests/core/extractor/test_extractor_parallel.py
```

## Expected Outcomes

| Metric | Before | After |
|--------|--------|-------|
| Lines in extractor.py | ~1600 | ~1560 (40 fewer) |
| Lines in types.py | 291 | 273 (18 fewer) |
| Thread safety risks | Medium | None |
| Code complexity | Higher | Lower |
| Performance (small files) | Similar or worse | Baseline |
| Performance (large files) | Marginal gain | Baseline |
| Memory spikes | Possible | None |

## Next Steps

1. Implement Step 1-3 (extractor.py changes)
2. Implement Step 4 (types.py cleanup)
3. Implement Step 5 (test updates)
4. Run Step 7 validation
5. Benchmark extraction time before/after on representative DXF files
6. Commit changes with detailed message referencing this plan
