# Two-Stage Snapping Implementation Plan

## Executive Summary

This plan details a sequenced implementation of the Two-Stage Snapping approach to fix floating-point precision gaps in polygon detection. The solution must handle DXF files with varying unit systems (mm, inches, meters, etc.) by detecting drawing units from the `$INSUNITS` header and applying unit-appropriate snap tolerances. Stage 1 (always-on precision normalization) fixes nanometer-scale floating-point artifacts, while Stage 2 (optional gap bridging) allows users to bridge intentional design gaps.

## Table Summary

| Stage | Tolerance | Default | Unit-Aware | Purpose |
|-------|-----------|---------|------------|---------|
| Stage 1: Precision Fix | 1e-9 to 1e-6 (by unit) | Always ON | Yes | Fix floating-point artifacts |
| Stage 2: Gap Bridge | User-defined (0-1000+) | OFF (0.0) | Yes | Bridge intentional design gaps |

| Unit System | $INSUNITS Value | Stage 1 Tolerance | Rationale |
|-------------|-----------------|-------------------|-----------|
| Unitless | 0 | 1e-6 | Default assumption (mm-like) |
| Inches | 1 | 1e-7 | ~2.5nm, handles inch precision |
| Feet | 2 | 1e-6 | ~0.3 micrometers |
| Miles | 3 | 1e-3 | ~1.6mm, appropriate for scale |
| Millimeters | 4 | 1e-6 | ~1nm, standard CAD precision |
| Centimeters | 5 | 1e-5 | ~0.1 micrometers |
| Meters | 6 | 1e-4 | ~0.1mm, meter-scale precision |
| Kilometers | 7 | 1e-1 | ~100mm, large scale |
| Microinches | 8 | 1e-9 | Sub-nanometer |
| Mils | 9 | 1e-8 | ~0.25nm |

## Relevant Files

- **app/core/geometry.py:465-560** - `_extract_all_edges()` and `_extract_paint_bucket_regions()` where snapping will be applied
- **app/core/constants.py:152-156** - Arc flattening config, pattern for adding tolerance constants
- **app/core/extractor.py** - DXF file loading, needs unit detection addition
- **app/core/types.py** - Type definitions, may need new type for unit info
- **ai_output/011-gap-tolerance-approach-analysis.md** - Source analysis document
- **ai_output/010-spar-gulv-polygon-count-analysis.md** - Root cause analysis of precision errors
- **ai_docs/ezdxf-geometry-reference.md** - ezdxf API reference
- **ai_docs/shapely-geometry-reference.md** - Shapely API reference

## In Scope

1. **Unit Detection** - Read `$INSUNITS` header from DXF files to determine drawing unit system
2. **Stage 1 Implementation** - Always-on coordinate precision normalization with unit-appropriate tolerance
3. **Stage 2 Implementation** - Optional gap bridging with user-configurable tolerance
4. **Constants Module Updates** - New tolerance constants and unit mapping
5. **Unit Tests** - Regression tests for precision error scenarios
6. **Logging** - Debug logging for snap operations and tolerance values used

## Out of Scope

1. **GUI Configuration** - No UI changes for Stage 2 gap tolerance (future enhancement)
2. **Per-Block Tolerance** - Single tolerance per drawing, not per-block customization
3. **3D Coordinate Snapping** - Z-axis snapping (2D operations only)
4. **DXF File Modification** - No writing back snapped coordinates to files
5. **Backward Compatibility Shims** - Old behavior not preserved as option
6. **Stage 2 User Configuration Persistence** - No saving user preferences

## Implementation Sequence

### Unit 1: DXF Unit Detection (constants.py, extractor.py)

**Purpose:** Add infrastructure to detect and map DXF drawing units to appropriate snap tolerances.

**Files to modify:**
- `app/core/constants.py` - Add unit mapping constants
- `app/core/extractor.py` - Add unit detection function

**Implementation:**

```python
# constants.py additions

# DXF $INSUNITS value to unit name mapping
DXF_INSUNITS_MAP: dict[int, str] = {
    0: "unitless",
    1: "inches",
    2: "feet",
    3: "miles",
    4: "millimeters",
    5: "centimeters",
    6: "meters",
    7: "kilometers",
    8: "microinches",
    9: "mils",
    10: "yards",
    11: "angstroms",
    12: "nanometers",
    13: "microns",
    14: "decimeters",
    15: "decameters",
    16: "hectometers",
    17: "gigameters",
    18: "astronomical_units",
    19: "light_years",
    20: "parsecs",
}

# Stage 1: Unit-aware precision snap tolerance
# Values chosen to fix floating-point artifacts without affecting valid geometry
PRECISION_SNAP_TOLERANCE: dict[int, float] = {
    0: 1e-6,   # Unitless: assume mm-like
    1: 1e-7,   # Inches: ~2.5nm
    2: 1e-6,   # Feet: ~0.3um
    3: 1e-3,   # Miles: ~1.6mm
    4: 1e-6,   # Millimeters: ~1nm
    5: 1e-5,   # Centimeters: ~0.1um
    6: 1e-4,   # Meters: ~0.1mm
    7: 1e-1,   # Kilometers: ~100mm
    8: 1e-9,   # Microinches: sub-nm
    9: 1e-8,   # Mils: ~0.25nm
    10: 1e-5,  # Yards: ~9um
    11: 1e-2,  # Angstroms: ~0.01A
    12: 1e-3,  # Nanometers: ~1pm
    13: 1e-3,  # Microns: ~1nm
    14: 1e-5,  # Decimeters: ~1um
    15: 1e-4,  # Decameters: ~1mm
    16: 1e-3,  # Hectometers: ~10cm
    17: 1e-0,  # Gigameters: ~1km
    18: 1e+6,  # AU: ~150km
    19: 1e+9,  # Light years: ~9.5e12km
    20: 1e+10, # Parsecs: ~3.1e13km
}

DEFAULT_PRECISION_SNAP_TOLERANCE: float = 1e-6
"""Fallback tolerance when $INSUNITS not specified or unrecognized."""
```

```python
# extractor.py addition

def _get_drawing_units(doc: Drawing) -> tuple[int, float]:
    """
    Extract drawing units from DXF header and return snap tolerance.

    Reads the $INSUNITS header variable to determine the drawing's
    unit system and returns the appropriate precision snap tolerance.

    Args:
        doc: ezdxf Drawing document

    Returns:
        Tuple of (insunits_value, snap_tolerance) where insunits_value
        is the raw $INSUNITS integer and snap_tolerance is the
        unit-appropriate Stage 1 precision tolerance.
    """
    try:
        insunits = doc.header.get("$INSUNITS", 0)
        tolerance = PRECISION_SNAP_TOLERANCE.get(
            insunits, DEFAULT_PRECISION_SNAP_TOLERANCE
        )
        logger.debug(
            f"Drawing units: $INSUNITS={insunits} "
            f"({DXF_INSUNITS_MAP.get(insunits, 'unknown')}), "
            f"snap_tolerance={tolerance}"
        )
        return (insunits, tolerance)
    except (AttributeError, KeyError):
        logger.debug("$INSUNITS not found, using default tolerance")
        return (0, DEFAULT_PRECISION_SNAP_TOLERANCE)
```

**Tests required:**
- Test detection of various $INSUNITS values
- Test fallback for missing $INSUNITS header
- Test tolerance mapping accuracy

---

### Unit 2: Stage 1 Precision Snapping (geometry.py)

**Purpose:** Apply always-on precision normalization using Shapely `snap()` to fix floating-point artifacts.

**Files to modify:**
- `app/core/geometry.py` - Modify `_extract_paint_bucket_regions()`

**Implementation:**

```python
# geometry.py modifications

from shapely.ops import polygonize, snap, unary_union

def _extract_paint_bucket_regions(
    block_def: BlockLayout,
    abort_event: threading.Event | None = None,
    precision_tolerance: float = 1e-6,
) -> list[Polygon]:
    """
    Extract all visual regions using paint-bucket algorithm.

    Combines all edges (LWPOLYLINE + LINE + CIRCLE + ARC + HATCH) into a
    unified edge set, applies precision snapping to fix floating-point
    artifacts, splits at intersections using unary_union, and finds all
    closed regions using polygonize.

    Args:
        block_def: ezdxf block definition object
        abort_event: Optional threading.Event to signal abort request
        precision_tolerance: Stage 1 snap tolerance for fixing precision errors.
            Should be derived from drawing units via _get_drawing_units().

    Returns:
        List of Polygon objects (coordinate tuples) representing all visual regions.

    Raises:
        GeometryAbortedError: If abort_event is set during processing.
    """
    edges = _extract_all_edges(block_def)

    if not edges:
        return []

    if abort_event and abort_event.is_set():
        raise GeometryAbortedError("Region detection aborted")

    # Merge and split at all intersections
    merged = unary_union(edges)
    if merged.is_empty:
        return []

    # Stage 1: Apply precision snapping to fix floating-point artifacts
    # snap() moves vertices within tolerance to align with reference geometry
    if precision_tolerance > 0:
        merged = snap(merged, merged, precision_tolerance)
        logger.debug(f"Applied Stage 1 precision snap with tolerance={precision_tolerance}")

    line_segments = list(merged.geoms) if hasattr(merged, "geoms") else [merged]
    polygons = list(polygonize(line_segments))

    # Convert to internal Polygon format
    result: list[Polygon] = []
    for poly in polygons:
        if poly.is_valid and not poly.is_empty:
            coords = list(poly.exterior.coords)[:-1]
            result.append([(float(x), float(y)) for x, y in coords])

    logger.debug(f"Found {len(result)} paint-bucket regions")
    return result
```

**Tests required:**
- Test with SPAR Gulv block (should increase from 5 to 7 polygons)
- Test that normal drawings are unaffected
- Test with various tolerance values

---

### Unit 3: Propagate Tolerance Through Call Chain (geometry.py, extractor.py)

**Purpose:** Pass the unit-derived tolerance from document loading through to region detection.

**Files to modify:**
- `app/core/geometry.py` - Update `_detect_content_zone()` signature
- `app/core/extractor.py` - Pass tolerance from document level

**Implementation:**

```python
# geometry.py - update _detect_content_zone signature

def _detect_content_zone(
    block_def: BlockLayout,
    block_bbox: tuple[float, float, float, float],
    abort_event: threading.Event | None = None,
    precision_tolerance: float = 1e-6,
) -> ContentZoneData:
    """
    Detect content zone and calculate trim values.

    ... existing docstring ...

    Args:
        ... existing args ...
        precision_tolerance: Stage 1 snap tolerance derived from drawing units.
    """
    # ... existing code until paint-bucket call ...

    # Use paint-bucket algorithm for accurate region detection
    all_shapes = _extract_paint_bucket_regions(
        block_def, abort_event, precision_tolerance
    )

    # ... rest unchanged ...
```

```python
# extractor.py - pass tolerance when processing blocks

def extract_blocks(
    file_path: str,
    abort_event: threading.Event | None = None,
) -> ExtractionResult:
    """..."""
    # ... existing validation ...

    doc = ezdxf.readfile(file_path)

    # Get drawing units and appropriate snap tolerance
    insunits, precision_tolerance = _get_drawing_units(doc)

    # ... later when processing blocks ...

    content_zone_data = _detect_content_zone(
        block_def,
        block_bbox,
        abort_event,
        precision_tolerance,  # Pass through
    )
```

**Tests required:**
- Integration test with DXF files having different $INSUNITS values
- Verify tolerance propagates correctly

---

### Unit 4: Stage 2 Gap Bridging Infrastructure (constants.py, geometry.py)

**Purpose:** Add optional user-configurable gap bridging for intentional design gaps.

**Files to modify:**
- `app/core/constants.py` - Add gap bridge constant
- `app/core/geometry.py` - Add gap bridging parameter

**Implementation:**

```python
# constants.py addition

GAP_BRIDGE_TOLERANCE: float = 0.0
"""User-configurable tolerance for bridging intentional design gaps.
Default 0.0 (disabled). Set based on drawing scale when needed.
Applied after Stage 1 precision snapping.

Guidelines for setting:
- For mm drawings with ~100 unit gaps: set to 150-200
- For inch drawings with ~5 unit gaps: set to 7-10
- For meter drawings with ~0.2 unit gaps: set to 0.3-0.5

Warning: Large values may incorrectly merge separate features."""
```

```python
# geometry.py - extend _extract_paint_bucket_regions

def _extract_paint_bucket_regions(
    block_def: BlockLayout,
    abort_event: threading.Event | None = None,
    precision_tolerance: float = 1e-6,
    gap_bridge_tolerance: float = 0.0,
) -> list[Polygon]:
    """
    ... existing docstring with updated Args ...

    Args:
        ... existing args ...
        gap_bridge_tolerance: Stage 2 tolerance for bridging intentional gaps.
            Default 0.0 (disabled). Set > 0 to bridge large gaps.
    """
    edges = _extract_all_edges(block_def)

    if not edges:
        return []

    if abort_event and abort_event.is_set():
        raise GeometryAbortedError("Region detection aborted")

    # Merge and split at all intersections
    merged = unary_union(edges)
    if merged.is_empty:
        return []

    # Stage 1: Always apply precision snapping
    if precision_tolerance > 0:
        merged = snap(merged, merged, precision_tolerance)
        logger.debug(f"Applied Stage 1 precision snap: tolerance={precision_tolerance}")

    # Stage 2: Optional gap bridging (user-configured)
    if gap_bridge_tolerance > 0:
        merged = snap(merged, merged, gap_bridge_tolerance)
        logger.debug(f"Applied Stage 2 gap bridge: tolerance={gap_bridge_tolerance}")

    line_segments = list(merged.geoms) if hasattr(merged, "geoms") else [merged]
    polygons = list(polygonize(line_segments))

    # Convert to internal Polygon format
    result: list[Polygon] = []
    for poly in polygons:
        if poly.is_valid and not poly.is_empty:
            coords = list(poly.exterior.coords)[:-1]
            result.append([(float(x), float(y)) for x, y in coords])

    logger.debug(f"Found {len(result)} paint-bucket regions")
    return result
```

**Tests required:**
- Test with gap_bridge_tolerance=0 (no change from Stage 1 only)
- Test with appropriate gap tolerance fixes Frysetorg-style gaps
- Test warning when tolerance seems too large (>10% of block size)

---

### Unit 5: Unit Tests for Precision Snapping (tests/core/test_geometry.py)

**Purpose:** Add comprehensive tests for the two-stage snapping behavior.

**Files to create/modify:**
- `app/tests/core/test_geometry.py` - Add new test cases
- `app/tests/assets/create_precision_gap_test.py` - Create test DXF with known gaps

**Test cases:**

1. **test_stage1_fixes_nanometer_gap** - Verify 3.7nm gap (like SPAR Gulv) is fixed
2. **test_stage1_no_effect_on_clean_geometry** - Verify normal drawings unchanged
3. **test_stage1_unit_aware_tolerance** - Verify correct tolerance for different units
4. **test_stage2_disabled_by_default** - Verify gap_bridge_tolerance=0 has no effect
5. **test_stage2_bridges_large_gaps** - Verify intentional gaps can be bridged
6. **test_tolerance_propagation** - Verify tolerance flows from doc to region detection

```python
# test_geometry.py additions

def test_stage1_fixes_nanometer_gap():
    """Stage 1 should fix floating-point precision gaps."""
    # Create edges with 3.7e-9 gap (like SPAR Gulv)
    edges = [
        LineString([(0, 0), (10, 0)]),
        LineString([(10, 0), (10, 10)]),
        LineString([(10, 10), (0, 10)]),
        LineString([(0, 10), (0, 0)]),
        # Horizontal line with precision error
        LineString([(0, 5), (9.9999999962746, 5)]),  # ~3.7nm short
    ]

    # Without snapping: 1 polygon (gap prevents split)
    merged = unary_union(edges)
    polygons_no_snap = list(polygonize(list(merged.geoms)))
    assert len(polygons_no_snap) == 1

    # With Stage 1 snapping: 2 polygons
    merged = unary_union(edges)
    merged = snap(merged, merged, 1e-6)
    polygons_with_snap = list(polygonize(list(merged.geoms)))
    assert len(polygons_with_snap) == 2


def test_unit_tolerance_mapping():
    """Verify correct tolerance for each unit system."""
    from app.core.constants import PRECISION_SNAP_TOLERANCE

    # MM drawings get 1e-6 tolerance
    assert PRECISION_SNAP_TOLERANCE[4] == 1e-6

    # Meter drawings get 1e-4 tolerance (larger)
    assert PRECISION_SNAP_TOLERANCE[6] == 1e-4

    # Inch drawings get 1e-7 tolerance (smaller)
    assert PRECISION_SNAP_TOLERANCE[1] == 1e-7
```

---

### Unit 6: Integration Testing with Real DXF Files

**Purpose:** Validate end-to-end behavior with actual DXF files.

**Files to modify:**
- `app/tests/core/test_content_zone.py` - Add integration tests

**Test scenarios:**

1. Test with `SPAR Gulv 900x600 H1860` block - verify polygon count increases from 5 to 7
2. Test with drawings in different unit systems
3. Test performance impact of snapping on large drawings

---

## Dependency Graph

```
Unit 1: Unit Detection
    └── Unit 2: Stage 1 Snapping (depends on Unit 1)
        └── Unit 3: Tolerance Propagation (depends on Unit 2)
            └── Unit 4: Stage 2 Gap Bridging (depends on Unit 3)
                └── Unit 5: Unit Tests (depends on Units 1-4)
                    └── Unit 6: Integration Tests (depends on Unit 5)
```

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| snap() creates invalid geometry | Low | Medium | Validate polygons after snap, log warnings |
| Wrong tolerance for unit system | Medium | Low | Comprehensive unit tests, fallback to safe default |
| Performance degradation | Low | Low | snap() is O(n), minimal overhead |
| Regression in existing behavior | Low | High | Test with existing test suite before/after |

## Reference Documentation

- [ezdxf DXF Units Documentation](https://ezdxf.readthedocs.io/en/stable/concepts/units.html)
- [AutoCAD INSUNITS System Variable](https://help.autodesk.com/view/ACD/2025/ENU/?guid=GUID-A58A87BB-482B-4042-A00A-EEF55A2B4FD8)
- [Shapely snap() Function](https://shapely.readthedocs.io/en/2.1.2/reference/shapely.snap.html)
- [Shapely Manual](https://shapely.readthedocs.io/en/stable/manual.html)
- ai_output/011-gap-tolerance-approach-analysis.md - Source requirements
- ai_output/010-spar-gulv-polygon-count-analysis.md - Root cause analysis
- ai_docs/ezdxf-geometry-reference.md - ezdxf API patterns
- ai_docs/shapely-geometry-reference.md - Shapely API patterns

## Validation Checklist

- [ ] Unit 1: `_get_drawing_units()` returns correct tolerance for all $INSUNITS values
- [ ] Unit 2: Stage 1 snap fixes SPAR Gulv 5→7 polygon issue
- [ ] Unit 3: Tolerance propagates from document load to region detection
- [ ] Unit 4: Stage 2 gap bridging works when enabled, no-op when disabled
- [ ] Unit 5: All unit tests pass
- [ ] Unit 6: Integration tests pass with real DXF files
- [ ] Performance: No significant slowdown on large drawings
- [ ] Regression: Existing test suite passes without modification
