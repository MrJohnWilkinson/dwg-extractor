# Block Extraction Discrepancy Analysis: 437 Greenwich DXF

## Executive Summary
The extractor is working correctly. The "missing blocks" issue is due to an incorrect reference list - the user's "actual dxf blocks" list contains 50 blocks that do not exist in the DXF file. The extractor successfully extracts all 52 blocks that are inserted in modelspace.

## Table Summary

| Metric | Count | Notes |
|--------|-------|-------|
| Block definitions in file | 54 | Excluding `*Model_Space`, `*Paper_Space` |
| Blocks inserted in modelspace | 52 | What extractor counts |
| Blocks extracted correctly | 52 | 100% match |
| Blocks in user's "actual" list | 97+ | User's reference list |
| Blocks in user list not in file | 50 | Don't exist in DXF |
| Nested-only blocks | 2 | `A$C348fe652`, `A$C61B563DF` |
| Unresolved A$C blocks | 9 | Listed in extraction issues |

## Relevant Files

- `app/core/extractor.py` - Main extraction logic, handles `*U` and `A$C` dynamic block resolution
- `app/tests/assets/samples/437 Greenwich - EFP- 4-18-2022.dxf` - The DXF file being analyzed

## Root Cause Analysis

### 1. User's Reference List is Incorrect
The user's "actual dxf blocks" list contains 50 blocks that **do not exist** in the DXF file:

| Missing Block Category | Examples |
|------------------------|----------|
| Plumbing fixtures | `Knsly_Mezz_Floor Plan$0$I_PLUMB_WC_FLUSH - WALL_*` (5 blocks) |
| Panel blocks | `95103BGM$0$DOT`, `95103BGM$0$PANEL`, `PANEL` |
| Refrigeration units | `C5XEP-*`, `FG-*`, `FW-*`, `FWG-*`, `IC6SL-*`, `SFG-*` |
| Display cases | `DX7LD-*`, `IM-05-C-R-*`, `P543-*`, `Q1-SS-*`, `Q3-SS*`, `Q4-SS-*` |
| Other variants | `C2NXXLP-6/8/END`, `C2XXLEP-12`, `RL-4DR` |

### 2. Naming Discrepancy
The user's list shows `ASC036B2AD9` but the file contains `A$C036B2AD9`. The `$` character is being rendered as `S` in whatever tool generated the user's list.

### 3. Minor Name Variations
- User list: `BOF -3ft Deep Wakefern Milk Mover` (one space)
- Actual file: `BOF -3ft Deep  Wakefern Milk Mover` (two spaces)

## Extractor Behavior Analysis

### What the Extractor Does Correctly

1. **Skips system blocks**: `*Model_Space`, `*Paper_Space`, dimension blocks (`*D*`)
2. **Resolves `*U` blocks**: Dynamic block instances resolved via XDATA to original names
3. **Handles `A$C` blocks**: Uses raw name when XDATA resolution fails (tracked in issues)
4. **Counts modelspace INSERTs**: Only counts blocks actually inserted in modelspace

### Nested Blocks (By Design, Not Counted)
The extractor only counts direct modelspace insertions. These blocks exist but are nested:

| Nested Block | Parent Block | Status |
|--------------|--------------|--------|
| `A$C348fe652` | `A$C86afe4d1` | Not counted (nested) |
| `A$C61B563DF` | `A$C10f30244` | Not counted (nested) |
| `RECEPT_DUPLEX` | `3 BAG + CLR` | Counted separately (also in modelspace) |

### Extraction Issues (A$C Resolution)
9 `A$C` blocks couldn't resolve their original names - these are tracked in `extraction_issues`:

| Block | Layer | Insertions | Details |
|-------|-------|------------|---------|
| `A$C86afe4d1` | EX-Refg'd Cases | 12 | No XDATA found |
| `A$C5EF818C6` | EX-Fixture | 7 | No AcDbBlockRepBTag |
| `A$C86afe4d1` | EX-Fixture | 6 | No XDATA found |
| `A$C29B80E08` | EX-Refg'd Cases | 4 | No AcDbBlockRepBTag |
| Others | Various | 6 | Various XDATA issues |

## Verification Results

### Actual DXF Contents
```
Block definitions: 54
Modelspace INSERT entities: 1,269
Unique blocks inserted: 52
```

### Extractor Output
```
Extracted blocks: 52 (100% match)
Extraction issues: 9 (all A$C blocks correctly tracked)
```

## Recommendations

1. **Verify source of user's block list** - The list appears to be from a different file version or different file entirely
2. **Check for file corruption/modification** - The DXF file may have been saved/exported differently than expected
3. **No extractor changes needed** - The extractor correctly extracts all blocks present in the file

## Next Steps

1. User should verify they're using the correct DXF file
2. If blocks are expected from an XREF, ensure the XREF is bound/embedded
3. Consider adding nested block counting as a future enhancement if needed
