# All Block Definitions & Nested Block Detection Implementation Plan

## Executive Summary
This report analyzes the best approach to implement two related features: (1) showing ALL block definitions in the Excel output with an insertion status column, and (2) detecting and reporting nested blocks. The implementation requires scanning block definitions for INSERT entities to build a parent-child relationship map, then adding columns to enable Excel filtering/sorting.

## Table Summary

| Feature | New Fields | Implementation Approach | Complexity |
|---------|-----------|------------------------|------------|
| All Block Definitions | `block_insertion_status` | Iterate `doc.blocks`, compare with `block_counts` | Low |
| Nested Detection | `block_is_nested`, `block_nested_parent_names` | Scan block definitions for INSERT entities | Medium |

### New Field Definitions (Following `app_docs/005-field-naming-convention.md`)

| Field Name | Domain | Type | Description |
|------------|--------|------|-------------|
| `block_insertion_status` | block | str | "Inserted", "Nested Only", "Unused", "System" |
| `block_is_nested` | block | bool | TRUE if block appears as INSERT inside another block definition |
| `block_nested_parent_names` | block | str | Comma-separated list of parent block names |

## Relevant Files

- **`app/core/extractor.py`** - Main extraction logic; needs modification for nested block scanning and all-definitions tracking
- **`app/core/types.py`** - TypedDict definitions; add new fields to relevant types
- **`app/core/constants.py`** - Excel column constants; add new EXCEL_COLUMN_ constants
- **`app/core/excel_writer.py`** - Excel generation; update Block Geometry Analysis sheet with new columns
- **`app_docs/005-field-naming-convention.md`** - Reference for field naming conventions

## Current Architecture Analysis

### Existing Block Processing Flow (extractor.py)

```
Phase 1: Block Definition Analysis (lines 1143-1264)
├── Iterates doc.blocks
├── Skips system blocks (*Model_Space, *Paper_Space)
├── Resolves anonymous blocks (*U, A$C)
├── Stores geometry in block_trimming_data
└── Does NOT track if block is nested

Phase 2: Modelspace Entity Scan (lines 1269-1480)
├── Iterates doc.modelspace()
├── Counts INSERT entities → block_counts
└── Only counts direct modelspace insertions
```

### Problem: Missing Data

1. **All Block Definitions**: `block_trimming_data` has geometry for all processed blocks, but `block_counts` only has blocks with modelspace insertions
2. **Nested Detection**: No existing code scans inside block definitions for INSERT entities

## Implementation Design

### Approach 1: Minimal Change (Recommended)

Add a new data structure during Phase 1 to track nested relationships:

```python
# New data structures in extract_blocks()
nested_block_parents: dict[str, set[str]] = {}  # child -> set of parent names
all_block_names: set[str] = set()  # Track all non-system block names

# During block definition loop (Phase 1)
for block_def in doc.blocks:
    block_name = block_def.name

    # Track all block names
    if not block_name.startswith("*"):
        all_block_names.add(block_name)

    # Scan for nested INSERT entities
    for entity in block_def:
        if entity.dxftype() == "INSERT":
            nested_name = entity.dxf.name
            if nested_name not in nested_block_parents:
                nested_block_parents[nested_name] = set()
            nested_block_parents[nested_name].add(block_name)
```

### Insertion Status Logic

```python
def get_insertion_status(
    block_name: str,
    block_counts: dict[str, int],
    nested_block_parents: dict[str, set[str]],
) -> str:
    """Determine insertion status for a block."""
    has_modelspace_insertion = block_name in block_counts
    is_nested = block_name in nested_block_parents

    if has_modelspace_insertion:
        return "Inserted"
    elif is_nested:
        return "Nested Only"
    else:
        return "Unused"
```

### Data Flow Diagram

```
doc.blocks iteration
        │
        ├──► all_block_names (set)
        │
        ├──► nested_block_parents (dict)
        │    child_name → {parent1, parent2, ...}
        │
        └──► block_trimming_data (existing)

        +

block_counts (existing, from modelspace)
        │
        ▼
Merge Logic (excel_writer.py)
        │
        ├──► block_insertion_status
        ├──► block_is_nested
        └──► block_nested_parent_names
```

## Best Practice: ezdxf Nested Block Scanning

Based on [ezdxf documentation](https://ezdxf.readthedocs.io/en/stable/blocks/block.html) and [tutorials](https://ezdxf.readthedocs.io/en/stable/tutorials/blocks.html):

```python
# Scan a block definition for nested INSERT entities
def scan_nested_inserts(block_def) -> set[str]:
    """Return set of block names inserted within this block definition."""
    nested_names = set()
    for entity in block_def:
        if entity.dxftype() == "INSERT":
            nested_names.add(entity.dxf.name)
    return nested_names

# Alternative using query (cleaner but slightly slower)
def scan_nested_inserts_query(block_def) -> set[str]:
    """Return set of block names inserted within this block definition."""
    inserts = block_def.query("INSERT")
    return {insert.dxf.name for insert in inserts}
```

## New Types Definition (types.py)

```python
class BlockDefinitionData(TypedDict):
    """
    Extended block definition data including insertion and nesting status.

    Attributes:
        insertion_status: One of "Inserted", "Nested Only", "Unused", "System"
        is_nested: True if this block is inserted inside another block
        nested_parent_names: List of parent block names where this block is used
    """
    insertion_status: str
    is_nested: bool
    nested_parent_names: list[str]
```

## New Constants (constants.py)

```python
# Block Definitions Analysis columns
EXCEL_COLUMN_BLOCK_INSERTION_STATUS: str = "block_insertion_status"
EXCEL_COLUMN_BLOCK_IS_NESTED: str = "block_is_nested"
EXCEL_COLUMN_BLOCK_NESTED_PARENT_NAMES: str = "block_nested_parent_names"
```

## Excel Output Changes

### Block Geometry Analysis Sheet (Updated)

| Column | Existing/New | Description |
|--------|--------------|-------------|
| Block Name | Existing | Block definition name |
| Block Layer Name | Existing | Layer of insertion |
| Block Insertion Status | **New** | "Inserted", "Nested Only", "Unused" |
| Block Is Nested | **New** | TRUE/FALSE |
| Block Nested Parent Names | **New** | Comma-separated parent names |
| Block Rotation 0 | Existing | ... |
| ... | Existing | (all existing columns) |

### Why Block Geometry Analysis Sheet?

The user's requirement states: "sheets with info around blocks such as geometry should include all blocks". The Block Geometry Analysis sheet is the appropriate location because:

1. It already contains per-block data (geometry, rotations, scales)
2. Adding status columns enables filtering blocks by insertion status
3. Adding nested parent names shows the block hierarchy

### Alternative: New "Block Definitions" Sheet

If preferred, a dedicated sheet could be created with just:
- Block Name
- Block Insertion Status
- Block Is Nested
- Block Nested Parent Names
- Block Entity Count

This would be cleaner but adds another sheet to manage.

## Implementation Steps

### Phase 1: Types & Constants

1. Add `BlockDefinitionData` TypedDict to `types.py`
2. Add `EXCEL_COLUMN_BLOCK_*` constants to `constants.py`

### Phase 2: Extractor Changes

1. Add `nested_block_parents: dict[str, set[str]]` to track parent-child relationships
2. Add `all_block_definitions: set[str]` to track all non-system blocks
3. During block definition loop, scan for INSERT entities
4. Add new fields to `ExtractionResult`:
   - `nested_block_parents: dict[str, list[str]]`
   - `all_block_definitions: list[str]`

### Phase 3: Excel Writer Changes

1. Modify `_create_block_geometry_analysis_sheet()`:
   - Include blocks from `all_block_definitions` (not just `block_layer_pairs`)
   - Compute `block_insertion_status` based on `block_counts` and `nested_block_parents`
   - Add `block_is_nested` column
   - Add `block_nested_parent_names` column
2. Update column list and formatting

### Phase 4: Tests

1. Create test DXF with nested blocks
2. Test insertion status classification
3. Test nested parent name reporting
4. Test Excel column output

## Handling Anonymous Blocks

Special consideration for anonymous blocks (*U, A$C):

```python
# When scanning nested inserts, resolve anonymous names
for entity in block_def:
    if entity.dxftype() == "INSERT":
        nested_name = entity.dxf.name
        # Resolve anonymous to original name if known
        if nested_name in anonymous_to_resolved:
            nested_name = anonymous_to_resolved[nested_name]
        nested_block_parents[nested_name].add(parent_block_name)
```

## Edge Cases

| Edge Case | Handling |
|-----------|----------|
| Circular nesting (A contains B, B contains A) | ezdxf documentation warns against this; report as-is |
| Anonymous blocks inside other blocks | Resolve using existing `anonymous_to_resolved` mapping |
| XRef blocks | Mark as "System" or exclude |
| Blocks only in paperspace | Current scope is modelspace; could add "Paperspace Only" status |

## Recommendations

1. **Start with Block Geometry Analysis sheet** - Add columns there first since it already has per-block data
2. **Use iteration not query** - Direct iteration is clearer and allows early-exit if needed
3. **Build mapping during Phase 1** - Leverage existing block definition loop
4. **Store parent names as list** - Easier for Excel output (comma-separated string)
5. **Add filtering hint in header** - Consider Excel header tooltips for explaining status values

## Next Steps

1. Create spec file: `specs/050-unit-1-nested-block-detection-types.md`
2. Create spec file: `specs/051-unit-2-extractor-nested-scanning.md`
3. Create spec file: `specs/052-unit-3-excel-all-blocks-columns.md`
4. Create test asset: `app/tests/assets/create_nested_block_test.py`
5. Implement in order: types → constants → extractor → excel_writer → tests

## Technical References

- [ezdxf Block Documentation](https://ezdxf.readthedocs.io/en/stable/blocks/block.html)
- [ezdxf Blocks Tutorial](https://ezdxf.readthedocs.io/en/stable/tutorials/blocks.html)
- [ezdxf INSERT Documentation](https://ezdxf.readthedocs.io/en/stable/blocks/insert.html)
- [Block Management Internals](https://ezdxf.readthedocs.io/en/stable/dxfinternals/block_management.html)
