# Frysetorg Block: Why Polygon Count is 21 - Detailed Step-by-Step Analysis

## Executive Summary

The `Frysetorg D 1960 L 3750` block has a polygon count of 21 because spec 032 (CIRCLE, ARC, HATCH extraction) was successfully implemented. The block contains 1 CIRCLE entity at the H2O symbol location, which is now discretized into 55 line segments. These circle segments intersect with the 23 decorative wave lines in the H2O area, creating 14 additional closed polygons beyond the 7 original main structure polygons.

## Table Summary

| Processing Step | Input | Output | Change from Pre-032 |
|-----------------|-------|--------|---------------------|
| 1. Entity Count | 47 entities | 43 LINE + 1 CIRCLE + 3 text | Same |
| 2. Edge Extraction | 47 entities | 98 edges | +55 (circle segments) |
| 3. Unary Union | 98 edges | 172 segments | +89 vs old 83 |
| 4. Polygonize | 172 segments | 21 polygons | +14 vs old 7 |
| 5. Content Zone | 21 candidates | Polygon #2 wins | Same winner |

## Relevant Files

- **app/core/geometry.py:378-403** - `_extract_circle_edges()` produces 55 segments from circle with sagitta=0.1
- **app/core/geometry.py:465-512** - `_extract_all_edges()` now includes CIRCLE entities
- **app/core/geometry.py:515-560** - `_extract_paint_bucket_regions()` runs polygonize
- **app/core/constants.py:57** - `ARC_FLATTENING_SAGITTA = 0.1` controls segment count
- **specs/032-unit-1-2-circle-arc-hatch-extraction.md** - Implementation spec (completed)
- **ai_output/003-frysetorg-h2o-processing-analysis.md** - Pre-spec-032 analysis (now outdated)

## Step-by-Step Processing Trace

### Step 1: Block Entity Composition

```
Block: Frysetorg D 1960 L 3750
┌─────────────┬───────┬────────────────────────────────────────┐
│ Entity Type │ Count │ Description                            │
├─────────────┼───────┼────────────────────────────────────────┤
│ LINE        │ 43    │ Structural lines + H2O wave pattern    │
│ CIRCLE      │ 1     │ H2O symbol at (1874.5, -1563), r=60    │
│ MTEXT       │ 2     │ "Frysdisk", "L:3750 D:1960"            │
│ TEXT        │ 1     │ "H2O"                                  │
└─────────────┴───────┴────────────────────────────────────────┘
Total geometric entities: 44 (43 LINE + 1 CIRCLE)
```

### Step 2: Circle Flattening

```
CIRCLE Entity:
  Center: (1874.50, -1563.00)
  Radius: 60.00 units

Flattening with ARC_FLATTENING_SAGITTA = 0.1:
  Sagitta formula: n ≈ π × √(2r/s)
  n ≈ π × √(2 × 60 / 0.1) = π × √1200 ≈ 108.8

Actual output: 55 line segments
  (ezdxf's adaptive algorithm produces fewer segments for small radii)
```

### Step 3: Edge Extraction

```
_extract_all_edges() output:
┌──────────────┬────────┬─────────────────────────────────────┐
│ Source       │ Edges  │ Notes                               │
├──────────────┼────────┼─────────────────────────────────────┤
│ LINE         │ 43     │ All 43 LINE entities → 43 edges     │
│ CIRCLE       │ 55     │ 1 circle → 55 flattened segments    │
│ ARC          │ 0      │ No ARC entities in this block       │
│ HATCH        │ 0      │ No HATCH entities in this block     │
├──────────────┼────────┼─────────────────────────────────────┤
│ TOTAL        │ 98     │ +55 edges compared to pre-spec-032  │
└──────────────┴────────┴─────────────────────────────────────┘
```

### Step 4: Unary Union (Intersection Splitting)

```
Input: 98 edges
Output: 172 segments

New intersection points: 74
  - Circle segments cross H2O wave lines at multiple points
  - Each crossing creates a new vertex and splits both edges
  - Some lines cross each other within the H2O area
```

### Step 5: Polygonize Result

```
Input: 172 line segments
Output: 21 closed polygons

Classification by location:
┌───────────────────┬──────────┬─────────────────────────────────┐
│ Category          │ Count    │ Description                     │
├───────────────────┼──────────┼─────────────────────────────────┤
│ Main Structure    │ 6        │ Original block compartments     │
│ H2O Area          │ 15       │ Circle-line intersection shapes │
├───────────────────┼──────────┼─────────────────────────────────┤
│ TOTAL             │ 21       │                                 │
└───────────────────┴──────────┴─────────────────────────────────┘
```

### Step 6: Polygon Area Analysis

```
Main Structure Polygons (by area):
  1. Polygon #2:  3,349,217.71 sq units  ← CONTENT ZONE (largest net area)
  2. Polygon #1:    816,874.97 sq units  Upper center section
  3. Polygon #4:    805,589.79 sq units  Lower center (near H2O)
  4. Polygon #5:    768,516.20 sq units  Lower right section
  5. Polygon #3:    768,515.95 sq units  Lower left section
  6. Polygon #6:    130,000.00 sq units  Gap region 1
  7. Polygon #7:    130,000.00 sq units  Gap region 2

H2O Area Polygons (14 small, 1 medium):
  - Polygon #13:    6,892.60 sq units  (circle center region)
  - Polygons #8-21: 0.00 to 864.30 sq units (wedge-shaped slivers)
```

## Why Pre-Spec-032 Count Was 7

Before implementing spec 032:
- `_extract_all_edges()` only processed LINE and LWPOLYLINE entities
- The CIRCLE at (1874.5, -1563) was **completely ignored**
- H2O wave lines created 0 polygons (36 dead-end vertices)
- Only 7 polygons from main block structure (shelves/compartments)

## Why Post-Spec-032 Count Is 21

After implementing spec 032:
- `_extract_circle_edges()` converts CIRCLE to 55 line segments
- Circle segments intersect with H2O wave lines
- Intersections create closed loops where none existed before
- 14 new polygons form in the H2O area (wedge shapes between circle arc and wave lines)
- Total: 7 original + 14 new = 21 polygons

## Visual Representation

```
H2O Area Before Spec 032:          H2O Area After Spec 032:

    /│\                                ╭──────────╮
   / │ \                              /│\│      │/│\
  /  │  \  <- Dead-end lines         / │ \│      │/ │ \
 ----+----                          ╱──┼──╲──────╱──┼──╲
     │                              │  │  │      │  │  │
     ▼ (no circle extracted)        ╰──┴──╯ .... ╰──┴──╯
                                       ↑ closed polygons
0 polygons formed                   14 polygons formed
(36 dead-end vertices)             (circle closes many paths)
```

## Excel Output Verification

The user-provided Excel row shows:
```
Block Polygon Count: 21
Content Zone Width: 3750
Content Zone Height: 1808
Content Zone Detected: TRUE
```

This confirms:
- Polygon count of 21 is correctly reported
- Content zone detection still works (polygon #2 with area 3,349,217 wins)
- Block dimensions are correctly derived

## Recommendations

### If Polygon Count Should Be Lower
The current behavior is mathematically correct. If fewer polygons are desired:

1. **Filter by area threshold** - Ignore polygons smaller than X square units
2. **Exclude decorative regions** - Skip polygons formed by circle-line intersections
3. **Use pre-032 logic** - Revert to LINE-only extraction (not recommended)

### If Current Count Is Acceptable
The current behavior is feature-complete per spec 032:
- CIRCLE entities are correctly extracted
- Closed regions are accurately detected
- Content zone selection is unaffected (largest net area wins)

## Next Steps

1. **Decide on polygon filtering** - Add optional area threshold to exclude tiny slivers?
2. **Update documentation** - `types.py` docstring should mention CIRCLE/ARC/HATCH
3. **Archive outdated reports** - Mark ai_output/003 as superseded by this analysis
