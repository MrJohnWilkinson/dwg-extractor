# Polygon Count Discrepancy Solutions Report

## Executive Summary

This report provides detailed implementation solutions for the two polygon count discrepancies identified in the DXF Block Extractor. Solution A addresses HATCH boundary extraction by modifying `_extract_all_edges()`. Solution B introduces a configurable gap tolerance feature using Shapely's `snap()` function to bridge near-touching line endpoints.

## Table Summary

| Issue | Block Example | Solution | Implementation Complexity | Risk Level |
|-------|---------------|----------|---------------------------|------------|
| HATCH boundaries not extracted | SPAR Gulv 900x600 H1860 | Add HATCH entity handling to `_extract_all_edges()` | Low | Low |
| Gap tolerance for near-touching lines | Frysetorg D 1960 L 3750 | Implement `snap()` pre-processing step | Medium | Medium |

## Relevant Files

- `app/core/geometry.py:375-411` - `_extract_all_edges()` - Primary function to modify for both solutions
- `app/core/geometry.py:413-458` - `_extract_paint_bucket_regions()` - Will benefit from both solutions automatically
- `app/core/constants.py:140-150` - Threshold constants - Add new `GAP_TOLERANCE_DEFAULT` constant
- `app/tests/assets/hatch_test.dxf` - Existing HATCH test fixture for validation
- `app/tests/assets/create_hatch_test.py` - Reference for HATCH boundary path creation

## Solution A: HATCH Boundary Extraction

### Problem

The `_extract_all_edges()` function only extracts LINE and LWPOLYLINE entities. HATCH boundaries (which define filled regions) are ignored, causing polygon counts to miss regions bounded by HATCH edges.

### Implementation Approach

HATCH entities in ezdxf contain boundary paths accessible via `hatch.paths`. Each path can be:
- **PolylinePath**: Contains vertices as a list of coordinates
- **EdgePath**: Contains individual edges (LineEdge, ArcEdge, EllipseEdge, SplineEdge)

### Recommended Code Change

Add to `_extract_all_edges()` after the LWPOLYLINE handling (around line 407):

```python
elif entity.dxftype() == "HATCH":
    try:
        for path in entity.paths:
            if hasattr(path, 'vertices'):
                # PolylinePath - has vertices attribute
                vertices = [(float(v[0]), float(v[1])) for v in path.vertices]
                if len(vertices) >= 2:
                    for i in range(len(vertices) - 1):
                        edges.append(LineString([vertices[i], vertices[i + 1]]))
                    # Close the path if it's marked as closed
                    if path.is_closed and len(vertices) >= 2:
                        edges.append(LineString([vertices[-1], vertices[0]]))
            elif hasattr(path, 'edges'):
                # EdgePath - has edges attribute
                for edge in path.edges:
                    if edge.EDGE_TYPE == 'LineEdge':
                        start = (float(edge.start[0]), float(edge.start[1]))
                        end = (float(edge.end[0]), float(edge.end[1]))
                        edges.append(LineString([start, end]))
                    # Note: ArcEdge, EllipseEdge, SplineEdge would need
                    # discretization to convert to line segments
    except (AttributeError, IndexError, TypeError):
        continue
```

### Testing Strategy

1. Use existing `app/tests/assets/hatch_test.dxf` to verify HATCH boundaries are extracted
2. Create new test in `app/tests/core/test_geometry.py` for HATCH edge extraction
3. Verify SPAR Gulv block now reports 7 polygons instead of 5

### Considerations

- **ArcEdge/EllipseEdge/SplineEdge**: These curved edge types would need discretization (conversion to line segments). Initial implementation can skip these and log a warning.
- **Performance**: HATCH paths are typically small; minimal performance impact expected
- **Semantic meaning**: HATCH boundaries represent visual fill areas, which aligns with the paint-bucket principle

## Solution B: Gap Tolerance Bridging

### Problem

Vertical lines in the Frysetorg block have gaps of ~140-350 units. Users expect these visually-continuous lines to form closed regions, but the algorithm correctly identifies them as having gaps.

### Implementation Approach

Use Shapely's `snap()` function to bridge endpoints that are within a configurable tolerance before running `polygonize()`.

### Recommended Implementation

#### 1. Add New Constant

In `app/core/constants.py`:

```python
GAP_TOLERANCE_DEFAULT: float = 0.0
"""Default gap tolerance for bridging near-touching line endpoints.
Set to 0.0 (disabled) by default. Users can enable by setting a positive value.
Typical values: 1.0-10.0 for drawings in mm, 50.0-500.0 for large-scale drawings.
Setting too high may incorrectly merge separate features."""
```

#### 2. Add Snap Pre-Processing

Modify `_extract_paint_bucket_regions()` to accept an optional tolerance parameter:

```python
def _extract_paint_bucket_regions(
    block_def: BlockLayout,
    abort_event: threading.Event | None = None,
    gap_tolerance: float = 0.0,
) -> list[Polygon]:
    """
    Extract all visual regions using paint-bucket algorithm.

    Args:
        block_def: ezdxf block definition object
        abort_event: Optional threading.Event to signal abort request
        gap_tolerance: Distance threshold for snapping nearby endpoints.
            Endpoints within this distance will be merged. Default 0.0 (disabled).
    """
    edges = _extract_all_edges(block_def)

    if not edges:
        return []

    if abort_event and abort_event.is_set():
        raise GeometryAbortedError("Region detection aborted")

    # Merge and split at all intersections
    merged = unary_union(edges)
    if merged.is_empty:
        return []

    # Apply gap tolerance snapping if enabled
    if gap_tolerance > 0:
        from shapely import snap
        # Snap geometry to itself to close small gaps
        merged = snap(merged, merged, gap_tolerance)

    line_segments = list(merged.geoms) if hasattr(merged, "geoms") else [merged]
    polygons = list(polygonize(line_segments))
    # ... rest of function unchanged
```

### Alternative: Vertex-Based Snapping

For more control, implement endpoint-to-endpoint snapping:

```python
def _snap_endpoints(edges: list[LineString], tolerance: float) -> list[LineString]:
    """
    Snap nearby endpoints to create connected geometry.

    Collects all endpoints, clusters points within tolerance,
    replaces each cluster with its centroid.
    """
    from collections import defaultdict
    import numpy as np

    # Collect all endpoints
    endpoints = []
    for edge in edges:
        coords = list(edge.coords)
        endpoints.append(coords[0])
        endpoints.append(coords[-1])

    # Cluster endpoints within tolerance using spatial index
    # (simplified: use brute force for small edge counts)
    point_map = {}  # original point -> snapped point

    for i, p1 in enumerate(endpoints):
        if p1 in point_map:
            continue
        cluster = [p1]
        for j, p2 in enumerate(endpoints):
            if i != j and p2 not in point_map:
                dist = ((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)**0.5
                if dist <= tolerance:
                    cluster.append(p2)

        # Compute centroid of cluster
        centroid = (
            sum(p[0] for p in cluster) / len(cluster),
            sum(p[1] for p in cluster) / len(cluster)
        )
        for p in cluster:
            point_map[p] = centroid

    # Rebuild edges with snapped endpoints
    snapped_edges = []
    for edge in edges:
        coords = list(edge.coords)
        new_start = point_map.get(coords[0], coords[0])
        new_end = point_map.get(coords[-1], coords[-1])
        snapped_edges.append(LineString([new_start, new_end]))

    return snapped_edges
```

### Configuration Options

| Option | Pros | Cons |
|--------|------|------|
| Global constant | Simple, consistent | One size doesn't fit all drawings |
| Per-extraction parameter | Flexible | Requires API change |
| Auto-detect based on drawing scale | User-friendly | Complex to implement reliably |

### Recommended Approach

Start with a **per-extraction parameter** with a sensible default:

```python
# In _detect_content_zone() signature:
def _detect_content_zone(
    block_def: BlockLayout,
    block_bbox: tuple[float, float, float, float],
    abort_event: threading.Event | None = None,
    gap_tolerance: float = 0.0,  # New parameter
) -> ContentZoneData:
```

### Testing Strategy

1. Create test DXF with known gaps (e.g., lines with 100-unit gaps)
2. Verify gap_tolerance=0 produces original behavior
3. Verify gap_tolerance=150 closes 100-unit gaps
4. Verify gap_tolerance doesn't incorrectly merge distant features

### Risk Mitigation

- **Default to 0.0**: Preserve existing behavior unless explicitly enabled
- **Document clearly**: Gap tolerance is a user preference, not a correction
- **Warn on high values**: Log warning if tolerance > 10% of block dimensions

## Comparison Matrix

| Criterion | Solution A (HATCH) | Solution B (Gap Tolerance) |
|-----------|-------------------|---------------------------|
| Code changes | ~20 lines | ~40-60 lines |
| Risk of breaking changes | Low | Medium |
| User configuration needed | No | Yes (optional) |
| Addresses root cause | Yes | No (workaround) |
| Preserves paint-bucket semantics | Yes | Partially |

## Recommendations

### Immediate Actions

1. **Implement Solution A first** - Low risk, clear benefit, no semantic compromise
2. **Add HATCH boundary extraction tests** before implementation
3. **Validate with SPAR block** to confirm polygon count becomes 7

### Future Consideration

1. **Solution B as optional feature** - Implement with default disabled
2. **Add UI toggle** for gap tolerance in application settings
3. **Document behavior** - Explain that gaps are intentional per paint-bucket rule

## Next Steps

1. Create feature branch for HATCH boundary extraction
2. Write unit tests for `_extract_all_edges()` HATCH handling
3. Implement Solution A code changes
4. Validate against sample-blocks.dxf
5. Consider Solution B for v2 as user-configurable feature

## References

- [ezdxf HATCH Tutorial](https://ezdxf.readthedocs.io/en/stable/tutorials/hatch.html) - Boundary path API
- [Shapely snap() Documentation](https://shapely.readthedocs.io/en/stable/reference/shapely.snap.html) - Tolerance-based vertex snapping
- `ai_docs/logical-rules-for-polygons.md` - Paint-bucket principle documentation
- `ai_output/001-polygon-count-discrepancy-analysis.md` - Original analysis
