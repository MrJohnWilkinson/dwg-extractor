# Settings Synchronization UI/UX Best Practices Report

## Executive Summary

This report analyzes the settings synchronization issues between the main GUI and Advanced Settings window in the DXF Block Extractor, providing 2025 best practice solutions for each identified problem. The core issue is that numeric filter values (like Gap Bridge = 4) set in the main GUI are not reflected in the Advanced Settings window due to incomplete bi-directional synchronization. This report provides finalized implementation patterns for real-time validation, settings summary panel, resizable windows, copyable summaries, and clarified button scopes.

## Table Summary

| Issue | Solution | Implementation Pattern | Complexity |
|-------|----------|------------------------|------------|
| Settings not syncing between windows | Single Source of Truth + trace callbacks | `StringVar.trace_add("write", sync_callback)` | Low |
| Button naming ("Settings" vs "Advanced Settings") | Match button text to destination title | Rename to "Advanced Settings" | Trivial |
| Modal vs modeless window management | Keep modal with pre-open sync | `_sync_settings_to_manager()` before opening | Low |
| Gap Bridge: same or different setting? | Same setting - keep main GUI authoritative | Prominent read-only note in Advanced Settings | Trivial |
| Unclear Apply/Save scope | Explicit button labels + tooltip | "Apply All Changes" / "Save All as Default" | Low |
| Filters tab read-only note not prominent | Styled info banner at top of Filters tab | CTkFrame with distinct background color | Low |
| Real-time validation feedback | `trace_add` + `border_color="red"` on invalid | CustomTkinter `configure(border_color=)` | Low |
| Settings summary for active filters | Horizontal chip bar at bottom of main window | CTkFrame with filter chips | Medium |
| Advanced Settings not expandable | `resizable(True, True)` + minsize constraints | `window.minsize(650, 600)` | Trivial |
| Settings summary not copyable | Summary tab with CTkTextbox + Copy button | Read-only textbox with "Copy to Clipboard" | Low |
| Main window too small for summary | Increase height to 1000px | `self.geometry("600x1000")` | Trivial |

## Relevant Files

- **app/main.py:86-107** - Main GUI tkinter variables for filters (not synced to SettingsManager)
- **app/main.py:72** - Main window geometry (`600x750` -> change to `600x1000`)
- **app/main.py:754-761** - `_open_advanced_settings()` lacks pre-sync and post-refresh
- **app/main.py:1067-1084** - `_sync_settings_to_manager()` only syncs booleans, missing amounts
- **app/core/settings_window.py:92-94** - Window size is `650x600`, needs minsize constraint
- **app/core/settings_window.py:162-186** - Button frame with "Save as Default" and "Apply" lacking scope clarity
- **app/core/settings_window.py:543-551** - Filters tab info label (needs more prominent styling)
- **app/core/settings.py:91-405** - SettingsManager class, the correct single source of truth
- **app/core/constants.py:367-523** - SETTINGS_VALIDATION_REGISTRY with min/max constraints for validation

## Gap Bridge: Same or Different Setting?

**Confirmed: They are the SAME setting.**

Both the main GUI's "Gap Bridge Amount" entry field and the Advanced Settings "Filters" tab's "Gap Bridge Amount" row reference the same `gap_bridge_amount` key in `SettingsManager`.

**Decision**: Keep main GUI as the authoritative location for filter editing. Advanced Settings displays filters as read-only with a prominent, styled notice directing users to the main window.

## Settings Not Being Synced

### Main GUI -> Advanced Settings (Currently Broken)

| Setting | Synced to SettingsManager? | Fix Required |
|---------|---------------------------|--------------|
| `precision_fix_enabled` | Yes | None |
| `precision_fix_amount` | **No** | Add to `_sync_settings_to_manager()` |
| `gap_bridge_enabled` | Yes | None |
| `gap_bridge_amount` | **No** | Add to `_sync_settings_to_manager()` |
| `min_area_filter_enabled` | Yes | None |
| `min_area_filter_amount` | **No** | Add to `_sync_settings_to_manager()` |
| `min_side_filter_enabled` | Yes | None |
| `min_side_filter_amount` | **No** | Add to `_sync_settings_to_manager()` |
| `unit_override` | **No** | Add to `_sync_settings_to_manager()` |
| `generate_log_file` | Yes | None |
| `file_log_level` | Yes | None |

### Advanced Settings -> Main GUI (Not Implemented)

After Advanced Settings closes with "Apply", the main GUI's tkinter variables are never refreshed. Changes to Output/Logging settings are invisible until app restart.

## Implementation Details

### 1. Single Source of Truth Architecture

**Pattern**: Use `SettingsManager` as the authoritative store; tkinter variables are display-only views that sync on change.

**References**:
- [NN/Group Modal & Nonmodal Dialogs](https://www.nngroup.com/articles/modal-nonmodal-dialog/) recommends modals for "collecting application configuration options in a centralized dialog"
- [Eleken Modal UX Best Practices](https://www.eleken.co/blog-posts/modal-ux) states "Each has its place - modals for focused tasks"

**Implementation**:
```python
# In main.py __init__:
self.gap_bridge_amount_var.trace_add(
    "write",
    lambda *_: self._sync_numeric_setting("gap_bridge_amount", self.gap_bridge_amount_var)
)

def _sync_numeric_setting(self, key: str, var: ctk.StringVar) -> None:
    try:
        value = float(var.get())
        self.settings.set(key, value)
    except ValueError:
        pass  # Invalid input, don't sync
```

### 2. Modal Window Management

**Best Practice**: Keep the modal pattern but ensure data freshness.

**Why Modal**: [UX Movement Best Practices for Modal Windows](https://uxmovement.com/forms/best-practices-for-modal-windows/) states "When users need to compare or refer to information in the main window, a modal window will not work" - but settings configuration doesn't require comparison, making modal appropriate.

**Implementation**:
```python
def _open_advanced_settings(self) -> None:
    self._sync_settings_to_manager()  # BEFORE opening
    window = AdvancedSettingsWindow(self, self.settings)
    self.wait_window(window)
    self._refresh_from_settings()  # AFTER closing
```

### 3. Apply/Save Button Scope Clarity

**Problem**: User confusion about whether "Save as Default" and "Apply" affect only the current tab section or all settings.

**Solution**: Explicit button labels with tooltip.

- Change "Apply" to "Apply All Changes"
- Change "Save as Default" to "Save All as Default"
- Add tooltip: "Applies changes from all tabs (Filters, Performance, Precision, Output, Logging)"

**Implementation**:
```python
# In settings_window.py button frame:
self.save_default_button = ctk.CTkButton(
    button_frame,
    text="Save All as Default",
    width=140,
    command=self._on_save_as_default,
)

self.apply_button = ctk.CTkButton(
    button_frame,
    text="Apply All Changes",
    width=120,
    command=self._on_apply,
)

# Add tooltip using CTkToolTip or hover behavior
```

### 4. Prominent Filters Tab Notice

**Problem**: Current info label is plain gray text, easily overlooked.

**Solution**: Styled info banner with distinct background that looks professional.

**Implementation**:
```python
def _populate_filters_tab(self, parent: ctk.CTkFrame) -> None:
    scroll_frame = ctk.CTkScrollableFrame(parent)
    scroll_frame.pack(fill="both", expand=True, padx=5, pady=5)

    # Section header
    self._create_section_header(scroll_frame, "Filter Settings", "filters")

    # PROMINENT INFO BANNER - styled frame with icon-like indicator
    info_frame = ctk.CTkFrame(
        scroll_frame,
        fg_color=("gray85", "gray25"),  # Subtle but distinct background
        corner_radius=8,
    )
    info_frame.pack(fill="x", pady=(0, 15), padx=5)

    # Info icon/indicator
    info_indicator = ctk.CTkLabel(
        info_frame,
        text="i",
        font=ctk.CTkFont(size=14, weight="bold"),
        text_color=("gray40", "gray70"),
        width=24,
    )
    info_indicator.pack(side="left", padx=(12, 8), pady=10)

    # Info text
    info_label = ctk.CTkLabel(
        info_frame,
        text="Filter settings are configured in the main window.\n"
             "This tab displays current values for reference only.",
        font=ctk.CTkFont(size=11),
        text_color=("gray30", "gray80"),
        anchor="w",
        justify="left",
    )
    info_label.pack(side="left", fill="x", expand=True, pady=10, padx=(0, 12))

    # Rest of filter display (read-only)...
```

### 5. Real-Time Validation Feedback

**Best Practice**: Use `trace_add` for instant validation on each keystroke, with red border on invalid.

**References**:
- [Python Tkinter Validation Tutorial](https://www.pythontutorial.net/tkinter/tkinter-validation/) states "validate='key' is used to check for validation when any key is used"
- [PythonGUIs Input Validation](https://www.pythonguis.com/tutorials/input-validation-tkinter/) recommends "Real-time validation involves validating the user's input as soon as they enter it"

**Implementation**:
```python
def _create_validated_entry(self, parent, setting_key):
    var = ctk.StringVar()
    entry = ctk.CTkEntry(parent, textvariable=var, width=100)

    # Real-time validation on every keystroke
    var.trace_add("write", lambda *_: self._validate_realtime(setting_key, entry, var))

    return entry

def _validate_realtime(self, key: str, entry: ctk.CTkEntry, var: ctk.StringVar) -> None:
    value_str = var.get().strip()

    # Empty is valid (optional field)
    if not value_str:
        entry.configure(border_color=("gray50", "gray50"))
        return

    try:
        value = float(value_str)
        is_valid, _ = self.settings.validate(key, value)

        if is_valid:
            entry.configure(border_color=("gray50", "gray50"))  # Normal
        else:
            entry.configure(border_color="red")  # Invalid
    except ValueError:
        entry.configure(border_color="red")  # Not a number
```

**Current Implementation Gap**: Current code validates only on `<FocusOut>` event (settings_window.py:334-337). Change to trace callback for real-time feedback.

### 6. Settings Summary Panel (Active Filters)

**Best Practice**: Display active filters as "chips" or tags in a horizontal panel at the bottom of the main window.

**References**:
- [Baymard Institute Applied Filters Study](https://baymard.com/blog/how-to-design-applied-filters) states "32% aren't using the best UX practices for filtering"
- [SetProduct Filter UI Design](https://www.setproduct.com/blog/filter-ui-design) recommends "displaying selected filters as 'chips' or tags can drastically improve clarity"

**Implementation**:
```python
# Add to main.py _create_widgets() at bottom:
# Settings Summary Panel (replaces "status bar" terminology)
self.settings_summary_frame = ctk.CTkFrame(self.main_frame, height=40)
self.settings_summary_frame.pack(fill="x", side="bottom", pady=(10, 0))

summary_label = ctk.CTkLabel(
    self.settings_summary_frame,
    text="Active Filters:",
    font=ctk.CTkFont(size=11, weight="bold"),
)
summary_label.pack(side="left", padx=(10, 5))

self.filter_chips_frame = ctk.CTkFrame(self.settings_summary_frame, fg_color="transparent")
self.filter_chips_frame.pack(side="left", fill="x", expand=True, padx=5)

def _update_settings_summary(self) -> None:
    """Update the settings summary panel with active filter chips."""
    # Clear existing chips
    for widget in self.filter_chips_frame.winfo_children():
        widget.destroy()

    active_filters = []
    if self.precision_fix_var.get():
        active_filters.append(f"Precision Fix: {self.precision_fix_amount_var.get()}")
    if self.gap_bridge_var.get():
        active_filters.append(f"Gap Bridge: {self.gap_bridge_amount_var.get()}")
    if self.min_area_filter_var.get():
        active_filters.append(f"Min Area: {self.min_area_filter_amount_var.get()}")
    if self.min_side_filter_var.get():
        active_filters.append(f"Min Side: {self.min_side_filter_amount_var.get()}")

    if not active_filters:
        label = ctk.CTkLabel(
            self.filter_chips_frame,
            text="None",
            text_color="gray",
            font=ctk.CTkFont(size=11),
        )
        label.pack(side="left")
    else:
        for filter_text in active_filters:
            chip = ctk.CTkLabel(
                self.filter_chips_frame,
                text=filter_text,
                fg_color=("gray80", "gray30"),
                corner_radius=10,
                font=ctk.CTkFont(size=10),
                padx=10,
                pady=4,
            )
            chip.pack(side="left", padx=3)
```

**Window Size Adjustment**: Increase main window height from `600x750` to `600x1000` to accommodate settings summary panel.

### 7. Making Advanced Settings Expandable/Full Screen

**Current State**: `self.geometry("650x600")` with `self.resizable(True, True)` but no `minsize`.

**Best Practice**: Allow expansion but set minimum size constraints.

**References**:
- [CustomTkinter CTkToplevel Documentation](https://customtkinter.tomschimansky.com/documentation/windows/toplevel/) confirms `resizable(True, True)` allows resizing
- [CustomTkinter Window Discussion](https://github.com/TomSchimansky/CustomTkinter/discussions/453) shows `state("zoomed")` for maximized windows

**Implementation**:
```python
# In AdvancedSettingsWindow.__init__:
self.geometry("650x600")
self.resizable(True, True)
self.minsize(650, 600)  # ADD: Prevent window from being too small

# Optional: Add maximize button behavior
# On Windows/Linux, maximize works automatically with resizable(True, True)
# For explicit zoom: self.state("zoomed")
```

**ScrollableFrame Usage**: The current implementation already uses `CTkScrollableFrame` for tab content, which handles content overflow correctly when window is smaller than content.

### 8. Copyable Settings Summary Tab

**Best Practice**: Provide a plain-text summary that users can select and copy.

**Implementation**:
```python
def _create_summary_tab(self) -> None:
    """Create Summary tab with copyable settings text."""
    self.tabview.add("Summary")
    tab = self.tabview.tab("Summary")

    # Header
    header = ctk.CTkLabel(
        tab,
        text="Current Settings Summary",
        font=ctk.CTkFont(size=14, weight="bold"),
    )
    header.pack(pady=(15, 10))

    # Subheader
    subheader = ctk.CTkLabel(
        tab,
        text="Select text below to copy, or use the Copy button",
        font=ctk.CTkFont(size=10),
        text_color="gray",
    )
    subheader.pack(pady=(0, 10))

    # Copyable text box (read-only but selectable)
    self.summary_textbox = ctk.CTkTextbox(
        tab,
        height=380,
        width=580,
        font=("Courier", 11),
    )
    self.summary_textbox.pack(fill="both", expand=True, padx=15, pady=5)

    # Copy button
    self.copy_btn = ctk.CTkButton(
        tab,
        text="Copy to Clipboard",
        width=150,
        command=self._copy_summary,
    )
    self.copy_btn.pack(pady=15)

    # Populate summary
    self._refresh_summary()

def _refresh_summary(self) -> None:
    """Refresh the summary textbox with current settings."""
    from .settings import SETTINGS_SECTIONS

    summary_lines = [
        "DXF Block Extractor Settings",
        "=" * 35,
        "",
    ]

    for section, keys in SETTINGS_SECTIONS.items():
        summary_lines.append(f"[{section.upper()}]")
        for key in keys:
            value = self.settings.get(key)
            if value is None:
                display_value = "(default)"
            elif isinstance(value, bool):
                display_value = "Yes" if value else "No"
            else:
                display_value = str(value)
            # Format key nicely
            display_key = key.replace("_", " ").title()
            summary_lines.append(f"  {display_key}: {display_value}")
        summary_lines.append("")

    self.summary_textbox.configure(state="normal")
    self.summary_textbox.delete("1.0", "end")
    self.summary_textbox.insert("1.0", "\n".join(summary_lines))
    self.summary_textbox.configure(state="disabled")  # Read-only but selectable

def _copy_summary(self) -> None:
    """Copy summary text to clipboard."""
    self.clipboard_clear()
    self.clipboard_append(self.summary_textbox.get("1.0", "end-1c"))

    # Visual feedback
    self.copy_btn.configure(text="Copied!")
    self.after(1500, lambda: self.copy_btn.configure(text="Copy to Clipboard"))
```

## Recommendations

### Immediate Fixes (Bug Resolution)

1. **Expand `_sync_settings_to_manager()`** to include all numeric amounts
2. **Add `_sync_settings_to_manager()` call** before opening Advanced Settings
3. **Add `_refresh_from_settings()` call** after Advanced Settings closes
4. **Rename "Settings" button** to "Advanced Settings"

### Short-Term Improvements

1. **Add `trace_add` callbacks** to all filter variable changes for instant sync
2. **Change button labels** to "Apply All Changes" / "Save All as Default" with tooltip
3. **Add `minsize(650, 600)`** to Advanced Settings window
4. **Implement real-time validation** using `trace_add` instead of `<FocusOut>`
5. **Style the Filters tab info banner** with distinct background for prominence

### Medium-Term Improvements

1. **Add settings summary panel** with active filter chips to main window bottom
2. **Increase main window height** from 750px to 1000px
3. **Add Summary tab** in Advanced Settings with copyable text and "Copy to Clipboard" button

### Out of Scope

- Keyboard shortcuts (Ctrl+Shift+S for Advanced Settings access)
- Preset configurations / named settings profiles
- Undo/redo capability for settings changes
- Live preview during settings changes
- Cloud sync across machines
- Multiple settings windows
- Bi-directional filter editing (filters editable in both main GUI and Advanced Settings)
- Export settings to file (.txt/.json) - in-app copy is sufficient
- Per-section Apply buttons (non-standard for tabbed dialogs)
- Visual indicator showing which tabs have unsaved changes

## Next Steps

1. Create implementation spec for settings synchronization fixes
2. Implement `_sync_settings_to_manager()` expansion and refresh pattern
3. Rename button to "Advanced Settings" and update Apply/Save labels
4. Style the Filters tab info banner for prominence
5. Add real-time validation with red border feedback
6. Implement settings summary panel with filter chips
7. Increase main window height to 1000px
8. Add Summary tab with copyable text
9. Test synchronization behavior across all scenarios

## Sources

- [NN/Group Modal & Nonmodal Dialogs](https://www.nngroup.com/articles/modal-nonmodal-dialog/)
- [Eleken Modal UX Best Practices](https://www.eleken.co/blog-posts/modal-ux)
- [UX Movement Best Practices for Modal Windows](https://uxmovement.com/forms/best-practices-for-modal-windows/)
- [Python Tkinter Validation Tutorial](https://www.pythontutorial.net/tkinter/tkinter-validation/)
- [PythonGUIs Input Validation](https://www.pythonguis.com/tutorials/input-validation-tkinter/)
- [Baymard Institute Applied Filters Study](https://baymard.com/blog/how-to-design-applied-filters)
- [SetProduct Filter UI Design](https://www.setproduct.com/blog/filter-ui-design)
- [CustomTkinter CTkToplevel Documentation](https://customtkinter.tomschimansky.com/documentation/windows/toplevel/)
- [CustomTkinter Window Documentation](https://customtkinter.tomschimansky.com/documentation/windows/window/)
