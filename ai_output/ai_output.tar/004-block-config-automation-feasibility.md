# Block Configuration Automation Feasibility Report

## Executive Summary

Analysis of 68 blocks from `AFPSheet-and-Geometry-filtered.xlsx` and the actual DXF file reveals strong correlations between extractable geometry and configuration fields. Trim values can be reliably automated from segment edge data (~76% accuracy), Direction from aspect ratio (100% pattern match), and BY_Class split lengths exactly match block heights. Corner rectangle geometry in DXF blocks provides an additional source for explicit trim zone detection.

## Table Summary

| Output Field | Automation Method | Confidence | Notes |
|--------------|-------------------|------------|-------|
| Trim Left | First V Segment value | 76% | Fails on asymmetric blocks |
| Trim Right | Last V Segment value | 76% | Fails on asymmetric blocks |
| Trim Top | Last H Segment value | ~60% | More variable pattern |
| Trim Bottom | First H Segment value | ~50% | Least reliable |
| Direction | Aspect ratio (W/H) | 100% | Up if >1, Left/Right if <1 |
| BY_Class "I" | Segment count > 100 | Strong | Complex geometry indicator |
| BY_Class "RH" | Horizontal split pattern | Strong | Correlates with H segments |
| BY_Class split length | Sum = Block Height | Exact | Pattern: `val,-gap,val` |

## Relevant Files

- `app/tests/assets/samples/AFPSheet-and-Geometry-filtered.xlsx` - Source data with 68 blocks, 25 columns including geometry and configuration fields
- `app/tests/assets/samples/05-02 MASTERTEGNING SPAR SUPERMARKED - 670 M2 - 280525 - Copy.dxf` - Real DXF with 222 blocks (62 with content)
- `app/core/extractor.py` - Current DXF extraction logic, would need extension for trim detection
- `app/core/geometry.py` - Geometric calculations, segment extraction already implemented

## Correlation Analysis Details

### Trim Left/Right from Vertical Segments

Strong correlation discovered: **Trim Left = First V Segment, Trim Right = Last V Segment**

```
Match rate: 19/25 (76%)
```

**Matching examples:**
| Block | V First | V Last | Trim L | Trim R |
|-------|---------|--------|--------|--------|
| Dryss på 90 cm | 30 | 30 | 30 | 30 |
| F og g eksponerings bord | 20 | 20 | 20 | 20 |
| SPAR Gulv 900x500 | 15 | 15 | 15 | 15 |
| Fruit 120 | 22 | 22 | 22 | 22 |

**Mismatches (asymmetric blocks):**
| Block | V First | V Last | Trim L | Trim R | Pattern |
|-------|---------|--------|--------|--------|---------|
| Kosmetikk Høyre | 15 | 26 | 15 | 40 | Name indicates "Right" variant |
| Kosmetikk Venstre | 26 | 15 | 40 | 15 | Name indicates "Left" variant |
| Fruktbord Bananer | 22 | 22 | 20 | 20 | Swapped H/V orientation |

### Direction from Aspect Ratio

100% pattern match:

| Direction | Aspect (W/H) | Example Blocks |
|-----------|--------------|----------------|
| Up | > 1.0 | F og g eksponerings bord (1.33), Helpall (1.50), Tygg (2.03) |
| Left | < 1.0 | Fruktbord med skråbrett (0.68), Fryse ende D 1960 (0.53) |
| Right | < 1.0 | Kassefront frukt kjøl 900 (0.67) |

**Note:** Left vs Right differentiation unclear - may require block naming convention or additional heuristics.

### BY_Class Split Length = Block Height

Exact correlation for "RH" class blocks:

| Block | Height | Split Length | Sum |
|-------|--------|--------------|-----|
| SPAR Gulv 900x500 H1540 | 1070 | 500,-70,500 | 1070 |
| SPAR Gulv 900x600 H1860 | 1270 | 600,-70,600 | 1270 |

Pattern: `primary_shelf,-gap,primary_shelf` where gap is negative and sum of absolute values equals height.

## DXF Geometry Analysis

### Corner Rectangle Detection

Blocks with explicit trim zone geometry identified:

```
Spar Småvarer 900:
  Block bounds: 930.0 x 800.0
  Corner rectangles:
    - Left trim:  X=[0,30]   Y=[-70,0]  size=30x70
    - Right trim: X=[900,930] Y=[-70,0]  size=30x70

Spar Brød 900:
  Block bounds: 930.0 x 800.0
  Corner rectangles:
    - Left trim:  X=[0,30]   Y=[-70,0]  size=30x70
    - Right trim: X=[900,930] Y=[-70,0]  size=30x70
```

**Algorithm:** Detect small closed LWPOLYLINE rectangles at block corners to extract explicit trim widths.

### Block Content Distribution

| Content Level | Count | Example |
|---------------|-------|---------|
| Empty blocks | 160 | Most target blocks (dynamic references) |
| 1-20 entities | 35 | Spar blocks, simple fixtures |
| 20-100 entities | 15 | Complex equipment |
| 100+ entities | 12 | Technical drawings |

**Note:** Many target blocks are empty because they're dynamic block references - geometry is in anonymous `A$C*` blocks.

## Automation Strategy

### Tier 1: High Confidence (Implement First)

1. **Direction** - Derive from aspect ratio:
   ```python
   direction = "Up" if width > height else "Left"  # Default, refine with naming
   ```

2. **Symmetric Trims** - Use segment edges when first == last:
   ```python
   if v_segments[0] == v_segments[-1]:
       trim_left = trim_right = v_segments[0]
   ```

3. **BY_Class "I"** - Flag complex blocks:
   ```python
   by_class = "I" if len(v_segments) > 100 or len(h_segments) > 100 else None
   ```

### Tier 2: Medium Confidence (Requires Validation)

4. **Asymmetric Trims** - Parse block naming:
   ```python
   if "Høyre" in block_name or "Right" in block_name:
       # Right-oriented, larger trim on right
   elif "Venstre" in block_name or "Left" in block_name:
       # Left-oriented, larger trim on left
   ```

5. **BY_Class split length** - Calculate from height for RH blocks:
   ```python
   if by_class == "RH":
       shelf = (height - gap) / 2
       split_length = f"{shelf},-{gap},{shelf}"
   ```

### Tier 3: Requires Additional Data

6. **Corner rectangle extraction** - Parse LWPOLYLINE geometry:
   - Identify closed rectangles at block corners
   - Extract width/height as explicit trim zones
   - Currently only works for blocks with content (35% of blocks)

7. **Left vs Right direction** - Needs heuristic development:
   - Block naming patterns
   - Insertion point offset analysis
   - User training data

## Recommendations

1. **Start with Tier 1 rules** - Implement aspect ratio Direction and symmetric trim detection for immediate 70%+ coverage

2. **Add naming convention parser** - Detect "Høyre/Venstre", "Left/Right", "Midt" patterns to handle asymmetric blocks

3. **Implement corner rectangle detector** - Extract explicit trim zones from LWPOLYLINE geometry for blocks with content

4. **Build feedback loop** - Track automation accuracy, allow user corrections to improve heuristics

5. **Consider ML approach** - With enough training data, a classifier could learn block-to-config mappings

## Next Steps

1. Implement `predict_block_config()` function with Tier 1 rules
2. Add unit tests using known block configurations from Excel
3. Extend `extractor.py` to detect corner rectangles in block geometry
4. Create validation report comparing predictions vs manual entries
5. Document edge cases requiring manual configuration
