# SPAR Gulv 900x600 H1860 Polygon Count Analysis

## Executive Summary
The block `SPAR Gulv 900x600 H1860` reports 5 polygons instead of the expected 7 due to **floating-point precision mismatch** in the DXF file. Two horizontal LINE entities have endpoint coordinates that differ from the rectangle edges by ~3.7 nanometers, preventing Shapely's `unary_union` from recognizing the intersection and splitting the rectangles.

## Table Summary

| Issue | Value | Impact |
|-------|-------|--------|
| Expected polygon count | 7 | User's visual observation |
| Actual polygon count | 5 | Code output |
| Missing polygons | 2 | Due to unsplit rectangles |
| LINE endpoint x-coord | 914.9999999962746 | Precision error |
| Rectangle edge x-coord | 915.0 | Expected value |
| Coordinate gap | ~3.7e-9 units | Below Shapely tolerance |
| HATCH extraction | Working correctly | Not the cause |

## Relevant Files

- **app/core/geometry.py** - Contains `_extract_all_edges()` and `_extract_paint_bucket_regions()` functions where the issue manifests
- **app/core/constants.py** - Defines `ARC_FLATTENING_SAGITTA` constant used for curve flattening (not the issue here)
- **app/tests/assets/samples/sample-blocks.dxf** - Source DXF file containing the problematic block
- **specs/032-unit-1-2-circle-arc-hatch-extraction.md** - Recent spec for CIRCLE/ARC/HATCH extraction (implemented correctly, not the cause)

## Block Entity Inventory

| Entity Type | Count | Notes |
|-------------|-------|-------|
| HATCH | 1 | EdgePath with 4 LineEdge boundaries |
| LINE | 2 | Horizontal dividers at y=-535 and y=535 |
| LWPOLYLINE | 6 | 4 closed (brackets), 2 open (rectangles) |
| MTEXT | 1 | Text annotation (ignored) |

## Step-by-Step Analysis

### Step 1: Entity Extraction

The block contains these geometric entities:

```
LWPOLYLINE (closed=False): Bottom rectangle outline
  Points: (15,-35) -> (15,-635) -> (915,-635) -> (915,-35) -> (15,-35)

LWPOLYLINE (closed=False): Top rectangle outline
  Points: (15,35) -> (15,635) -> (915,635) -> (915,35) -> (15,35)

LINE: Horizontal divider in bottom rectangle
  Start: (15.0, -535.0)
  End:   (914.9999999962746, -535.0000000002328)  <-- PRECISION ERROR

LINE: Horizontal divider in top rectangle
  Start: (15.0, 535.0)
  End:   (914.9999999962746, 535.0000000002328)   <-- PRECISION ERROR

LWPOLYLINE (closed=True): Left bracket at (0,-35) to (30,35)
LWPOLYLINE (closed=True): Right bracket at (900,-35) to (930,35)

HATCH: Middle strip boundary at (30,-35) to (900,35)
```

### Step 2: Edge Extraction (30 edges total)

The `_extract_all_edges()` function correctly extracts:
- 4 edges from HATCH boundary (working correctly)
- 4 edges each from 2 open LWPOLYLINE rectangles (8 total)
- 4 edges each from 4 closed LWPOLYLINE brackets (16 total)
- 2 LINE edges (horizontal dividers)

### Step 3: Shapely unary_union Processing

When `unary_union()` merges all 30 edges:
- It merges overlapping/touching edges
- It splits edges at intersection points
- **CRITICAL**: The LINE endpoints don't exactly touch the rectangle edges

```python
# Rectangle right edge: x = 915.0 (exact)
# LINE right endpoint:  x = 914.9999999962746 (off by 3.7e-9)

rect_right_edge = LineString([(915.0, -35.0), (915.0, -635.0)])
horiz_line = LineString([(15, -535), (914.9999999962746, -535.0000000002328)])

# Intersection test:
rect_right_edge.intersection(horiz_line)  # Returns: LINESTRING EMPTY
```

### Step 4: Polygonize Results

After `unary_union`, the line segments are passed to `polygonize()`:

| Polygon | Area | Bounds | Expected |
|---------|------|--------|----------|
| 1 | 540,000 | (15,-635) to (915,-35) | Should be 2 polygons |
| 2 | 60,900 | (30,-35) to (900,35) | Correct (middle strip) |
| 3 | 2,100 | (900,-35) to (930,35) | Correct (right bracket) |
| 4 | 540,000 | (15,35) to (915,635) | Should be 2 polygons |
| 5 | 2,100 | (0,-35) to (30,35) | Correct (left bracket) |

### Step 5: Visual vs Detected Polygons

**Expected 7 Polygons:**
1. Bottom rect lower section: (15,-635) to (915,-535) = 360,000 area
2. Bottom rect upper section: (15,-535) to (915,-35) = 180,000 area
3. Top rect lower section: (15,35) to (915,535) = 180,000 area
4. Top rect upper section: (15,535) to (915,635) = 360,000 area
5. Middle strip: (30,-35) to (900,35) = 60,900 area
6. Left bracket: (0,-35) to (30,35) = 2,100 area
7. Right bracket: (900,-35) to (930,35) = 2,100 area

**Actual 5 Polygons:**
- Polygons 1+2 merged into single 540,000 polygon
- Polygons 3+4 merged into single 540,000 polygon
- Polygons 5,6,7 detected correctly

## Root Cause

**DXF file contains LINE entities with floating-point precision errors.**

The LINE endpoint x-coordinate (914.9999999962746) differs from the rectangle edge (915.0) by approximately 3.7 nanometers in CAD units. This microscopic gap prevents Shapely from recognizing the geometric intersection.

This is **NOT a code bug** - the CIRCLE/ARC/HATCH extraction implemented in spec 032 works correctly. The HATCH boundary contributes 4 edges that form the middle strip polygon properly.

## Impact Assessment

| Metric | Expected | Actual | Status |
|--------|----------|--------|--------|
| Polygon count | 7 | 5 | Incorrect |
| Content zone detection | Largest net area | Still works | OK |
| Trim values | Based on content zone | Still calculated | OK |
| Visual accuracy | Perfect match | 2 regions missed | Degraded |

## Recommendations

### Option 1: Coordinate Snapping (Recommended)
Add coordinate snapping in `_extract_all_edges()` before polygonization:

```python
def _snap_coordinate(value: float, precision: int = 6) -> float:
    """Snap coordinate to specified decimal precision."""
    return round(value, precision)
```

Apply to all extracted edge coordinates.

### Option 2: Buffer-Based Intersection
Use a small buffer around edges before `unary_union`:

```python
# Buffer edges by 1e-6 units, then union, then un-buffer
buffered = unary_union([edge.buffer(1e-6) for edge in edges])
```

### Option 3: Shapely snap() Function
Use `shapely.ops.snap()` to snap nearby points:

```python
from shapely.ops import snap
# Snap all edges to each other with tolerance
snapped_edges = [snap(e, merged, 1e-6) for e in edges]
```

## Next Steps

1. Determine acceptable coordinate precision for CAD drawings (typically 6 decimal places)
2. Implement coordinate snapping in `_extract_all_edges()`
3. Add unit test with the `SPAR Gulv 900x600 H1860` block as regression test
4. Verify polygon count increases from 5 to 7 after fix
