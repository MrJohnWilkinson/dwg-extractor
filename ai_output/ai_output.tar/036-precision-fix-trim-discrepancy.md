# Precision Fix Causes Content Zone to Exceed Native Block Dimensions

## Executive Summary

When precision fix is enabled with a custom tolerance (e.g., 3 units), coordinate snapping can cause the detected content zone bounding box to expand beyond the block's native dimensions. This results in negative trim values (e.g., `block_suggested_trim_top: -1.2`). The root cause is a **coordinate domain mismatch**: native dimensions use raw entity coordinates while content zone dimensions use snapped polygon coordinates.

## Table Summary

| Calculation Step | Value (Precision OFF) | Value (Precision=3) | Source |
|------------------|----------------------|---------------------|--------|
| Raw max_y coordinate | 4876.80000000028 | 4876.80000000028 | DXF entities |
| Native height | 4876.8 | 4876.8 | `_get_block_bounding_box()` (raw coords) |
| Snapped max_y | N/A | 4878.0 | `round(4876.8/3)*3 = 1626*3` |
| Content zone height | 4876.8 | 4878.0 | Snapped polygon bounds |
| Trim top calculation | 4876.8 - 4876.8 = 0.0 | 4876.8 - 4878.0 = -1.2 | `block_max_y - cz_max_y` |
| **Result** | **Correct** | **Negative trim (invalid)** | |

## Relevant Files

- `app/core/geometry.py:984-1181` - `_detect_content_zone()` calculates trim values from snapped polygon bounds and raw block_bbox
- `app/core/geometry.py:645-715` - `_extract_paint_bucket_regions()` applies precision snapping before polygon detection
- `app/core/geometry.py:541-560` - `_snap_linestring_coords()` implements the grid snapping formula
- `app/core/geometry.py:175-262` - `_get_block_bounding_box()` uses raw entity coordinates (unsnapped)
- `app/core/extractor.py:1269-1293` - Block trimming data and content zone detection are calculated from different coordinate sources
- `app/core/constants.py:243-260` - `DEFAULT_PRECISION_FIX_TOLERANCE` defines default values by unit (0.01mm for MM)

## Root Cause Analysis

### Step-by-Step Calculation Trace

**Block: `AP #5-4` with Precision Fix Amount = 3**

1. **Raw DXF Coordinates**
   - Block entity max Y coordinate: `4876.80000000028` (floating-point artifact from CAD)
   - This is used directly by `_get_block_bounding_box()`

2. **Native Height Calculation** (`extractor.py:1279`)
   ```python
   bbox = _get_block_bounding_box(block_def)  # Returns (0, 0, 762, 4876.80000000028)
   native_height = round(bbox[3] - bbox[1], 2)  # = round(4876.80000000028, 2) = 4876.8
   ```

3. **Precision Fix Snapping** (`geometry.py:691`)
   ```python
   # Snapping formula in _snap_linestring_coords():
   snapped_y = round(y / tolerance) * tolerance
   # For y=4876.80000000028, tolerance=3.0:
   # = round(4876.8/3) * 3 = round(1625.6) * 3 = 1626 * 3 = 4878.0
   ```

4. **Content Zone Bounding Box** (`geometry.py:1147-1149`)
   - Polygon detection uses snapped coordinates (4878.0 for max_y)
   - Content zone bbox becomes: `(0, 0, 762, 4878.0)`
   - Content zone height = `4878.0`

5. **Trim Value Calculation** (`geometry.py:1158`)
   ```python
   trim_top = round(block_max_y - cz_max_y, 2)
   # = round(4876.80000000028 - 4878.0, 2)
   # = round(-1.2, 2) = -1.2
   ```

### Why This Happens

The **coordinate domain mismatch**:

| Calculation | Coordinate Source | Value |
|------------|-------------------|-------|
| `native_height` | Raw entity coords | 4876.8 |
| `content_zone_height` | Snapped polygon coords | 4878.0 |
| `trim_top` | Raw - Snapped | -1.2 |

The snapping grid alignment causes expansion:
- `4876.8` is NOT a multiple of 3 (it's between 4875 and 4878)
- `4876.8 / 3 = 1625.6` rounds to `1626`
- `1626 * 3 = 4878.0` (expands by 1.2 units)

### Tolerance Impact Analysis

| Tolerance | Snapped max_y | Delta from 4876.8 |
|-----------|---------------|-------------------|
| 0.01 (default MM) | 4876.8 | 0.0 |
| 0.1 | 4876.8 | 0.0 |
| 1.0 | 4877.0 | +0.2 |
| **3.0 (user's value)** | **4878.0** | **+1.2** |
| 5.0 | 4875.0 | -1.8 |

## Why Default Tolerances Work Correctly

The default precision fix tolerances are designed to be small enough to only fix floating-point artifacts without significantly altering geometry:

| Unit | Default Tolerance | Purpose |
|------|------------------|---------|
| MM | 0.01 | Fix nanometer-scale errors |
| IN | 0.0005 | Fix sub-mil errors |
| Unitless | 0.01 | Conservative default |

With tolerance=0.01, snapping `4876.80000000028` produces `4876.8` (exact match).

## The Design Trade-off

**Purpose of Precision Fix**: Close polygon gaps caused by floating-point precision errors so `polygonize()` can correctly identify closed regions for area calculation.

**Side Effect**: When tolerance is large, the snapping grid can shift polygon boundaries significantly, causing content zone bounds to differ from native block bounds.

**Current Behavior**:
- Native dimensions: Use raw coordinates (correct for reporting block size)
- Content zone dimensions: Use snapped coordinates (needed for polygon closure)
- Trim values: Mix both coordinate systems (causes discrepancy)

## Recommendations

### Option 1: Clamp Content Zone to Block Bounds (Preferred)

Add post-processing to ensure content zone never exceeds block bounds:

```python
# After calculating cz_bbox from polygons:
cz_min_x = max(cz_min_x, block_min_x)
cz_min_y = max(cz_min_y, block_min_y)
cz_max_x = min(cz_max_x, block_max_x)
cz_max_y = min(cz_max_y, block_max_y)
```

**Pros**: Simple fix, ensures trim values are always >= 0
**Cons**: May slightly misrepresent actual polygon detection results

### Option 2: Use Consistent Coordinate System

Apply precision snapping to block_bbox calculation as well:

```python
bbox = _get_block_bounding_box(block_def)
if precision_tolerance > 0:
    bbox = tuple(round(c / precision_tolerance) * precision_tolerance for c in bbox)
```

**Pros**: Both calculations use same coordinates
**Cons**: Native dimensions would vary based on precision setting

### Option 3: Separate Polygon Closure from Trim Calculation

Use snapped coordinates only for polygon detection, then re-calculate bounds from original coordinates:

```python
# Detect polygons with snapping for closure
polygons = _extract_paint_bucket_regions(block_def, precision_tolerance=3.0)
# Get bounding box from raw polygon coordinates (without snapping)
original_bounds = _get_union_bounding_box_from_raw(polygons, block_def)
```

**Pros**: Mathematically correct separation of concerns
**Cons**: More complex implementation

### Option 4: Warning for Large Tolerances

Add validation/warning when precision fix amount might cause coordinate shift > 1 unit:

```python
if precision_fix_amount > 1.0:
    logger.warning(f"Large precision fix ({precision_fix_amount}) may cause trim discrepancies")
```

**Pros**: Educates users without code changes
**Cons**: Doesn't fix the underlying issue

## Next Steps

1. **Immediate**: Document that custom precision fix values > 1 can cause negative trims
2. **Short-term**: Implement Option 1 (clamping) as a safeguard
3. **Long-term**: Consider Option 3 for architecturally correct solution
4. **Testing**: Add unit test for edge case where raw coordinate is near grid boundary
