# Implementation Plan: Extract CIRCLE, ARC, and HATCH Boundary Edges

## Executive Summary

This plan extends `_extract_all_edges()` in `geometry.py` to extract edges from CIRCLE, ARC, and HATCH boundary entities. Currently the function only extracts LINE and LWPOLYLINE/POLYLINE edges, causing incomplete polygon detection for blocks containing these entity types. The implementation involves discretizing curved entities to line segments and parsing HATCH boundary path structures.

## Table Summary

| Entity Type | Current State | Target State | Implementation Approach | Complexity | Risk |
|-------------|---------------|--------------|------------------------|------------|------|
| LINE | Extracted | Extracted | No change | N/A | N/A |
| LWPOLYLINE/POLYLINE | Extracted | Extracted | No change | N/A | N/A |
| CIRCLE | Not extracted | Extracted | Discretize to line segments | Low | Low |
| ARC | Not extracted | Extracted | Discretize to line segments | Low | Low |
| HATCH (PolylinePath) | Not extracted | Extracted | Extract vertex edges | Low | Low |
| HATCH (EdgePath - LineEdge) | Not extracted | Extracted | Extract start/end edges | Low | Low |
| HATCH (EdgePath - ArcEdge) | Not extracted | Extracted | Discretize to segments | Medium | Low |

## Relevant Files

- **app/core/geometry.py:375-410** - `_extract_all_edges()` function to modify; core edge extraction logic
- **app/core/geometry.py:65-152** - `_get_block_bounding_box()` already handles CIRCLE/ARC for reference
- **app/core/geometry.py:155-245** - `_get_intersection_points()` already handles CIRCLE/ARC for reference
- **app/core/constants.py** - May need new constant for arc segment count (discretization resolution)
- **app/tests/core/test_content_zone.py** - Existing test suite for content zone detection
- **app/tests/assets/circles_arcs_points.dxf** - Test fixture with CIRCLE and ARC entities
- **app/tests/assets/hatch_test.dxf** - Test fixture with HATCH entities

## In-Scope

1. **CIRCLE entity extraction** - Discretize full circles into line segment edges
2. **ARC entity extraction** - Discretize arcs into line segment edges
3. **HATCH PolylinePath extraction** - Extract edges from polyline boundary paths
4. **HATCH EdgePath - LineEdge** - Extract line edges from edge paths
5. **HATCH EdgePath - ArcEdge** - Discretize arc edges to line segments
6. **Unit tests** - Tests for each new entity type extraction

## Out-of-Scope

1. **ELLIPSE entities** - Not commonly used in target drawings
2. **SPLINE entities** - Complex discretization, rare in target drawings
3. **HATCH EdgePath - EllipseEdge** - Low priority, complex geometry
4. **HATCH EdgePath - SplineEdge** - Low priority, complex geometry
5. **3D entities** - Focus on 2D extraction only
6. **POINT entities** - Points have no edges (zero-dimensional)

## Implementation Steps

### Step 1: Add Arc Discretization Constant

**File:** `app/core/constants.py`

Add a constant for arc segment resolution:

```python
ARC_SEGMENT_COUNT = 32  # Number of segments for discretizing arcs/circles
```

### Step 2: Create Helper Function for Arc Discretization

**File:** `app/core/geometry.py`

Add helper function to discretize an arc to line segments:

```python
def _discretize_arc(
    center: tuple[float, float],
    radius: float,
    start_angle: float,
    end_angle: float,
    segment_count: int = ARC_SEGMENT_COUNT,
) -> list[LineString]:
    """Discretize an arc into line segments."""
    # Convert angles to radians
    # Generate points along arc
    # Return list of LineString edges between consecutive points
```

### Step 3: Add CIRCLE Extraction to `_extract_all_edges()`

**File:** `app/core/geometry.py:375-410`

Add CIRCLE handling after LWPOLYLINE block:

```python
elif entity.dxftype() == "CIRCLE":
    center = entity.dxf.center
    radius = entity.dxf.radius
    # Full circle: 0 to 360 degrees
    arc_edges = _discretize_arc(
        (center.x, center.y), radius, 0, 360, ARC_SEGMENT_COUNT
    )
    edges.extend(arc_edges)
```

### Step 4: Add ARC Extraction to `_extract_all_edges()`

**File:** `app/core/geometry.py:375-410`

Add ARC handling:

```python
elif entity.dxftype() == "ARC":
    center = entity.dxf.center
    radius = entity.dxf.radius
    start_angle = entity.dxf.start_angle
    end_angle = entity.dxf.end_angle
    arc_edges = _discretize_arc(
        (center.x, center.y), radius, start_angle, end_angle
    )
    edges.extend(arc_edges)
```

### Step 5: Add HATCH Boundary Extraction Helper

**File:** `app/core/geometry.py`

Add helper function to extract edges from HATCH boundaries:

```python
def _extract_hatch_boundary_edges(entity: Any) -> list[LineString]:
    """Extract edges from HATCH boundary paths."""
    edges: list[LineString] = []

    for path in entity.paths:
        if path.type == "PolylinePath":
            # Extract polyline vertices as edges
            vertices = path.vertices
            for i in range(len(vertices) - 1):
                edges.append(LineString([vertices[i], vertices[i + 1]]))
            if path.is_closed and len(vertices) >= 2:
                edges.append(LineString([vertices[-1], vertices[0]]))

        elif path.type == "EdgePath":
            for edge in path.edges:
                if edge.type == "LineEdge":
                    edges.append(LineString([edge.start, edge.end]))
                elif edge.type == "ArcEdge":
                    arc_edges = _discretize_arc(
                        edge.center, edge.radius,
                        edge.start_angle, edge.end_angle
                    )
                    edges.extend(arc_edges)

    return edges
```

### Step 6: Add HATCH Extraction to `_extract_all_edges()`

**File:** `app/core/geometry.py:375-410`

Add HATCH handling:

```python
elif entity.dxftype() == "HATCH":
    try:
        hatch_edges = _extract_hatch_boundary_edges(entity)
        edges.extend(hatch_edges)
    except (AttributeError, TypeError):
        continue
```

### Step 7: Create Test DXF Generator Script

**File:** `app/tests/assets/create_circle_arc_hatch_edges_test.py`

Create test fixture with:
- Block with CIRCLE entities forming closed regions
- Block with ARC entities forming closed regions
- Block with HATCH boundaries (PolylinePath and EdgePath variants)
- Block mixing all entity types

### Step 8: Add Unit Tests for CIRCLE Extraction

**File:** `app/tests/core/test_geometry_circle_arc_hatch.py`

Test cases:
- Single circle discretizes to correct segment count
- Circle edges form closed polygon via polygonize
- Content zone detection works with CIRCLE-only blocks

### Step 9: Add Unit Tests for ARC Extraction

**File:** `app/tests/core/test_geometry_circle_arc_hatch.py`

Test cases:
- Arc discretizes to correct segment count based on angle span
- Multiple arcs forming closed shape detected as polygon
- Arc start/end angle handling (including > 360, negative angles)

### Step 10: Add Unit Tests for HATCH Boundary Extraction

**File:** `app/tests/core/test_geometry_circle_arc_hatch.py`

Test cases:
- PolylinePath vertices extracted correctly
- EdgePath LineEdge extraction
- EdgePath ArcEdge discretization
- Mixed EdgePath types in single HATCH
- HATCH with multiple boundary paths

### Step 11: Integration Tests

**File:** `app/tests/core/test_geometry_circle_arc_hatch.py`

Test cases:
- Content zone detection with CIRCLE boundaries
- Content zone detection with mixed LINE + ARC boundaries
- Content zone detection with HATCH boundary defining outer shape
- Paint-bucket algorithm produces correct regions with new entity types

### Step 12: Update Existing Tests

**File:** `app/tests/core/test_content_zone.py`

Verify existing tests still pass after changes. Add regression tests if needed.

## Recommendations

1. **Use ezdxf's built-in methods** - ezdxf provides `entity.flattening()` and similar methods that may simplify arc discretization
2. **Configurable segment count** - Allow segment count to be adjusted for performance vs. accuracy tradeoffs
3. **Handle edge cases** - Full circles (0-360), arcs crossing 0 degrees, very small radii
4. **Log new entity extractions** - Add debug logging for troubleshooting

## Next Steps

1. Implement Step 1-2 (constants and helper function)
2. Implement Step 3-4 (CIRCLE and ARC extraction)
3. Run existing tests to verify no regression
4. Implement Step 5-6 (HATCH extraction)
5. Create test fixtures (Step 7)
6. Add unit tests (Steps 8-11)
7. Run full test suite with coverage report
