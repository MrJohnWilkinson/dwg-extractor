# Parallel Block Processing Performance Analysis

## Executive Summary

The implementation of `specs/058-unit-3-parallel-block-processing.md` uses `ThreadPoolExecutor` for CPU-bound geometry operations. This is fundamentally flawed because Python's Global Interpreter Lock (GIL) prevents true parallel execution of Python bytecode, even with multiple threads. While Shapely/GEOS releases the GIL during C operations, the surrounding Python code (ezdxf document iteration, dictionary operations) still contends for the GIL. **Recommendation: Remove parallel processing entirely** - it's simpler, safer, and the performance gains are minimal or negative for this workload.

## Table Summary

| Aspect | Current Implementation | Best Practice 2025 | Recommendation |
|--------|----------------------|-------------------|----------------|
| **Executor Type** | ThreadPoolExecutor | ProcessPoolExecutor for CPU-bound | Remove parallelism |
| **GIL Impact** | Threads contend for GIL | Processes bypass GIL | N/A |
| **ezdxf Thread Safety** | Not documented/guaranteed | Unknown | Sequential access only |
| **Memory Overhead** | 8 threads × geometry data | Higher with processes | Single thread |
| **Complexity** | Medium (race conditions) | High (pickling issues) | Low (sequential) |
| **Expected Speedup** | 2-4x theoretical | 4-8x with processes | None needed |
| **Actual Impact** | Performance degradation | Better than threads | Best stability |
| **Effort to Fix** | Low | High | Lowest |

## Relevant Files

- `app/core/extractor.py:879-982` - `_analyze_single_block()` function that runs in parallel threads. Contains shared ezdxf document access (`doc` parameter) and block definition iteration.
- `app/core/extractor.py:1299-1354` - Phase 2 parallel processing block with `ThreadPoolExecutor`. Creates 8 worker threads and submits all block definitions.
- `app/core/geometry.py:696-772` - `_extract_paint_bucket_regions()` - CPU-intensive Shapely operations that release GIL. This is the only part that truly benefits from parallelism.
- `app/core/geometry.py:1041-1252` - `_detect_content_zone()` - Main content zone detection. Contains early exit thresholds but still heavy computation.
- `specs/058-unit-3-parallel-block-processing.md` - Original spec claiming Shapely/GEOS is thread-safe for read operations.
- `app/core/constants.py:162-178` - Threshold constants (POLYGON_COUNT_THRESHOLD=500, LINE_SEGMENT_THRESHOLD=5000, ENTITY_COUNT_THRESHOLD=1000).

## Root Cause Analysis

### 1. Misunderstanding of GIL Behavior

The spec states:
> "Shapely/GEOS is thread-safe for read-only operations"
> "Thread pool has lower overhead for CPU-bound tasks with GIL-releasing libraries (like Shapely/GEOS)"

**Reality:** While Shapely 2.0+ does release the GIL during GEOS operations, the Python code surrounding those operations (dictionary access, iteration, result collection) still requires the GIL. In the `_analyze_single_block` function:

```python
# GIL required - ezdxf iteration
for entity in block_def:
    if entity.dxftype() == "INSERT":  # GIL required
        nested_name = entity.dxf.name  # GIL required

# GIL released during GEOS call
bbox = _get_block_bounding_box(block_def)  # Mixed - iteration needs GIL

# GIL required - Python dict creation
result: BlockAnalysisResult = {...}  # GIL required
```

### 2. ezdxf Thread Safety Not Guaranteed

ezdxf documentation does not claim thread-safety. Multiple threads accessing:
- `doc.blocks` - Shared collection
- `block_def` iteration - May have internal state
- `entity.dxf.*` attribute access - Shared document state

This creates potential race conditions and memory corruption.

### 3. Inefficient Workload Distribution

Each thread performs:
1. Block filtering (Python - needs GIL)
2. Entity counting `sum(1 for _ in block_def)` (Python - needs GIL)
3. Nested INSERT scanning (Python - needs GIL)
4. Bounding box calculation (Mixed)
5. Intersection point extraction (Mixed)
6. Content zone detection (Shapely - releases GIL)

Only step 6 truly benefits from parallelism, but it's preceded by GIL-requiring setup.

### 4. Memory Pressure

8 threads simultaneously:
- Extracting edges into `list[LineString]`
- Creating Shapely polygons
- Building result dictionaries

This can cause memory spikes and GC pressure.

## Options Analysis

### Option A: Remove Parallel Processing (Recommended)

**Effort:** Low (revert to sequential loop)
**Risk:** None
**Performance:** Potentially faster due to no thread overhead

```python
# Replace ThreadPoolExecutor block with sequential:
for block_def in doc.blocks:
    effective_name, result = _analyze_single_block(...)
    if effective_name and result:
        # Store results
```

**Pros:**
- Eliminates all thread-safety concerns
- Simplifies code and debugging
- No memory spikes from parallel allocation
- Removes GIL contention overhead

**Cons:**
- No theoretical parallelism benefit

### Option B: Use ProcessPoolExecutor

**Effort:** High
**Risk:** Medium (pickling issues, file handling)
**Performance:** Better parallelism but high overhead

Would require:
1. Restructure to load DXF file in each worker process
2. Handle non-picklable ezdxf objects
3. Serialize results across process boundaries
4. Manage file path passing vs document sharing

**Not recommended** because ezdxf `Drawing` objects are not picklable.

### Option C: Fix Current ThreadPoolExecutor

**Effort:** Medium
**Risk:** Medium (subtle bugs)
**Performance:** Marginal improvement

Would require:
1. Pre-extract all block data into thread-safe structures
2. Pass only serializable data to workers
3. Minimize shared state access
4. Add proper synchronization

**Not recommended** because GIL still limits parallelism for Python code.

## Best Practices 2025

### Python Concurrency Guidelines

| Task Type | Recommended Approach | Reason |
|-----------|---------------------|--------|
| I/O-bound | `ThreadPoolExecutor` | Threads can wait on I/O in parallel |
| CPU-bound (Python) | `ProcessPoolExecutor` | Bypasses GIL |
| CPU-bound (C extension) | `ThreadPoolExecutor` | If library releases GIL |
| Mixed | Separate executors | I/O threads + CPU processes |

### When ThreadPoolExecutor Works for CPU Tasks

ThreadPoolExecutor can provide speedup when:
1. The C extension releases GIL for **most** of the work
2. Python overhead is minimal
3. Shared state access is minimized or protected

**This workload fails all three criteria.**

### Python 3.13+ Free Threading

Python 3.13 introduces experimental free-threading mode that removes the GIL. However:
- Still experimental in 2025
- Requires `--disable-gil` compile flag
- Not widely deployed
- Would still have ezdxf thread-safety concerns

## Recommendations

### Immediate Action: Remove Parallel Processing

1. **Revert `extract_blocks()` Phase 2** to sequential processing
2. **Remove** `_analyze_single_block()` function (inline back into loop)
3. **Remove** `BlockAnalysisResult` TypedDict (no longer needed)
4. **Update** `test_extractor_parallel.py` to verify sequential behavior

### Code Changes Required

Replace lines 1299-1354 in `extractor.py`:

```python
# PHASE 2: Sequential block geometry analysis (removed parallel processing)
logger.info(f"Analyzing {len(list(doc.blocks))} block definitions...")

for block_def in doc.blocks:
    block_name = block_def.name

    # Skip system blocks
    if block_name in ("*Model_Space", "*Paper_Space") or block_name.startswith("*Paper_Space"):
        continue
    # ... rest of original sequential logic
```

### Performance Monitoring

After removal, measure:
1. Extraction time for test files
2. Memory usage peak
3. CPU utilization pattern

Expected: Similar or better performance with lower memory usage.

## Next Steps

1. Create reversion spec for parallel processing removal
2. Implement sequential extraction
3. Run full test suite
4. Benchmark before/after on representative DXF files
5. Update documentation to remove parallel processing claims

## Sources

- [Python Concurrency: ThreadPoolExecutor vs ProcessPoolExecutor](https://superfastpython.com/threadpoolexecutor-vs-processpoolexecutor/)
- [Python concurrent.futures Documentation](https://docs.python.org/3/library/concurrent.futures.html)
- [Shapely Documentation - Threading](https://shapely.readthedocs.io/)
- [PyGEOS Multithreading Analysis](https://caspervdw.github.io/Pygeos-Multithreading/)
- [Real Python - Python Concurrency](https://realpython.com/python-concurrency/)
- [ezdxf Documentation](https://ezdxf.readthedocs.io/)
