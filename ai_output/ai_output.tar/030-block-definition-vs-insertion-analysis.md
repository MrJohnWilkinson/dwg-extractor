# Block Definition vs Block Insertion Discrepancy Analysis

## Executive Summary
The extractor counts only blocks **inserted in modelspace**, while AutoCAD's "Edit Block Definition" list shows **all block definitions** in the file. This is the root cause of the discrepancy: ~45 blocks exist as definitions but have no direct modelspace insertions (they are either nested inside other blocks, defined but unused, or from bound XREFs).

## Table Summary

| Category | Count | Description |
|----------|-------|-------------|
| AutoCAD "Edit Block Definition" list | ~97 | ALL block definitions in the file |
| Extractor block_counts output | 52 | Only blocks with modelspace INSERTs |
| **Missing blocks** | ~45 | Definitions without modelspace insertions |

### Missing Block Categories

| Category | Examples | Reason Not Extracted |
|----------|----------|---------------------|
| Nested-only blocks | Blocks inside other block definitions | No direct modelspace INSERT |
| Orphaned definitions | Defined but never inserted anywhere | No INSERT entity at all |
| XREF-bound blocks | Blocks from bound external references | May exist only as definitions |
| Paper space only | Blocks only in layout tabs | Extractor scans modelspace only |

## Relevant Files

- `app/core/extractor.py:1143-1264` - Block definition iteration (geometry analysis only)
- `app/core/extractor.py:1269-1480` - Modelspace entity iteration (INSERT counting)
- `app/core/extractor.py:1344-1456` - INSERT entity processing (the actual counting logic)

## Root Cause: Design Behavior, Not Bug

### What AutoCAD Shows
AutoCAD's "Edit Block Definition" dialog lists every `BLOCK` definition in the DXF file, including:
1. Blocks inserted directly in modelspace
2. Blocks used only as nested components inside other blocks
3. Blocks defined but never inserted anywhere (orphaned)
4. Blocks from bound XREFs
5. System blocks (filtered in extractor)

### What The Extractor Counts
The extractor iterates through **modelspace entities only** (`doc.modelspace()`) and counts only `INSERT` entities:

```python
# extractor.py:1344-1345
if entity_type == "INSERT":
    original_block_name = entity.dxf.name
```

This means:
- **Nested blocks are NOT counted** - If "FG-12" is inserted inside "SHELF-ASSEMBLY" but never directly in modelspace, it won't appear in block_counts
- **Unused definitions are NOT counted** - If "FG-12" was defined but never inserted anywhere, it won't appear
- **Paper space insertions are NOT counted** - Only modelspace is scanned

## Analysis of "FG-12" Block

The user specifically asked about "FG-12" appearing in AutoCAD but not in extraction.

### Likely Scenarios for FG-12

| Scenario | How to Verify |
|----------|---------------|
| **Nested inside another block** | In AutoCAD: Insert FG-12 → shows "0 found" in modelspace but exists inside another block definition |
| **Orphaned definition** | Block was defined/imported but never placed in the drawing |
| **Paper space only** | Block exists only in layout tabs, not in Model tab |
| **XREF-bound** | Block came from an external reference that was bound but not exploded |

### How to Verify in AutoCAD
1. Open the drawing
2. Use `BCOUNT` command to count block insertions
3. Use `QSELECT` to search for INSERT entities with name "FG-12"
4. Use `BEDIT` to check if FG-12 appears inside other block definitions

## Code Analysis: Block Definition vs INSERT Processing

### Block Definition Loop (lines 1143-1264)
```python
for block_def in doc.blocks:
    block_name = block_def.name
    # ... geometry analysis only (trimming_data, content_zone)
    # Does NOT count insertions
```

This loop processes all block **definitions** for geometry analysis but does NOT count insertions.

### Modelspace Entity Loop (lines 1269-1480)
```python
for entity in msp:
    entity_type = entity.dxftype()
    if entity_type == "INSERT":
        # Count block insertions
```

This loop processes only **modelspace entities** and counts INSERT entities. Blocks not directly inserted in modelspace are not counted.

### Nested Blocks Are Not Recursively Counted
The extractor does NOT recursively scan inside block definitions. If block "A" contains an INSERT of block "B", only "A" is counted when "A" is placed in modelspace. The nested "B" insertion is ignored.

## Recommendations

### Option 1: Add "All Block Definitions" Output (New Feature)
Add a separate output that lists all block definitions in the file, regardless of insertion status:

```python
# Would add to extraction result:
all_block_definitions: dict[str, int]  # name -> entity count in definition
```

**Pros:** Shows complete picture of what's in the file
**Cons:** May include irrelevant system/orphaned blocks

### Option 2: Add Nested Block Detection (Complex)
Recursively scan block definitions to count nested block references:

```python
# Scan inside each block definition for INSERT entities
for block_def in doc.blocks:
    for entity in block_def:
        if entity.dxftype() == "INSERT":
            # Track nested usage
```

**Pros:** Shows where "missing" blocks are actually used
**Cons:** Complex, may show confusing hierarchy

### Option 3: Status Quo with Better Documentation
Keep current behavior but document clearly that:
- Extractor counts **modelspace insertions only**
- Use AutoCAD's BCOUNT for comparison
- Nested/orphaned blocks are intentionally excluded

## Next Steps

1. **Verify the specific file** - Confirm which blocks are nested vs orphaned vs paper-space
2. **User requirement clarification** - Does the user need:
   - All block definitions listed? (inventory)
   - Only placed blocks counted? (current behavior)
   - Nested block hierarchy? (complex)
3. **Feature decision** - If all definitions needed, implement Option 1

## Technical Reference

### DXF Structure
```
DXF File
├── BLOCKS Section (definitions)
│   ├── *Model_Space (system)
│   ├── *Paper_Space (system)
│   ├── FG-12 (block definition)
│   ├── FG-End (block definition)
│   └── ... (97+ definitions)
│
└── ENTITIES Section (modelspace)
    ├── INSERT (block_name="SHELF-ASSEMBLY") ← counted
    ├── INSERT (block_name="A$C86afe4d1") ← counted (as resolved name)
    └── ... (52 unique block names with insertions)

    Note: No INSERT with block_name="FG-12" in modelspace
          → FG-12 may be nested inside SHELF-ASSEMBLY definition
```

### ezdxf API Reference
- `doc.blocks` - Iterator over all BLOCK definitions
- `doc.modelspace()` - Access to modelspace entities only
- `entity.dxftype() == "INSERT"` - Block insertion entity
- `entity.dxf.name` - Name of inserted block
