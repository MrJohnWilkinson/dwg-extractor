# Feature: Unit Tests for T-Junctions and Crossing Intersections

## Feature Description
Add comprehensive unit tests for the `_extract_line_cycles()` function in the geometry module to verify correct polygon detection from LINE entities, including T-junctions and crossing intersections. These tests validate the `unary_union()` preprocessing fix implemented in Unit 1 that splits lines at intersection points before polygonization.

## User Story
As a developer maintaining the DXF Block Extractor
I want unit tests that verify polygon detection from LINE entities with T-junctions and crossings
So that I can confidently modify the cycle detection logic without introducing regressions

## Problem Statement
The `_extract_line_cycles()` function now uses `unary_union()` to preprocess LINE segments before polygonization, which correctly handles T-junctions and crossing intersections. However, there are no dedicated unit tests that verify this behavior. Without explicit tests for these edge cases, future modifications could inadvertently break the T-junction and crossing detection functionality.

## Solution Statement
Add a new test class `TestExtractLineCycles` to `app/tests/core/test_geometry.py` with four focused test cases:
1. Simple rectangle from 4 lines (baseline test)
2. T-junction creating two polygons (vertical divider splitting rectangle)
3. Crossing lines with no closed region (X pattern)
4. Grid pattern with multiple T-junctions and crossings (6 polygons)

These tests use ezdxf to programmatically create block definitions with specific LINE configurations and verify the expected polygon count from `_extract_line_cycles()`.

## Relevant Files
Use these files to implement the feature:

- `app/tests/core/test_geometry.py` - Target file for adding the new test class. Contains existing test classes for other geometry functions (`TestBoundingBox`, `TestIntersectionPoints`, `TestCalculateSegments`, `TestCategorizeRotation`).
- `app/core/geometry.py` - Contains the `_extract_line_cycles()` function being tested. Function signature: `_extract_line_cycles(block_def: BlockLayout, abort_event: threading.Event | None = None) -> list[Polygon]`
- `ai_docs/011-python-testing-template.md` - Reference for testing patterns and conventions used in this project.

### No New Files Required
All changes are additions to existing test file `app/tests/core/test_geometry.py`.

## Implementation Plan
### Phase 1: Foundation
- Add import for `_extract_line_cycles` to the existing imports in `test_geometry.py`
- Review existing test patterns in the file for consistency

### Phase 2: Core Implementation
- Create `TestExtractLineCycles` class with docstring
- Implement four test methods following the existing test patterns
- Each test creates a block with specific LINE configurations using ezdxf
- Verify polygon count returned by `_extract_line_cycles()`

### Phase 3: Integration
- Run tests to verify all pass
- Ensure no regressions in existing 492+ tests
- Verify type checking passes with mypy

## Step by Step Tasks

### Step 1: Add Import Statement
- Add `_extract_line_cycles` to the existing imports from `core.geometry`
- Update import statement: `from core.geometry import (_calculate_segments, _categorize_rotation, _get_block_bounding_box, _get_intersection_points, _extract_line_cycles)`

### Step 2: Create TestExtractLineCycles Class
- Add new test class after existing test classes (at end of file)
- Include class-level docstring describing the test suite purpose

### Step 3: Implement test_simple_rectangle_from_lines
- Create ezdxf document and block with 4 lines forming a 100x50 rectangle
- Lines: (0,0)-(100,0), (100,0)-(100,50), (100,50)-(0,50), (0,50)-(0,0)
- Call `_extract_line_cycles(block)`
- Assert exactly 1 polygon is returned

### Step 4: Implement test_t_junction_creates_two_polygons
- Create block with rectangle + vertical divider at midpoint
- Rectangle lines: (0,0)-(100,0), (100,0)-(100,50), (100,50)-(0,50), (0,50)-(0,0)
- Divider line: (50,0)-(50,50) - creates T-junctions at top and bottom
- Call `_extract_line_cycles(block)`
- Assert exactly 2 polygons are returned (left and right halves)

### Step 5: Implement test_crossing_lines_no_closed_region
- Create block with two diagonal lines forming an X pattern
- Lines: (0,0)-(100,100), (100,0)-(0,100)
- Call `_extract_line_cycles(block)`
- Assert exactly 0 polygons are returned (no closed region)

### Step 6: Implement test_grid_pattern_multiple_polygons
- Create block with rectangle + 2 horizontal lines + 1 vertical divider
- Rectangle: (0,0)-(150,90) perimeter
- Horizontal dividers at y=30 and y=60
- Vertical divider at x=75
- Call `_extract_line_cycles(block)`
- Assert exactly 6 polygons are returned (3 rows x 2 columns)

### Step 7: Run Tests and Validate
- Run `uv run pytest app/tests/core/test_geometry.py::TestExtractLineCycles -v` to verify new tests pass
- Run `uv run pytest app/tests/` to verify no regressions
- Run `uv run mypy app/` to verify type checking passes

## Testing Strategy
### Unit Tests
- `test_simple_rectangle_from_lines`: Verifies basic polygon detection from 4 lines forming a closed rectangle
- `test_t_junction_creates_two_polygons`: Verifies T-junction handling where a divider splits a rectangle into two polygons
- `test_crossing_lines_no_closed_region`: Verifies that crossing lines without forming closed regions return no polygons
- `test_grid_pattern_multiple_polygons`: Verifies complex grid with multiple T-junctions and crossings produces correct polygon count

### Integration Tests
- Not applicable - these are unit tests for a pure geometry function

### Edge Cases
- Simple closed polygon (baseline)
- T-junction splitting a polygon (2 new polygons)
- X-pattern crossings with no closed region (0 polygons)
- Grid pattern with multiple intersections (6 polygons)

### Playwright MCP Tests
- Not applicable - this is a backend geometry calculation function

## Acceptance Criteria
- [ ] Import statement includes `_extract_line_cycles`
- [ ] `TestExtractLineCycles` class exists with 4 test methods
- [ ] `test_simple_rectangle_from_lines` passes and returns 1 polygon
- [ ] `test_t_junction_creates_two_polygons` passes and returns 2 polygons
- [ ] `test_crossing_lines_no_closed_region` passes and returns 0 polygons
- [ ] `test_grid_pattern_multiple_polygons` passes and returns 6 polygons
- [ ] All existing tests continue to pass (492+ tests)
- [ ] Type checking passes with `uv run mypy app/`
- [ ] Code formatting passes with `uv run ruff check app/`

## Validation Commands
Execute every command to validate the feature works correctly with zero regressions.

- `uv run pytest app/tests/core/test_geometry.py::TestExtractLineCycles -v` - Run new test class to verify all 4 tests pass
- `uv run pytest app/tests/` - Run full test suite to verify no regressions
- `uv run mypy app/` - Run type checking to verify no type errors
- `uv run ruff check app/` - Run linting to verify code quality

## Notes
- Unit 1 implementation modified `_extract_line_cycles()` to use `unary_union()` preprocessing
- The function handles both single `LineString` and `MultiLineString` results from `unary_union()`
- All 492 existing tests pass after Unit 1 implementation
- Tests use ezdxf to programmatically create block definitions - no test DXF files needed
- Follow existing test patterns in `test_geometry.py` for consistency
