# Chore: Add Comprehensive Tests for HATCH Detection in Color Analysis

## Chore Description
Create comprehensive tests around the HATCH entity detection functionality in the Color Analysis tab. While existing tests pass using a synthetic test fixture (`hatch_test.dxf`), the user reported that a real extracted sheet is not showing hatches when hatches should be present. This chore adds tests using real-world DXF files to ensure HATCH detection works reliably with production data and catches edge cases that synthetic fixtures may miss.

## Relevant Files
Use these files to resolve the chore:

- `app/tests/core/test_extractor.py` - Contains existing `TestHatchExtraction` class with 9 tests. New real-world HATCH tests will be added to this file.
- `app/core/extractor.py` - Contains `extract_color_analysis()` function with HATCH processing at lines 288-290. Understanding this helps write targeted tests.
- `app/tests/assets/hatch_test.dxf` - Existing synthetic test fixture with 8 HATCH entities. Used by current tests.
- `app/tests/assets/samples/ACAD-11211-FXP.dxf` - Real-world DXF file with 123 HATCH entities. Will be used for new real-world tests.
- `app/tests/assets/Supermarket-2020-block-rotations.dxf` - Another real-world DXF file with 19 HATCH entities. Can be used for additional coverage.

### New Files
None - tests will be added to existing `test_extractor.py`

## Step by Step Tasks

### Step 1: Add test for HATCH detection with real-world DXF file
- Add new test `test_color_analysis_hatch_real_world_file` to `TestHatchExtraction` class
- Use `app/tests/assets/samples/ACAD-11211-FXP.dxf` which has 123 HATCH entities
- Verify that:
  - Hatch records are extracted (at least 1 record)
  - Entity type is "Hatches"
  - Reasonable number of hatches are detected (file has 123 hatches, should get aggregated records)

### Step 2: Add test for HATCH count verification with real-world file
- Add new test `test_color_analysis_hatch_count_real_world`
- Verify total hatch entity count across all records matches or approximates the raw HATCH entity count
- This catches issues where hatches are silently filtered out due to color resolution failures

### Step 3: Add test for HATCH ACI color variety
- Add new test `test_color_analysis_hatch_aci_color_variety`
- Use the real-world file which has hatches with various ACI colors (5, 51, 91, 96, 130, 140, 150, 160, 220)
- Verify that hatches with different ACI colors are extracted correctly
- Check that ACI values in the 1-255 range are properly resolved

### Step 4: Add test for HATCH True Color detection in real-world file
- Add new test `test_color_analysis_hatch_true_color_real_world`
- The real-world file has hatches with True Color (RGB directly set, e.g., `RGB(r=0, g=127, b=0)`)
- Verify True Color hatches have `color_aci=None`
- Verify RGB values are correctly extracted

### Step 5: Add test for mixed HATCH and True Color hatches
- Add new test `test_color_analysis_hatch_mixed_aci_and_true_color`
- Verify that a single file can have both ACI-colored and True Color hatches
- Both types should appear correctly in the results

### Step 6: Add test for HATCH layer grouping with real-world data
- Add new test `test_color_analysis_hatch_layer_grouping_real_world`
- Verify hatches are properly grouped by layer
- Check that the real-world file's hatches on `A-Area-Nsel` and `A-AREA-SPCE` layers are separated

### Step 7: Add diagnostic test to help debug future issues
- Add new test `test_color_analysis_hatch_diagnostic_info`
- When running with verbose pytest, this test prints diagnostic info about HATCH extraction
- Shows: total hatches in file, total hatch records extracted, hatches that failed color resolution
- This helps debug future "hatches not showing" issues

### Step 8: Run validation commands
- Run all tests to ensure no regressions
- Run type checking and linting

## Validation Commands
Execute every command to validate the chore is complete with zero regressions.

- `uv run pytest app/tests/core/test_extractor.py::TestHatchExtraction -v` - Run all HATCH extraction tests including new ones
- `uv run pytest app/tests/core/test_extractor.py::TestColorAnalysis -v` - Run color analysis tests to ensure no regressions
- `uv run pytest app/tests/ -v` - Run full test suite to ensure no regressions
- `uv run mypy app/` - Run type checking to validate no type errors
- `uv run ruff check app/` - Run linting to validate code style

## Notes
- The real-world file `ACAD-11211-FXP.dxf` has 123 HATCH entities that get extracted into 73 records (due to color/layer aggregation)
- The existing synthetic test fixture (`hatch_test.dxf`) only has 8 hatches with carefully controlled colors
- Real-world DXF files may have hatches with unusual color configurations (high ACI values, True Color, ByLayer, etc.)
- The user's issue of "hatches not showing" could be specific to their file - the diagnostic test will help identify such issues in the future
- All new tests should use the sample file path `app/tests/assets/samples/ACAD-11211-FXP.dxf`
