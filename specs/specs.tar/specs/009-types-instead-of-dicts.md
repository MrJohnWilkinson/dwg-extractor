# Chore: Ensure Codebase Uses Types Instead of Dicts

## Chore Description
Audit and enhance the codebase to replace generic `dict[...]` type annotations with semantic TypedDict or type alias definitions. While the codebase already has `app/core/types.py` with some TypedDict definitions (`BlockTrimmingData`, `ColorAnalysisRecord`), the `ExtractionResult` TypedDict in `extractor.py` still uses raw `dict[...]` annotations for many fields. This chore will:

1. Create semantic type aliases for commonly used dictionary patterns
2. Improve code readability by giving meaningful names to complex dict types
3. Enhance IDE support with better type hints and autocompletion
4. Maintain type safety while improving code documentation

The goal is NOT to change all dicts to classes, but to provide meaningful type aliases that document the intent and structure of the data.

## Relevant Files
Use these files to resolve the chore:

### Core Files Requiring Changes
- `app/core/types.py` - Add new type aliases for common dict patterns used in ExtractionResult
- `app/core/extractor.py` - Update ExtractionResult TypedDict to use new type aliases; update local variable annotations

### Files for Reference Only (no changes needed)
- `app/core/excel_writer.py` - Uses types from extractor.py; verify compatibility after changes
- `app/core/excel_formatting.py` - No dict type annotations requiring changes
- `app/core/geometry.py` - No dict type annotations requiring changes
- `app/core/constants.py` - No dict type annotations requiring changes

### Test Files (verify compatibility)
- `app/tests/core/test_extractor.py` - Verify tests still pass after type changes
- `app/tests/core/test_excel_writer.py` - Verify tests still pass after type changes

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### 1. Add type aliases to app/core/types.py
Add the following type aliases after the existing TypedDict definitions:

```python
# Type aliases for ExtractionResult dictionary fields
# These provide semantic meaning to commonly used dict patterns

# Block-related type aliases
BlockCountsDict = dict[str, int]
"""Maps block names to their total insertion count across all layers."""

BlockEntitiesDict = dict[str, int]
"""Maps block names to the entity count within their block definition."""

BlockLayerPairsDict = dict[tuple[str, str], int]
"""Maps (block_name, layer_name) tuples to insertion count on that layer."""

BlockRotationCountsDict = dict[tuple[str, str, str], int]
"""Maps (block_name, layer_name, rotation_category) tuples to count.
Rotation categories: '0', '90', '180', '270', 'other'."""

BlockScaleDataDict = dict[str, set[tuple[float, float]]]
"""Maps block names to sets of unique (x_scale, y_scale) tuples."""

BlockXdataAppsDict = dict[tuple[str, str], set[str]]
"""Maps (block_name, layer_name) tuples to sets of XDATA application IDs."""

BlockTrimmingDataDict = dict[str, BlockTrimmingData]
"""Maps block names to their geometry analysis data."""

# Layer-related type aliases
LayerCountsDict = dict[str, int]
"""Generic dict mapping layer names to integer counts."""

LayerColorsDict = dict[str, set[tuple[int, int, int]]]
"""Maps layer names to sets of unique RGB color tuples."""

# Annotation-related type aliases
AnnotationDataDict = dict[tuple[str, str, str, int, int, int], int]
"""Maps (contents, type, layer_name, color_r, color_g, color_b) tuples to count."""

# Entity-related type aliases
EntityTypeCountsDict = dict[str, int]
"""Maps entity type names (e.g., 'LINE', 'INSERT') to their total count."""
```

### 2. Update ExtractionResult TypedDict in extractor.py
- Import the new type aliases from types.py
- Update the ExtractionResult TypedDict field annotations to use the new type aliases
- This improves readability of the TypedDict definition

Before:
```python
class ExtractionResult(TypedDict):
    block_counts: dict[str, int]
    block_entities: dict[str, int]
    block_layer_pairs: dict[tuple[str, str], int]
    ...
```

After:
```python
class ExtractionResult(TypedDict):
    block_counts: BlockCountsDict
    block_entities: BlockEntitiesDict
    block_layer_pairs: BlockLayerPairsDict
    ...
```

### 3. Update local variable annotations in extract_blocks function
Update the local variable type annotations in the `extract_blocks()` function to use the new type aliases for consistency:

- `block_counts: BlockCountsDict = {}`
- `block_entities: BlockEntitiesDict = {}`
- `block_layer_pairs: BlockLayerPairsDict = {}`
- `block_rotation_counts: BlockRotationCountsDict = {}`
- `block_scale_data: BlockScaleDataDict = {}`
- `block_xdata_apps: BlockXdataAppsDict = {}`
- `layer_block_insertion_counts: LayerCountsDict = {}`
- `layer_entity_counts: LayerCountsDict = {}`
- `layer_unique_colors: LayerColorsDict = {}`
- `layer_annotation_counts: LayerCountsDict = {}`
- `annotation_data: AnnotationDataDict = {}`
- `entity_type_counts: EntityTypeCountsDict = {}`
- `block_trimming_data: BlockTrimmingDataDict = {}`

### 4. Update extract_color_analysis local variable
In the `extract_color_analysis()` function, update the `geometric_entities` local variable type annotation:

Before:
```python
geometric_entities: dict[tuple[int, int, int, int | None, str, str], int] = {}
```

After (add type alias to types.py first):
```python
# In types.py, add:
GeometricEntitiesDict = dict[tuple[int, int, int, int | None, str, str], int]
"""Maps (color_r, color_g, color_b, color_aci, layer_name, entity_type) tuples to count."""

# In extractor.py:
geometric_entities: GeometricEntitiesDict = {}
```

### 5. Run validation and fix any type errors
- Run mypy to verify all type annotations are correct
- Run tests to verify functionality is unchanged
- Fix any type errors or import issues

## Validation Commands
Execute every command to validate the chore is complete with zero regressions.

- `uv run mypy app/` - Run mypy type checker - must pass with 0 errors
- `uv run pytest app/tests/ -v` - Run full test suite to verify no regressions
- `uv run ruff check app/` - Run linter to ensure code style compliance
- `uv run ruff format app/ --check` - Verify code formatting

## Notes
- The type aliases are still `dict[...]` under the hood - they just provide semantic names
- This improves code readability without changing runtime behavior
- The `_ACI_NAMED_COLORS` dict in excel_writer.py is a private module constant and doesn't need a type alias
- Test file type annotations (like in test_excel_writer.py:799) are intentionally using raw dict types for testing invalid data scenarios
- The existing `BlockTrimmingData` and `ColorAnalysisRecord` TypedDicts are already well-defined and should continue to be used
- Type aliases use `=` assignment syntax which is valid for type aliases in Python 3.9+
