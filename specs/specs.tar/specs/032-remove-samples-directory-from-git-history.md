# Chore: Remove Samples Directory from Git History

## Chore Description
Permanently remove the entire `app/tests/assets/samples/` directory and all its contents from Git history while keeping it locally for development reference. This directory contains proprietary/client CAD files that should not be publicly accessible on GitHub. The simplified approach removes the entire directory rather than individual files, making the operation cleaner and preventing any sensitive files from being accidentally overlooked.

Files currently in the samples directory:
- `251102-WV10-20-1011 CAD-LAYERS.txt` (proprietary client data)
- `251102-WV10-20-1011.dxf` (proprietary client data)
- `AS-1922_XXXX-SSL-XXX-XX-DR-U-0200.dxf` (proprietary client data)
- `AS-1922_XXXX-SSL-XXX-XX-DR-U-0200_blocks_20251120_230740.xlsx` (proprietary client data)
- `Supermarket-2020-block-rotations.dwg` (potentially sensitive)
- `Supermarket-2020-block-rotations.dxf` (potentially sensitive)
- `Supermarket-2020.dwg` (potentially sensitive)
- `floorplan supermarket v3 new chilled dept.dwg` (potentially sensitive)
- `floorplan supermarket v3.dwg` (potentially sensitive)

Current status:
- Some files are deleted from current branch (marked as `D` in git status)
- Directory exists locally at `app/tests/assets/samples/` with untracked files
- Files may appear in Git history across multiple commits
- Need to rewrite history to remove all traces of the entire directory

## Relevant Files
Use these files to resolve the chore:

- `.gitignore` - Add pattern to prevent future commits of the entire samples directory
  - Will add `app/tests/assets/samples/` pattern to ignore the entire directory
  - Ensures no files in this directory can be accidentally committed

### New Files
No new files need to be created. All work involves Git history manipulation and .gitignore updates.

## Step by Step Tasks
IMPORTANT: Execute every step in order, top to bottom.

### Step 1: Update .gitignore to prevent future commits
- Add entry to `.gitignore` to prevent accidental re-addition of the entire samples directory:
  ```
  # Sensitive/proprietary CAD sample files directory
  app/tests/assets/samples/
  ```
- Commit the .gitignore changes: `git add .gitignore && git commit -m "chore: ignore samples directory containing sensitive CAD files"`

### Step 2: Verify and remove any tracked files in samples directory
- Check current status of samples directory files: `git status --porcelain | grep "app/tests/assets/samples/"`
- If any files in the samples directory are still tracked, remove them: `git rm -r --cached app/tests/assets/samples/`
- If removal was needed, commit: `git commit -m "chore: remove samples directory from Git tracking"`
- Verify removal: `git ls-files | grep "app/tests/assets/samples/"` (should return empty)

### Step 3: Install git-filter-repo tool
- Check if git-filter-repo is already installed: `git filter-repo --version 2>/dev/null || echo "Not installed"`
- If not installed, install using uv: `uv tool install git-filter-repo`
- Verify installation: `git filter-repo --version`

### Step 4: Create backup of repository
- Create a timestamped backup of the entire repository before history rewrite: `cp -r /home/john/github-projects-linux/dwg-extractor /home/john/github-projects-linux/dwg-extractor-backup-$(date +%Y%m%d_%H%M%S)`
- Verify backup was created: `ls -d /home/john/github-projects-linux/dwg-extractor-backup-*`
- This allows rollback if anything goes wrong during the filter-repo operation

### Step 5: Purge samples directory from entire Git history using git-filter-repo
- Run git-filter-repo to purge the entire directory from all history:
  ```bash
  git filter-repo --path app/tests/assets/samples/ --invert-paths --force
  ```
- This rewrites all commits in history, removing any trace of the samples directory and its contents
- The `--invert-paths` flag removes the specified path instead of keeping it
- The `--force` flag is required because we may have uncommitted changes

### Step 6: Re-add remote origin (filter-repo removes it for safety)
- Check if remote was removed: `git remote -v`
- Re-add the remote: `git remote add origin https://github.com/MrJohnWilkinson/dwg-extractor.git`
- Verify remote is set: `git remote -v`

### Step 7: Force push cleaned history to GitHub
- WARNING: This will rewrite history on GitHub and break existing clones
- Force push to overwrite remote history: `git push origin --force --all`
- Force push tags as well (if any exist): `git push origin --force --tags`

### Step 8: Verify local samples directory still exists
- Confirm the samples directory and files still exist locally: `ls -la app/tests/assets/samples/`
- This ensures we preserved the files locally for development use

### Step 9: Run validation commands
- Execute all validation commands listed below to ensure the chore is complete with zero regressions

## Validation Commands
Execute every command to validate the chore is complete with zero regressions.

- `ls -la app/tests/assets/samples/` - Verify directory and files still exist locally (should list 9 files)
- `git log --all --full-history --name-only -- "app/tests/assets/samples/"` - Should return empty (no commits containing this directory)
- `git log --all --oneline | wc -l` - Verify commits still exist (count should be similar but potentially fewer if commits only contained samples files)
- `git status` - Should show clean working tree (no deleted files in staging)
- `cat .gitignore | grep "app/tests/assets/samples/"` - Verify .gitignore entry exists
- `git ls-files | grep "app/tests/assets/samples/"` - Should return empty (no files from samples directory in Git index)
- `git ls-files app/tests/assets/` - Verify other test assets are still tracked (should list DXF files like annotation_test.dxf, circles_arcs_points.dxf, etc.)
- `uv run pytest app/tests/` - Run full test suite to ensure no tests broke from directory removal
- `git remote -v` - Verify remote is properly configured after filter-repo operation

## Notes
- **CRITICAL WARNING**: Force pushing rewrites public history. Anyone with existing clones must re-clone the repository or manually reset their local branches.
- **Backup created**: A timestamped backup of the repository is created before history rewrite in case rollback is needed. Format: `dwg-extractor-backup-YYYYMMDD_HHMMSS`
- **Simplified approach**: Removing the entire `app/tests/assets/samples/` directory is cleaner than removing individual files and prevents accidentally missing any sensitive files.
- **GitHub considerations**:
  - After force push, old commits may still be accessible via direct SHA links for ~30 days
  - Contact GitHub support to fully purge from their caches if needed
  - Pull requests referencing removed commits will show "unknown commit"
- **Local files preserved**: The entire samples directory remains in `app/tests/assets/samples/` for development use, just not committed to Git
- **Team communication**: Notify all team members that history has been rewritten and they need to re-clone the repository
- **Tool choice**: `git-filter-repo` is the officially recommended tool by the Git project for rewriting history
- **Verification**: After completion, verify on GitHub web interface that the samples directory doesn't appear in commit history or file browser
- **Test suite**: The test suite should continue passing as test files use the test assets in `app/tests/assets/` (not the samples subdirectory)
