# Chore: Types, Dicts, and Classes Inventory

## Chore Description
Output a markdown table that lists all dicts, types, classes, and type aliases in the codebase. This chore provides a comprehensive inventory of type definitions used across the application for reference and documentation purposes.

## Relevant Files
Use these files to resolve the chore:

- `app/core/types.py` - Contains the shared TypedDict definitions (`BlockTrimmingData`, `ColorAnalysisRecord`)
- `app/core/extractor.py` - Contains the main `ExtractionResult` TypedDict class and internal dict type annotations
- `app/core/excel_writer.py` - Contains the `_ACI_NAMED_COLORS` dict constant
- `app/core/excel_formatting.py` - No custom types, uses openpyxl types
- `app/core/geometry.py` - No custom types, uses ezdxf types
- `app/core/constants.py` - Contains string constants (not types)
- `app/core/logger.py` - No custom types
- `app/main.py` - Contains the `DXFExtractorApp` class (GUI application)

## Step by Step Tasks

### Step 1: Generate the Markdown Table
Create the following markdown table documenting all types, dicts, and classes in the codebase:

| Name | Kind | File | Line | Description |
|------|------|------|------|-------------|
| `BlockTrimmingData` | TypedDict | `app/core/types.py` | 23 | Block geometry analysis data for trimming assistance (native_width, native_height, vertical_segments, horizontal_segments) |
| `ColorAnalysisRecord` | TypedDict | `app/core/types.py` | 43 | Color analysis record for Lines, Polylines, Hatches, TEXT, and MTEXT entities with RGB values and counts |
| `ExtractionResult` | TypedDict | `app/core/extractor.py` | 384 | Comprehensive extraction result containing all CAD analysis data (block_counts, block_entities, layer data, color analysis, etc.) |
| `_ACI_NAMED_COLORS` | dict[int, str] | `app/core/excel_writer.py` | 87 | ACI (AutoCAD Color Index) named colors mapping (1-7: Red, Yellow, Green, Cyan, Blue, Magenta, White) |
| `DXFExtractorApp` | class (ctk.CTk) | `app/main.py` | 41 | Main GUI application class for DXF Block Extractor with file browsing, extraction, and Excel output |

### Step 2: Document Internal Dict Type Annotations
The following internal dict type annotations are used within functions:

| Variable | Type Annotation | File | Function/Context |
|----------|-----------------|------|------------------|
| `geometric_entities` | `dict[tuple[int, int, int, int \| None, str, str], int]` | `app/core/extractor.py` | `extract_color_analysis()` - Groups entities by (R, G, B, ACI, layer_name, entity_type) |
| `text_annotations` | `list[ColorAnalysisRecord]` | `app/core/extractor.py` | `extract_color_analysis()` - List for text annotation records |
| `block_counts` | `dict[str, int]` | `app/core/extractor.py` | `extract_blocks()` - Block name to insertion count |
| `block_entities` | `dict[str, int]` | `app/core/extractor.py` | `extract_blocks()` - Block name to entity count within definition |
| `block_layer_pairs` | `dict[tuple[str, str], int]` | `app/core/extractor.py` | `extract_blocks()` - (block_name, layer_name) to insertion count |
| `block_rotation_counts` | `dict[tuple[str, str, str], int]` | `app/core/extractor.py` | `extract_blocks()` - (block_name, layer_name, rotation_category) to count |
| `block_scale_data` | `dict[str, set[tuple[float, float]]]` | `app/core/extractor.py` | `extract_blocks()` - Block name to unique (x_scale, y_scale) tuples |
| `block_xdata_apps` | `dict[tuple[str, str], set[str]]` | `app/core/extractor.py` | `extract_blocks()` - (block_name, layer_name) to XDATA application IDs |
| `layer_block_insertion_counts` | `dict[str, int]` | `app/core/extractor.py` | `extract_blocks()` - Layer name to block insertion count |
| `layer_entity_counts` | `dict[str, int]` | `app/core/extractor.py` | `extract_blocks()` - Layer name to total entity count |
| `layer_unique_colors` | `dict[str, set[tuple[int, int, int]]]` | `app/core/extractor.py` | `extract_blocks()` - Layer name to unique RGB color tuples |
| `layer_annotation_counts` | `dict[str, int]` | `app/core/extractor.py` | `extract_blocks()` - Layer name to TEXT/MTEXT count |
| `annotation_data` | `dict[tuple[str, str, str, int, int, int], int]` | `app/core/extractor.py` | `extract_blocks()` - (contents, type, layer, r, g, b) to count |
| `entity_type_counts` | `dict[str, int]` | `app/core/extractor.py` | `extract_blocks()` - Entity type name to count |
| `block_trimming_data` | `dict[str, BlockTrimmingData]` | `app/core/extractor.py` | `extract_blocks()` - Block name to geometry analysis data |
| `layer_unique_color_counts` | `dict[str, int]` | `app/core/extractor.py` | `extract_blocks()` - Layer name to unique color count |

## Validation Commands
Execute every command to validate the chore is complete with zero regressions.

- `uv run pytest app/tests/` - Run all tests to ensure no regressions
- `uv run mypy app/` - Run type checking to validate type annotations are correct

## Notes
- The codebase uses Python's `TypedDict` from the `typing` module for structured dictionary types
- `ExtractionResult` is the main data structure returned by `extract_blocks()` and consumed by `write_excel()`
- The `BlockTrimmingData` and `ColorAnalysisRecord` TypedDicts are defined in a separate `types.py` module for reusability
- Internal dict type annotations provide strong typing within functions but are not exported as public types
- The `DXFExtractorApp` class is the only class in the codebase (besides TypedDicts) and inherits from `customtkinter.CTk`
